// src/config.ts
var PLATFORM_BASE_URL = "https://trafegopago-trafegopago.ztcjzs.easypanel.host";
var CONSENT_VERSION = "4.0.0";
var HEARTBEAT_INTERVAL_MINUTES = 1;

// src/service-worker.ts
var ALARM_NAME = "heartbeat";
var STORAGE_AUTH = "auth";
var STORAGE_DEVICE_PUBLIC_ID = "devicePublicId";
var STORAGE_LAST_WHATSAPP_STATE = "lastWhatsappState";
var STORAGE_REVOKED_FLAG = "wasRevoked";
var STORAGE_LAST_SEND_DEBUG = "lastSendDebug";
async function recordSendDebug(result, itemCount) {
  await chrome.storage.local.set({
    [STORAGE_LAST_SEND_DEBUG]: { at: (/* @__PURE__ */ new Date()).toISOString(), result, itemCount }
  });
}
async function getDevicePublicId() {
  const existing = await chrome.storage.local.get(STORAGE_DEVICE_PUBLIC_ID);
  if (existing[STORAGE_DEVICE_PUBLIC_ID]) return existing[STORAGE_DEVICE_PUBLIC_ID];
  const id = crypto.randomUUID();
  await chrome.storage.local.set({ [STORAGE_DEVICE_PUBLIC_ID]: id });
  return id;
}
async function getAuth() {
  const data = await chrome.storage.local.get(STORAGE_AUTH);
  return data[STORAGE_AUTH] ?? null;
}
async function setAuth(auth) {
  if (auth === null) {
    await chrome.storage.local.remove(STORAGE_AUTH);
  } else {
    await chrome.storage.local.set({ [STORAGE_AUTH]: auth });
  }
}
async function getLastWhatsappState() {
  const data = await chrome.storage.local.get(STORAGE_LAST_WHATSAPP_STATE);
  return data[STORAGE_LAST_WHATSAPP_STATE] ?? null;
}
async function setLastWhatsappState(state) {
  await chrome.storage.local.set({ [STORAGE_LAST_WHATSAPP_STATE]: state });
}
async function ensureAlarm() {
  const existing = await chrome.alarms.get(ALARM_NAME);
  if (!existing) {
    chrome.alarms.create(ALARM_NAME, { periodInMinutes: HEARTBEAT_INTERVAL_MINUTES });
  }
}
chrome.runtime.onInstalled.addListener(() => {
  ensureAlarm();
});
chrome.runtime.onStartup.addListener(() => {
  ensureAlarm();
});
async function sendHeartbeat(connectorState) {
  const auth = await getAuth();
  if (!auth) return "error";
  try {
    const res = await fetch(`${PLATFORM_BASE_URL}/api/integrations/whatsapp-extension/heartbeat`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.deviceToken}` },
      body: JSON.stringify({ connectorState })
    });
    if (res.status === 401) return "revoked";
    return res.ok ? "ok" : "error";
  } catch {
    return "error";
  }
}
async function sendMessageBatch(items) {
  const auth = await getAuth();
  if (!auth) {
    console.warn("[Conector WhatsApp] sendMessageBatch chamado sem auth salva \u2014 dispositivo n\xE3o pareado?");
    await recordSendDebug("sem auth salva", items.length);
    return;
  }
  if (items.length === 0) return;
  try {
    const res = await fetch(`${PLATFORM_BASE_URL}/api/integrations/whatsapp-extension/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.deviceToken}` },
      body: JSON.stringify({ items })
    });
    const data = await res.json().catch(() => null);
    console.log(`[Conector WhatsApp] POST /messages status=${res.status} items=${items.length} processed=${data?.processed ?? "?"} skipped=${data?.skipped ?? "?"} reason=${data?.reason ?? "-"}`);
    await recordSendDebug(`status=${res.status} processed=${data?.processed ?? "?"} skipped=${data?.skipped ?? "?"} reason=${data?.reason ?? "-"}`, items.length);
    if (res.status === 401) await handleRevoked();
  } catch (e) {
    console.error("[Conector WhatsApp] erro de rede ao mandar /messages:", e);
    await recordSendDebug(`erro de rede: ${e instanceof Error ? e.message : String(e)}`, items.length);
  }
}
async function handleRevoked() {
  await setAuth(null);
  await chrome.storage.local.set({ [STORAGE_REVOKED_FLAG]: true });
}
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM_NAME) return;
  const auth = await getAuth();
  if (!auth) return;
  const state = await getLastWhatsappState() ?? "disconnected";
  const result = await sendHeartbeat(state);
  if (result === "revoked") await handleRevoked();
});
async function computePopupState() {
  const auth = await getAuth();
  if (!auth) {
    const revokedData = await chrome.storage.local.get(STORAGE_REVOKED_FLAG);
    if (revokedData[STORAGE_REVOKED_FLAG]) {
      return { type: "status-update", popupState: "device_revoked" };
    }
    return { type: "status-update", popupState: "not_linked" };
  }
  const state = await getLastWhatsappState();
  let popupState;
  if (state === "connected") popupState = "platform_connected";
  else if (state === "waiting_qr") popupState = "waiting_connection";
  else popupState = "whatsapp_closed";
  return { type: "status-update", popupState, connectorState: state ?? void 0 };
}
async function submitCode(code) {
  const devicePublicId = await getDevicePublicId();
  try {
    const res = await fetch(`${PLATFORM_BASE_URL}/api/integrations/whatsapp-extension/claim`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, devicePublicId, consentVersion: CONSENT_VERSION })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const reason = data.reason;
      if (reason === "expired") return { type: "status-update", popupState: "expired_code" };
      if (reason === "not_found" || reason === "used") return { type: "status-update", popupState: "invalid_code", errorMessage: data.error };
      return { type: "status-update", popupState: "comm_error", errorMessage: data.error ?? "Erro ao validar c\xF3digo" };
    }
    await setAuth({
      deviceId: data.deviceId,
      deviceToken: data.deviceToken,
      clientId: data.clientId,
      devicePublicId
    });
    await chrome.storage.local.remove(STORAGE_REVOKED_FLAG);
    await ensureAlarm();
    chrome.tabs.create({ url: `${PLATFORM_BASE_URL}/cliente/whatsapp-extensao` }).catch(() => {
    });
    return { type: "status-update", popupState: "open_whatsapp" };
  } catch {
    return { type: "status-update", popupState: "comm_error", errorMessage: "N\xE3o foi poss\xEDvel falar com a plataforma. Verifique sua conex\xE3o." };
  }
}
async function disconnect() {
  await setAuth(null);
  return { type: "status-update", popupState: "not_linked" };
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "whatsapp-state") {
    (async () => {
      await setLastWhatsappState(message.state);
      const auth = await getAuth();
      if (auth) {
        const result = await sendHeartbeat(message.state);
        if (result === "revoked") await handleRevoked();
      }
    })();
    return false;
  }
  if (message.type === "new-messages") {
    sendMessageBatch(message.items);
    return false;
  }
  if (message.type === "get-status") {
    computePopupState().then(sendResponse);
    return true;
  }
  if (message.type === "submit-code") {
    submitCode(message.code).then(sendResponse);
    return true;
  }
  if (message.type === "disconnect") {
    disconnect().then(sendResponse);
    return true;
  }
  return false;
});
//# sourceMappingURL=service-worker.js.map
