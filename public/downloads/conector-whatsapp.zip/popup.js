// src/config.ts
var PLATFORM_BASE_URL = "https://trafegopago-trafegopago.ztcjzs.easypanel.host";

// src/popup.ts
var dot = document.getElementById("status-dot");
var label = document.getElementById("status-label");
var content = document.getElementById("content");
var privacyLink = document.getElementById("privacy-link");
var sendDebugEl = document.getElementById("send-debug");
privacyLink.href = `${PLATFORM_BASE_URL}/privacidade/extensao-whatsapp`;
privacyLink.target = "_blank";
function send(message) {
  return chrome.runtime.sendMessage(message);
}
function openWhatsApp() {
  chrome.tabs.create({ url: "https://web.whatsapp.com/" });
}
function openPlatform() {
  chrome.tabs.create({ url: `${PLATFORM_BASE_URL}/cliente/whatsapp-extensao` });
}
function button(label2, variant, onClick) {
  const btn = document.createElement("button");
  btn.className = `popup__btn popup__btn--${variant}`;
  btn.textContent = label2;
  btn.addEventListener("click", onClick);
  return btn;
}
function text(msg) {
  const p = document.createElement("p");
  p.className = "popup__text";
  p.textContent = msg;
  return p;
}
function errorBox(msg) {
  const div = document.createElement("div");
  div.className = "popup__error";
  div.textContent = msg;
  return div;
}
function spinner() {
  const div = document.createElement("div");
  div.className = "popup__spinner";
  div.setAttribute("aria-label", "Carregando");
  return div;
}
async function submitCode(code) {
  render("validating");
  const result = await send({ type: "submit-code", code });
  render(result.popupState, result.errorMessage);
}
function renderCodeForm(errorMessage) {
  content.innerHTML = "";
  content.appendChild(text('Gere um c\xF3digo na plataforma (p\xE1gina "Extens\xE3o WA") e cole abaixo.'));
  if (errorMessage) content.appendChild(errorBox(errorMessage));
  const input = document.createElement("input");
  input.className = "popup__code-input";
  input.placeholder = "XXXX-XXXX-XXXX";
  input.maxLength = 14;
  input.setAttribute("aria-label", "C\xF3digo de conex\xE3o");
  content.appendChild(input);
  content.appendChild(
    button("Conectar", "primary", () => {
      if (input.value.trim()) submitCode(input.value.trim());
    })
  );
  content.appendChild(button("Abrir plataforma", "secondary", openPlatform));
}
var currentState = null;
var INPUT_ACTIVE_STATES = ["not_linked", "enter_code", "invalid_code", "expired_code", "device_revoked"];
function render(state, errorMessage) {
  currentState = state;
  content.innerHTML = "";
  const statusMap = {
    not_linked: { dotClass: "", labelText: "N\xE3o vinculado" },
    enter_code: { dotClass: "", labelText: "Informe o c\xF3digo" },
    validating: { dotClass: "warn", labelText: "Validando c\xF3digo..." },
    open_whatsapp: { dotClass: "warn", labelText: "Abra o WhatsApp Web" },
    waiting_connection: { dotClass: "warn", labelText: "Aguardando conex\xE3o" },
    whatsapp_connected: { dotClass: "ok", labelText: "WhatsApp conectado" },
    platform_connected: { dotClass: "ok", labelText: "Plataforma conectada" },
    whatsapp_closed: { dotClass: "err", labelText: "WhatsApp Web fechado" },
    invalid_code: { dotClass: "err", labelText: "C\xF3digo inv\xE1lido" },
    expired_code: { dotClass: "err", labelText: "C\xF3digo expirado" },
    device_revoked: { dotClass: "err", labelText: "Dispositivo revogado" },
    comm_error: { dotClass: "err", labelText: "Erro de comunica\xE7\xE3o" }
  };
  const s = statusMap[state];
  dot.className = `status-dot ${s.dotClass}`;
  label.textContent = s.labelText;
  switch (state) {
    case "not_linked":
    case "invalid_code":
    case "expired_code":
    case "device_revoked":
      renderCodeForm(errorMessage ?? (state === "invalid_code" ? "C\xF3digo inv\xE1lido ou j\xE1 utilizado. Gere um novo na plataforma." : state === "expired_code" ? "Esse c\xF3digo expirou (validade de 10 min). Gere um novo." : state === "device_revoked" ? "Esse dispositivo foi desconectado pela plataforma. Cole um novo c\xF3digo para reconectar." : void 0));
      break;
    case "validating":
      content.appendChild(spinner());
      break;
    case "open_whatsapp":
      content.appendChild(text("C\xF3digo validado! Abra o WhatsApp Web e conecte normalmente (QR Code do pr\xF3prio WhatsApp)."));
      content.appendChild(button("Abrir WhatsApp Web", "primary", openWhatsApp));
      break;
    case "waiting_connection":
      content.appendChild(text("Aguardando voc\xEA conectar o WhatsApp Web nessa aba..."));
      content.appendChild(button("Abrir WhatsApp Web", "secondary", openWhatsApp));
      break;
    case "whatsapp_connected":
    case "platform_connected":
      content.appendChild(text("Tudo certo! O status est\xE1 sendo sincronizado com a plataforma."));
      content.appendChild(button("Abrir plataforma", "secondary", openPlatform));
      content.appendChild(button("Desconectar", "danger", async () => {
        await send({ type: "disconnect" });
        render("not_linked");
      }));
      break;
    case "whatsapp_closed":
      content.appendChild(text('A aba do WhatsApp Web n\xE3o est\xE1 mais respondendo. Abra novamente para o status voltar a "conectado".'));
      content.appendChild(button("Abrir WhatsApp Web", "primary", openWhatsApp));
      content.appendChild(button("Desconectar", "danger", async () => {
        await send({ type: "disconnect" });
        render("not_linked");
      }));
      break;
    case "comm_error":
      content.appendChild(errorBox(errorMessage ?? "N\xE3o foi poss\xEDvel falar com a plataforma."));
      content.appendChild(button("Tentar novamente", "secondary", () => init()));
      break;
    case "enter_code":
      renderCodeForm(errorMessage);
      break;
  }
}
async function init() {
  label.textContent = "Carregando...";
  try {
    const result = await send({ type: "get-status" });
    render(result.popupState, result.errorMessage);
  } catch {
    render("comm_error", "N\xE3o foi poss\xEDvel verificar o status.");
  }
}
async function renderSendDebug() {
  const data = await chrome.storage.local.get("lastSendDebug");
  const debug = data.lastSendDebug;
  if (!debug) {
    sendDebugEl.textContent = "";
    return;
  }
  const timeStr = new Date(debug.at).toLocaleTimeString("pt-BR");
  sendDebugEl.textContent = `\xDAltimo envio: ${timeStr} \u2014 ${debug.result}`;
}
init();
renderSendDebug();
setInterval(() => {
  renderSendDebug();
  if (currentState && !INPUT_ACTIVE_STATES.includes(currentState)) init();
}, 5e3);
//# sourceMappingURL=popup.js.map
