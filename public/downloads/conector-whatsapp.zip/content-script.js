"use strict";
(() => {
  // src/whatsapp-dom-adapter.ts
  var QR_CANVAS_SELECTOR = 'canvas[aria-label], div[data-testid="qrcode"]';
  var CHAT_LIST_SELECTOR = 'div[aria-label="Chat list"], div[aria-label="Lista de conversas"], #pane-side';
  var LOADING_SELECTOR = 'div[data-testid="startup"], div[data-icon="loading"]';
  function detectWhatsAppState(doc = document) {
    try {
      if (doc.querySelector(CHAT_LIST_SELECTOR)) return { state: "connected" };
      if (doc.querySelector(QR_CANVAS_SELECTOR)) return { state: "waiting_qr" };
      if (doc.querySelector(LOADING_SELECTOR)) return { state: "waiting_qr" };
      return { state: null, reason: "unknown_structure" };
    } catch {
      return { state: null, reason: "unknown_structure" };
    }
  }

  // src/config.ts
  var PLATFORM_BASE_URL = "https://trafegopago-trafegopago.ztcjzs.easypanel.host";

  // src/content-script.ts
  var MAIN_WORLD_SOURCE = "conector-whatsapp-main-world";
  var ISOLATED_SOURCE = "conector-whatsapp-isolated";
  var lastReportedState = null;
  function reportState() {
    const result = detectWhatsAppState();
    if (result.state === null) return;
    if (result.state === lastReportedState) return;
    lastReportedState = result.state;
    const message = { type: "whatsapp-state", state: result.state };
    chrome.runtime.sendMessage(message).catch(() => {
    });
  }
  var scanThrottled = false;
  function throttledReportState() {
    if (scanThrottled) return;
    scanThrottled = true;
    setTimeout(() => {
      scanThrottled = false;
    }, 1e3);
    reportState();
  }
  var observer = new MutationObserver(throttledReportState);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  reportState();
  var pendingBatch = [];
  var flushTimer = null;
  var BATCH_DELAY_MS = 2e3;
  function flushBatch() {
    flushTimer = null;
    if (pendingBatch.length === 0) return;
    const items = pendingBatch;
    pendingBatch = [];
    console.log(`[Conector WhatsApp] mandando ${items.length} mensagem(ns) pro service worker`);
    const message = { type: "new-messages", items };
    chrome.runtime.sendMessage(message).catch((e) => {
      console.warn("[Conector WhatsApp] falha ao mandar mensagem pro service worker:", e);
    });
  }
  var pendingSendResolvers = /* @__PURE__ */ new Map();
  function requestSend(chatId, text) {
    return new Promise((resolve) => {
      const requestId = crypto.randomUUID();
      pendingSendResolvers.set(requestId, resolve);
      window.postMessage({ source: ISOLATED_SOURCE, type: "send-reply", chatId, text, requestId }, window.location.origin);
      setTimeout(() => {
        if (pendingSendResolvers.has(requestId)) {
          pendingSendResolvers.delete(requestId);
          resolve({ ok: false, error: "timeout" });
        }
      }, 15e3);
    });
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const data = event.data;
    if (data?.source !== MAIN_WORLD_SOURCE) return;
    if (data.type === "whatsapp-message") {
      const { phone, chatId, isLid, realPhone, contactName, body, ts, adId, adSourceUrl, adTitle } = data;
      if (typeof phone !== "string" || typeof chatId !== "string" || typeof body !== "string") return;
      pendingBatch.push({
        phone,
        chatId,
        isLid: isLid === true,
        realPhone: typeof realPhone === "string" ? realPhone : null,
        contactName: typeof contactName === "string" ? contactName : null,
        body,
        ts: typeof ts === "number" ? ts : Date.now(),
        adId: typeof adId === "string" ? adId : null,
        adSourceUrl: typeof adSourceUrl === "string" ? adSourceUrl : null,
        adTitle: typeof adTitle === "string" ? adTitle : null
      });
      if (!flushTimer) flushTimer = setTimeout(flushBatch, BATCH_DELAY_MS);
      return;
    }
    if (data.type === "send-result") {
      const requestId = data.requestId;
      if (typeof requestId !== "string") return;
      const resolver = pendingSendResolvers.get(requestId);
      if (!resolver) return;
      pendingSendResolvers.delete(requestId);
      resolver({ ok: data.ok === true, error: typeof data.error === "string" ? data.error : void 0 });
    }
  });
  var POLL_INTERVAL_MS = 5e3;
  var pollInFlight = false;
  async function pollPendingReplies() {
    if (pollInFlight) return;
    pollInFlight = true;
    try {
      const stored = await chrome.storage.local.get("auth");
      const auth = stored.auth;
      if (!auth) return;
      const res = await fetch(`${PLATFORM_BASE_URL}/api/integrations/whatsapp-extension/pending-replies`, {
        headers: { Authorization: `Bearer ${auth.deviceToken}` }
      });
      if (!res.ok) return;
      const data = await res.json().catch(() => null);
      if (!data?.replies?.length) return;
      for (const reply of data.replies) {
        const result = await requestSend(reply.chatId, reply.text);
        await fetch(`${PLATFORM_BASE_URL}/api/integrations/whatsapp-extension/pending-replies/ack`, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.deviceToken}` },
          body: JSON.stringify({ id: reply.id, ok: result.ok, error: result.error })
        }).catch(() => {
        });
      }
    } catch {
    } finally {
      pollInFlight = false;
    }
  }
  setInterval(pollPendingReplies, POLL_INTERVAL_MS);
  pollPendingReplies();
})();
//# sourceMappingURL=content-script.js.map
