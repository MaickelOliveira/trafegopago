"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/@wppconnect/wa-js/dist/wppconnect-wa.js
  var require_wppconnect_wa = __commonJS({
    "node_modules/@wppconnect/wa-js/dist/wppconnect-wa.js"(exports, module) {
      (() => {
        var __webpack_modules__ = { 67526(e, t) {
          "use strict";
          t.toByteArray = function(e2) {
            var t2, r2, i2 = s(e2), a2 = i2[0], u2 = i2[1], c2 = new o(function(e3, t3, r3) {
              return 3 * (t3 + r3) / 4 - r3;
            }(0, a2, u2)), l = 0, d = u2 > 0 ? a2 - 4 : a2;
            for (r2 = 0; r2 < d; r2 += 4) t2 = n[e2.charCodeAt(r2)] << 18 | n[e2.charCodeAt(r2 + 1)] << 12 | n[e2.charCodeAt(r2 + 2)] << 6 | n[e2.charCodeAt(r2 + 3)], c2[l++] = t2 >> 16 & 255, c2[l++] = t2 >> 8 & 255, c2[l++] = 255 & t2;
            2 === u2 && (t2 = n[e2.charCodeAt(r2)] << 2 | n[e2.charCodeAt(r2 + 1)] >> 4, c2[l++] = 255 & t2);
            1 === u2 && (t2 = n[e2.charCodeAt(r2)] << 10 | n[e2.charCodeAt(r2 + 1)] << 4 | n[e2.charCodeAt(r2 + 2)] >> 2, c2[l++] = t2 >> 8 & 255, c2[l++] = 255 & t2);
            return c2;
          }, t.fromByteArray = function(e2) {
            for (var t2, n2 = e2.length, o2 = n2 % 3, i2 = [], a2 = 16383, s2 = 0, u2 = n2 - o2; s2 < u2; s2 += a2) i2.push(c(e2, s2, s2 + a2 > u2 ? u2 : s2 + a2));
            1 === o2 ? (t2 = e2[n2 - 1], i2.push(r[t2 >> 2] + r[t2 << 4 & 63] + "==")) : 2 === o2 && (t2 = (e2[n2 - 2] << 8) + e2[n2 - 1], i2.push(r[t2 >> 10] + r[t2 >> 4 & 63] + r[t2 << 2 & 63] + "="));
            return i2.join("");
          };
          for (var r = [], n = [], o = "undefined" != typeof Uint8Array ? Uint8Array : Array, i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", a = 0; a < 64; ++a) r[a] = i[a], n[i.charCodeAt(a)] = a;
          function s(e2) {
            var t2 = e2.length;
            if (t2 % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
            var r2 = e2.indexOf("=");
            return -1 === r2 && (r2 = t2), [r2, r2 === t2 ? 0 : 4 - r2 % 4];
          }
          function u(e2) {
            return r[e2 >> 18 & 63] + r[e2 >> 12 & 63] + r[e2 >> 6 & 63] + r[63 & e2];
          }
          function c(e2, t2, r2) {
            for (var n2, o2 = [], i2 = t2; i2 < r2; i2 += 3) n2 = (e2[i2] << 16 & 16711680) + (e2[i2 + 1] << 8 & 65280) + (255 & e2[i2 + 2]), o2.push(u(n2));
            return o2.join("");
          }
          n["-".charCodeAt(0)] = 62, n["_".charCodeAt(0)] = 63;
        }, 48287(e, t, r) {
          "use strict";
          const n = r(67526), o = r(251), i = "function" == typeof Symbol && "function" == typeof Symbol.for ? Symbol.for("nodejs.util.inspect.custom") : null;
          t.hp = u, t.IS = 50;
          const a = 2147483647;
          function s(e2) {
            if (e2 > a) throw new RangeError('The value "' + e2 + '" is invalid for option "size"');
            const t2 = new Uint8Array(e2);
            return Object.setPrototypeOf(t2, u.prototype), t2;
          }
          function u(e2, t2, r2) {
            if ("number" == typeof e2) {
              if ("string" == typeof t2) throw new TypeError('The "string" argument must be of type string. Received type number');
              return d(e2);
            }
            return c(e2, t2, r2);
          }
          function c(e2, t2, r2) {
            if ("string" == typeof e2) return function(e3, t3) {
              "string" == typeof t3 && "" !== t3 || (t3 = "utf8");
              if (!u.isEncoding(t3)) throw new TypeError("Unknown encoding: " + t3);
              const r3 = 0 | m(e3, t3);
              let n3 = s(r3);
              const o3 = n3.write(e3, t3);
              o3 !== r3 && (n3 = n3.slice(0, o3));
              return n3;
            }(e2, t2);
            if (ArrayBuffer.isView(e2)) return function(e3) {
              if (H(e3, Uint8Array)) {
                const t3 = new Uint8Array(e3);
                return p(t3.buffer, t3.byteOffset, t3.byteLength);
              }
              return f(e3);
            }(e2);
            if (null == e2) throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e2);
            if (H(e2, ArrayBuffer) || e2 && H(e2.buffer, ArrayBuffer)) return p(e2, t2, r2);
            if ("undefined" != typeof SharedArrayBuffer && (H(e2, SharedArrayBuffer) || e2 && H(e2.buffer, SharedArrayBuffer))) return p(e2, t2, r2);
            if ("number" == typeof e2) throw new TypeError('The "value" argument must not be of type number. Received type number');
            const n2 = e2.valueOf && e2.valueOf();
            if (null != n2 && n2 !== e2) return u.from(n2, t2, r2);
            const o2 = function(e3) {
              if (u.isBuffer(e3)) {
                const t3 = 0 | g(e3.length), r3 = s(t3);
                return 0 === r3.length || e3.copy(r3, 0, 0, t3), r3;
              }
              if (void 0 !== e3.length) return "number" != typeof e3.length || Q(e3.length) ? s(0) : f(e3);
              if ("Buffer" === e3.type && Array.isArray(e3.data)) return f(e3.data);
            }(e2);
            if (o2) return o2;
            if ("undefined" != typeof Symbol && null != Symbol.toPrimitive && "function" == typeof e2[Symbol.toPrimitive]) return u.from(e2[Symbol.toPrimitive]("string"), t2, r2);
            throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e2);
          }
          function l(e2) {
            if ("number" != typeof e2) throw new TypeError('"size" argument must be of type number');
            if (e2 < 0) throw new RangeError('The value "' + e2 + '" is invalid for option "size"');
          }
          function d(e2) {
            return l(e2), s(e2 < 0 ? 0 : 0 | g(e2));
          }
          function f(e2) {
            const t2 = e2.length < 0 ? 0 : 0 | g(e2.length), r2 = s(t2);
            for (let n2 = 0; n2 < t2; n2 += 1) r2[n2] = 255 & e2[n2];
            return r2;
          }
          function p(e2, t2, r2) {
            if (t2 < 0 || e2.byteLength < t2) throw new RangeError('"offset" is outside of buffer bounds');
            if (e2.byteLength < t2 + (r2 || 0)) throw new RangeError('"length" is outside of buffer bounds');
            let n2;
            return n2 = void 0 === t2 && void 0 === r2 ? new Uint8Array(e2) : void 0 === r2 ? new Uint8Array(e2, t2) : new Uint8Array(e2, t2, r2), Object.setPrototypeOf(n2, u.prototype), n2;
          }
          function g(e2) {
            if (e2 >= a) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + a.toString(16) + " bytes");
            return 0 | e2;
          }
          function m(e2, t2) {
            if (u.isBuffer(e2)) return e2.length;
            if (ArrayBuffer.isView(e2) || H(e2, ArrayBuffer)) return e2.byteLength;
            if ("string" != typeof e2) throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof e2);
            const r2 = e2.length, n2 = arguments.length > 2 && true === arguments[2];
            if (!n2 && 0 === r2) return 0;
            let o2 = false;
            for (; ; ) switch (t2) {
              case "ascii":
              case "latin1":
              case "binary":
                return r2;
              case "utf8":
              case "utf-8":
                return $(e2).length;
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return 2 * r2;
              case "hex":
                return r2 >>> 1;
              case "base64":
                return J(e2).length;
              default:
                if (o2) return n2 ? -1 : $(e2).length;
                t2 = ("" + t2).toLowerCase(), o2 = true;
            }
          }
          function y(e2, t2, r2) {
            let n2 = false;
            if ((void 0 === t2 || t2 < 0) && (t2 = 0), t2 > this.length) return "";
            if ((void 0 === r2 || r2 > this.length) && (r2 = this.length), r2 <= 0) return "";
            if ((r2 >>>= 0) <= (t2 >>>= 0)) return "";
            for (e2 || (e2 = "utf8"); ; ) switch (e2) {
              case "hex":
                return A(this, t2, r2);
              case "utf8":
              case "utf-8":
                return S(this, t2, r2);
              case "ascii":
                return x(this, t2, r2);
              case "latin1":
              case "binary":
                return I(this, t2, r2);
              case "base64":
                return j(this, t2, r2);
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return E(this, t2, r2);
              default:
                if (n2) throw new TypeError("Unknown encoding: " + e2);
                e2 = (e2 + "").toLowerCase(), n2 = true;
            }
          }
          function v(e2, t2, r2) {
            const n2 = e2[t2];
            e2[t2] = e2[r2], e2[r2] = n2;
          }
          function b(e2, t2, r2, n2, o2) {
            if (0 === e2.length) return -1;
            if ("string" == typeof r2 ? (n2 = r2, r2 = 0) : r2 > 2147483647 ? r2 = 2147483647 : r2 < -2147483648 && (r2 = -2147483648), Q(r2 = +r2) && (r2 = o2 ? 0 : e2.length - 1), r2 < 0 && (r2 = e2.length + r2), r2 >= e2.length) {
              if (o2) return -1;
              r2 = e2.length - 1;
            } else if (r2 < 0) {
              if (!o2) return -1;
              r2 = 0;
            }
            if ("string" == typeof t2 && (t2 = u.from(t2, n2)), u.isBuffer(t2)) return 0 === t2.length ? -1 : h(e2, t2, r2, n2, o2);
            if ("number" == typeof t2) return t2 &= 255, "function" == typeof Uint8Array.prototype.indexOf ? o2 ? Uint8Array.prototype.indexOf.call(e2, t2, r2) : Uint8Array.prototype.lastIndexOf.call(e2, t2, r2) : h(e2, [t2], r2, n2, o2);
            throw new TypeError("val must be string, number or Buffer");
          }
          function h(e2, t2, r2, n2, o2) {
            let i2, a2 = 1, s2 = e2.length, u2 = t2.length;
            if (void 0 !== n2 && ("ucs2" === (n2 = String(n2).toLowerCase()) || "ucs-2" === n2 || "utf16le" === n2 || "utf-16le" === n2)) {
              if (e2.length < 2 || t2.length < 2) return -1;
              a2 = 2, s2 /= 2, u2 /= 2, r2 /= 2;
            }
            function c2(e3, t3) {
              return 1 === a2 ? e3[t3] : e3.readUInt16BE(t3 * a2);
            }
            if (o2) {
              let n3 = -1;
              for (i2 = r2; i2 < s2; i2++) if (c2(e2, i2) === c2(t2, -1 === n3 ? 0 : i2 - n3)) {
                if (-1 === n3 && (n3 = i2), i2 - n3 + 1 === u2) return n3 * a2;
              } else -1 !== n3 && (i2 -= i2 - n3), n3 = -1;
            } else for (r2 + u2 > s2 && (r2 = s2 - u2), i2 = r2; i2 >= 0; i2--) {
              let r3 = true;
              for (let n3 = 0; n3 < u2; n3++) if (c2(e2, i2 + n3) !== c2(t2, n3)) {
                r3 = false;
                break;
              }
              if (r3) return i2;
            }
            return -1;
          }
          function _(e2, t2, r2, n2) {
            r2 = Number(r2) || 0;
            const o2 = e2.length - r2;
            n2 ? (n2 = Number(n2)) > o2 && (n2 = o2) : n2 = o2;
            const i2 = t2.length;
            let a2;
            for (n2 > i2 / 2 && (n2 = i2 / 2), a2 = 0; a2 < n2; ++a2) {
              const n3 = parseInt(t2.substr(2 * a2, 2), 16);
              if (Q(n3)) return a2;
              e2[r2 + a2] = n3;
            }
            return a2;
          }
          function P(e2, t2, r2, n2) {
            return K($(t2, e2.length - r2), e2, r2, n2);
          }
          function M(e2, t2, r2, n2) {
            return K(function(e3) {
              const t3 = [];
              for (let r3 = 0; r3 < e3.length; ++r3) t3.push(255 & e3.charCodeAt(r3));
              return t3;
            }(t2), e2, r2, n2);
          }
          function w(e2, t2, r2, n2) {
            return K(J(t2), e2, r2, n2);
          }
          function O(e2, t2, r2, n2) {
            return K(function(e3, t3) {
              let r3, n3, o2;
              const i2 = [];
              for (let a2 = 0; a2 < e3.length && !((t3 -= 2) < 0); ++a2) r3 = e3.charCodeAt(a2), n3 = r3 >> 8, o2 = r3 % 256, i2.push(o2), i2.push(n3);
              return i2;
            }(t2, e2.length - r2), e2, r2, n2);
          }
          function j(e2, t2, r2) {
            return 0 === t2 && r2 === e2.length ? n.fromByteArray(e2) : n.fromByteArray(e2.slice(t2, r2));
          }
          function S(e2, t2, r2) {
            r2 = Math.min(e2.length, r2);
            const n2 = [];
            let o2 = t2;
            for (; o2 < r2; ) {
              const t3 = e2[o2];
              let i2 = null, a2 = t3 > 239 ? 4 : t3 > 223 ? 3 : t3 > 191 ? 2 : 1;
              if (o2 + a2 <= r2) {
                let r3, n3, s2, u2;
                switch (a2) {
                  case 1:
                    t3 < 128 && (i2 = t3);
                    break;
                  case 2:
                    r3 = e2[o2 + 1], 128 == (192 & r3) && (u2 = (31 & t3) << 6 | 63 & r3, u2 > 127 && (i2 = u2));
                    break;
                  case 3:
                    r3 = e2[o2 + 1], n3 = e2[o2 + 2], 128 == (192 & r3) && 128 == (192 & n3) && (u2 = (15 & t3) << 12 | (63 & r3) << 6 | 63 & n3, u2 > 2047 && (u2 < 55296 || u2 > 57343) && (i2 = u2));
                    break;
                  case 4:
                    r3 = e2[o2 + 1], n3 = e2[o2 + 2], s2 = e2[o2 + 3], 128 == (192 & r3) && 128 == (192 & n3) && 128 == (192 & s2) && (u2 = (15 & t3) << 18 | (63 & r3) << 12 | (63 & n3) << 6 | 63 & s2, u2 > 65535 && u2 < 1114112 && (i2 = u2));
                }
              }
              null === i2 ? (i2 = 65533, a2 = 1) : i2 > 65535 && (i2 -= 65536, n2.push(i2 >>> 10 & 1023 | 55296), i2 = 56320 | 1023 & i2), n2.push(i2), o2 += a2;
            }
            return function(e3) {
              const t3 = e3.length;
              if (t3 <= C) return String.fromCharCode.apply(String, e3);
              let r3 = "", n3 = 0;
              for (; n3 < t3; ) r3 += String.fromCharCode.apply(String, e3.slice(n3, n3 += C));
              return r3;
            }(n2);
          }
          u.TYPED_ARRAY_SUPPORT = function() {
            try {
              const e2 = new Uint8Array(1), t2 = { foo: function() {
                return 42;
              } };
              return Object.setPrototypeOf(t2, Uint8Array.prototype), Object.setPrototypeOf(e2, t2), 42 === e2.foo();
            } catch (e2) {
              return false;
            }
          }(), u.TYPED_ARRAY_SUPPORT || "undefined" == typeof console || "function" != typeof console.error || console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."), Object.defineProperty(u.prototype, "parent", { enumerable: true, get: function() {
            if (u.isBuffer(this)) return this.buffer;
          } }), Object.defineProperty(u.prototype, "offset", { enumerable: true, get: function() {
            if (u.isBuffer(this)) return this.byteOffset;
          } }), u.poolSize = 8192, u.from = function(e2, t2, r2) {
            return c(e2, t2, r2);
          }, Object.setPrototypeOf(u.prototype, Uint8Array.prototype), Object.setPrototypeOf(u, Uint8Array), u.alloc = function(e2, t2, r2) {
            return function(e3, t3, r3) {
              return l(e3), e3 <= 0 ? s(e3) : void 0 !== t3 ? "string" == typeof r3 ? s(e3).fill(t3, r3) : s(e3).fill(t3) : s(e3);
            }(e2, t2, r2);
          }, u.allocUnsafe = function(e2) {
            return d(e2);
          }, u.allocUnsafeSlow = function(e2) {
            return d(e2);
          }, u.isBuffer = function(e2) {
            return null != e2 && true === e2._isBuffer && e2 !== u.prototype;
          }, u.compare = function(e2, t2) {
            if (H(e2, Uint8Array) && (e2 = u.from(e2, e2.offset, e2.byteLength)), H(t2, Uint8Array) && (t2 = u.from(t2, t2.offset, t2.byteLength)), !u.isBuffer(e2) || !u.isBuffer(t2)) throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
            if (e2 === t2) return 0;
            let r2 = e2.length, n2 = t2.length;
            for (let o2 = 0, i2 = Math.min(r2, n2); o2 < i2; ++o2) if (e2[o2] !== t2[o2]) {
              r2 = e2[o2], n2 = t2[o2];
              break;
            }
            return r2 < n2 ? -1 : n2 < r2 ? 1 : 0;
          }, u.isEncoding = function(e2) {
            switch (String(e2).toLowerCase()) {
              case "hex":
              case "utf8":
              case "utf-8":
              case "ascii":
              case "latin1":
              case "binary":
              case "base64":
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return true;
              default:
                return false;
            }
          }, u.concat = function(e2, t2) {
            if (!Array.isArray(e2)) throw new TypeError('"list" argument must be an Array of Buffers');
            if (0 === e2.length) return u.alloc(0);
            let r2;
            if (void 0 === t2) for (t2 = 0, r2 = 0; r2 < e2.length; ++r2) t2 += e2[r2].length;
            const n2 = u.allocUnsafe(t2);
            let o2 = 0;
            for (r2 = 0; r2 < e2.length; ++r2) {
              let t3 = e2[r2];
              if (H(t3, Uint8Array)) o2 + t3.length > n2.length ? (u.isBuffer(t3) || (t3 = u.from(t3)), t3.copy(n2, o2)) : Uint8Array.prototype.set.call(n2, t3, o2);
              else {
                if (!u.isBuffer(t3)) throw new TypeError('"list" argument must be an Array of Buffers');
                t3.copy(n2, o2);
              }
              o2 += t3.length;
            }
            return n2;
          }, u.byteLength = m, u.prototype._isBuffer = true, u.prototype.swap16 = function() {
            const e2 = this.length;
            if (e2 % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
            for (let t2 = 0; t2 < e2; t2 += 2) v(this, t2, t2 + 1);
            return this;
          }, u.prototype.swap32 = function() {
            const e2 = this.length;
            if (e2 % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
            for (let t2 = 0; t2 < e2; t2 += 4) v(this, t2, t2 + 3), v(this, t2 + 1, t2 + 2);
            return this;
          }, u.prototype.swap64 = function() {
            const e2 = this.length;
            if (e2 % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
            for (let t2 = 0; t2 < e2; t2 += 8) v(this, t2, t2 + 7), v(this, t2 + 1, t2 + 6), v(this, t2 + 2, t2 + 5), v(this, t2 + 3, t2 + 4);
            return this;
          }, u.prototype.toString = function() {
            const e2 = this.length;
            return 0 === e2 ? "" : 0 === arguments.length ? S(this, 0, e2) : y.apply(this, arguments);
          }, u.prototype.toLocaleString = u.prototype.toString, u.prototype.equals = function(e2) {
            if (!u.isBuffer(e2)) throw new TypeError("Argument must be a Buffer");
            return this === e2 || 0 === u.compare(this, e2);
          }, u.prototype.inspect = function() {
            let e2 = "";
            const r2 = t.IS;
            return e2 = this.toString("hex", 0, r2).replace(/(.{2})/g, "$1 ").trim(), this.length > r2 && (e2 += " ... "), "<Buffer " + e2 + ">";
          }, i && (u.prototype[i] = u.prototype.inspect), u.prototype.compare = function(e2, t2, r2, n2, o2) {
            if (H(e2, Uint8Array) && (e2 = u.from(e2, e2.offset, e2.byteLength)), !u.isBuffer(e2)) throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof e2);
            if (void 0 === t2 && (t2 = 0), void 0 === r2 && (r2 = e2 ? e2.length : 0), void 0 === n2 && (n2 = 0), void 0 === o2 && (o2 = this.length), t2 < 0 || r2 > e2.length || n2 < 0 || o2 > this.length) throw new RangeError("out of range index");
            if (n2 >= o2 && t2 >= r2) return 0;
            if (n2 >= o2) return -1;
            if (t2 >= r2) return 1;
            if (this === e2) return 0;
            let i2 = (o2 >>>= 0) - (n2 >>>= 0), a2 = (r2 >>>= 0) - (t2 >>>= 0);
            const s2 = Math.min(i2, a2), c2 = this.slice(n2, o2), l2 = e2.slice(t2, r2);
            for (let e3 = 0; e3 < s2; ++e3) if (c2[e3] !== l2[e3]) {
              i2 = c2[e3], a2 = l2[e3];
              break;
            }
            return i2 < a2 ? -1 : a2 < i2 ? 1 : 0;
          }, u.prototype.includes = function(e2, t2, r2) {
            return -1 !== this.indexOf(e2, t2, r2);
          }, u.prototype.indexOf = function(e2, t2, r2) {
            return b(this, e2, t2, r2, true);
          }, u.prototype.lastIndexOf = function(e2, t2, r2) {
            return b(this, e2, t2, r2, false);
          }, u.prototype.write = function(e2, t2, r2, n2) {
            if (void 0 === t2) n2 = "utf8", r2 = this.length, t2 = 0;
            else if (void 0 === r2 && "string" == typeof t2) n2 = t2, r2 = this.length, t2 = 0;
            else {
              if (!isFinite(t2)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
              t2 >>>= 0, isFinite(r2) ? (r2 >>>= 0, void 0 === n2 && (n2 = "utf8")) : (n2 = r2, r2 = void 0);
            }
            const o2 = this.length - t2;
            if ((void 0 === r2 || r2 > o2) && (r2 = o2), e2.length > 0 && (r2 < 0 || t2 < 0) || t2 > this.length) throw new RangeError("Attempt to write outside buffer bounds");
            n2 || (n2 = "utf8");
            let i2 = false;
            for (; ; ) switch (n2) {
              case "hex":
                return _(this, e2, t2, r2);
              case "utf8":
              case "utf-8":
                return P(this, e2, t2, r2);
              case "ascii":
              case "latin1":
              case "binary":
                return M(this, e2, t2, r2);
              case "base64":
                return w(this, e2, t2, r2);
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return O(this, e2, t2, r2);
              default:
                if (i2) throw new TypeError("Unknown encoding: " + n2);
                n2 = ("" + n2).toLowerCase(), i2 = true;
            }
          }, u.prototype.toJSON = function() {
            return { type: "Buffer", data: Array.prototype.slice.call(this._arr || this, 0) };
          };
          const C = 4096;
          function x(e2, t2, r2) {
            let n2 = "";
            r2 = Math.min(e2.length, r2);
            for (let o2 = t2; o2 < r2; ++o2) n2 += String.fromCharCode(127 & e2[o2]);
            return n2;
          }
          function I(e2, t2, r2) {
            let n2 = "";
            r2 = Math.min(e2.length, r2);
            for (let o2 = t2; o2 < r2; ++o2) n2 += String.fromCharCode(e2[o2]);
            return n2;
          }
          function A(e2, t2, r2) {
            const n2 = e2.length;
            (!t2 || t2 < 0) && (t2 = 0), (!r2 || r2 < 0 || r2 > n2) && (r2 = n2);
            let o2 = "";
            for (let n3 = t2; n3 < r2; ++n3) o2 += Y[e2[n3]];
            return o2;
          }
          function E(e2, t2, r2) {
            const n2 = e2.slice(t2, r2);
            let o2 = "";
            for (let e3 = 0; e3 < n2.length - 1; e3 += 2) o2 += String.fromCharCode(n2[e3] + 256 * n2[e3 + 1]);
            return o2;
          }
          function T(e2, t2, r2) {
            if (e2 % 1 != 0 || e2 < 0) throw new RangeError("offset is not uint");
            if (e2 + t2 > r2) throw new RangeError("Trying to access beyond buffer length");
          }
          function L(e2, t2, r2, n2, o2, i2) {
            if (!u.isBuffer(e2)) throw new TypeError('"buffer" argument must be a Buffer instance');
            if (t2 > o2 || t2 < i2) throw new RangeError('"value" argument is out of bounds');
            if (r2 + n2 > e2.length) throw new RangeError("Index out of range");
          }
          function B(e2, t2, r2, n2, o2) {
            G(t2, n2, o2, e2, r2, 7);
            let i2 = Number(t2 & BigInt(4294967295));
            e2[r2++] = i2, i2 >>= 8, e2[r2++] = i2, i2 >>= 8, e2[r2++] = i2, i2 >>= 8, e2[r2++] = i2;
            let a2 = Number(t2 >> BigInt(32) & BigInt(4294967295));
            return e2[r2++] = a2, a2 >>= 8, e2[r2++] = a2, a2 >>= 8, e2[r2++] = a2, a2 >>= 8, e2[r2++] = a2, r2;
          }
          function k(e2, t2, r2, n2, o2) {
            G(t2, n2, o2, e2, r2, 7);
            let i2 = Number(t2 & BigInt(4294967295));
            e2[r2 + 7] = i2, i2 >>= 8, e2[r2 + 6] = i2, i2 >>= 8, e2[r2 + 5] = i2, i2 >>= 8, e2[r2 + 4] = i2;
            let a2 = Number(t2 >> BigInt(32) & BigInt(4294967295));
            return e2[r2 + 3] = a2, a2 >>= 8, e2[r2 + 2] = a2, a2 >>= 8, e2[r2 + 1] = a2, a2 >>= 8, e2[r2] = a2, r2 + 8;
          }
          function R(e2, t2, r2, n2, o2, i2) {
            if (r2 + n2 > e2.length) throw new RangeError("Index out of range");
            if (r2 < 0) throw new RangeError("Index out of range");
          }
          function N(e2, t2, r2, n2, i2) {
            return t2 = +t2, r2 >>>= 0, i2 || R(e2, 0, r2, 4), o.write(e2, t2, r2, n2, 23, 4), r2 + 4;
          }
          function D(e2, t2, r2, n2, i2) {
            return t2 = +t2, r2 >>>= 0, i2 || R(e2, 0, r2, 8), o.write(e2, t2, r2, n2, 52, 8), r2 + 8;
          }
          u.prototype.slice = function(e2, t2) {
            const r2 = this.length;
            (e2 = ~~e2) < 0 ? (e2 += r2) < 0 && (e2 = 0) : e2 > r2 && (e2 = r2), (t2 = void 0 === t2 ? r2 : ~~t2) < 0 ? (t2 += r2) < 0 && (t2 = 0) : t2 > r2 && (t2 = r2), t2 < e2 && (t2 = e2);
            const n2 = this.subarray(e2, t2);
            return Object.setPrototypeOf(n2, u.prototype), n2;
          }, u.prototype.readUintLE = u.prototype.readUIntLE = function(e2, t2, r2) {
            e2 >>>= 0, t2 >>>= 0, r2 || T(e2, t2, this.length);
            let n2 = this[e2], o2 = 1, i2 = 0;
            for (; ++i2 < t2 && (o2 *= 256); ) n2 += this[e2 + i2] * o2;
            return n2;
          }, u.prototype.readUintBE = u.prototype.readUIntBE = function(e2, t2, r2) {
            e2 >>>= 0, t2 >>>= 0, r2 || T(e2, t2, this.length);
            let n2 = this[e2 + --t2], o2 = 1;
            for (; t2 > 0 && (o2 *= 256); ) n2 += this[e2 + --t2] * o2;
            return n2;
          }, u.prototype.readUint8 = u.prototype.readUInt8 = function(e2, t2) {
            return e2 >>>= 0, t2 || T(e2, 1, this.length), this[e2];
          }, u.prototype.readUint16LE = u.prototype.readUInt16LE = function(e2, t2) {
            return e2 >>>= 0, t2 || T(e2, 2, this.length), this[e2] | this[e2 + 1] << 8;
          }, u.prototype.readUint16BE = u.prototype.readUInt16BE = function(e2, t2) {
            return e2 >>>= 0, t2 || T(e2, 2, this.length), this[e2] << 8 | this[e2 + 1];
          }, u.prototype.readUint32LE = u.prototype.readUInt32LE = function(e2, t2) {
            return e2 >>>= 0, t2 || T(e2, 4, this.length), (this[e2] | this[e2 + 1] << 8 | this[e2 + 2] << 16) + 16777216 * this[e2 + 3];
          }, u.prototype.readUint32BE = u.prototype.readUInt32BE = function(e2, t2) {
            return e2 >>>= 0, t2 || T(e2, 4, this.length), 16777216 * this[e2] + (this[e2 + 1] << 16 | this[e2 + 2] << 8 | this[e2 + 3]);
          }, u.prototype.readBigUInt64LE = Z(function(e2) {
            q(e2 >>>= 0, "offset");
            const t2 = this[e2], r2 = this[e2 + 7];
            void 0 !== t2 && void 0 !== r2 || V(e2, this.length - 8);
            const n2 = t2 + 256 * this[++e2] + 65536 * this[++e2] + this[++e2] * 2 ** 24, o2 = this[++e2] + 256 * this[++e2] + 65536 * this[++e2] + r2 * 2 ** 24;
            return BigInt(n2) + (BigInt(o2) << BigInt(32));
          }), u.prototype.readBigUInt64BE = Z(function(e2) {
            q(e2 >>>= 0, "offset");
            const t2 = this[e2], r2 = this[e2 + 7];
            void 0 !== t2 && void 0 !== r2 || V(e2, this.length - 8);
            const n2 = t2 * 2 ** 24 + 65536 * this[++e2] + 256 * this[++e2] + this[++e2], o2 = this[++e2] * 2 ** 24 + 65536 * this[++e2] + 256 * this[++e2] + r2;
            return (BigInt(n2) << BigInt(32)) + BigInt(o2);
          }), u.prototype.readIntLE = function(e2, t2, r2) {
            e2 >>>= 0, t2 >>>= 0, r2 || T(e2, t2, this.length);
            let n2 = this[e2], o2 = 1, i2 = 0;
            for (; ++i2 < t2 && (o2 *= 256); ) n2 += this[e2 + i2] * o2;
            return o2 *= 128, n2 >= o2 && (n2 -= Math.pow(2, 8 * t2)), n2;
          }, u.prototype.readIntBE = function(e2, t2, r2) {
            e2 >>>= 0, t2 >>>= 0, r2 || T(e2, t2, this.length);
            let n2 = t2, o2 = 1, i2 = this[e2 + --n2];
            for (; n2 > 0 && (o2 *= 256); ) i2 += this[e2 + --n2] * o2;
            return o2 *= 128, i2 >= o2 && (i2 -= Math.pow(2, 8 * t2)), i2;
          }, u.prototype.readInt8 = function(e2, t2) {
            return e2 >>>= 0, t2 || T(e2, 1, this.length), 128 & this[e2] ? -1 * (255 - this[e2] + 1) : this[e2];
          }, u.prototype.readInt16LE = function(e2, t2) {
            e2 >>>= 0, t2 || T(e2, 2, this.length);
            const r2 = this[e2] | this[e2 + 1] << 8;
            return 32768 & r2 ? 4294901760 | r2 : r2;
          }, u.prototype.readInt16BE = function(e2, t2) {
            e2 >>>= 0, t2 || T(e2, 2, this.length);
            const r2 = this[e2 + 1] | this[e2] << 8;
            return 32768 & r2 ? 4294901760 | r2 : r2;
          }, u.prototype.readInt32LE = function(e2, t2) {
            return e2 >>>= 0, t2 || T(e2, 4, this.length), this[e2] | this[e2 + 1] << 8 | this[e2 + 2] << 16 | this[e2 + 3] << 24;
          }, u.prototype.readInt32BE = function(e2, t2) {
            return e2 >>>= 0, t2 || T(e2, 4, this.length), this[e2] << 24 | this[e2 + 1] << 16 | this[e2 + 2] << 8 | this[e2 + 3];
          }, u.prototype.readBigInt64LE = Z(function(e2) {
            q(e2 >>>= 0, "offset");
            const t2 = this[e2], r2 = this[e2 + 7];
            void 0 !== t2 && void 0 !== r2 || V(e2, this.length - 8);
            const n2 = this[e2 + 4] + 256 * this[e2 + 5] + 65536 * this[e2 + 6] + (r2 << 24);
            return (BigInt(n2) << BigInt(32)) + BigInt(t2 + 256 * this[++e2] + 65536 * this[++e2] + this[++e2] * 2 ** 24);
          }), u.prototype.readBigInt64BE = Z(function(e2) {
            q(e2 >>>= 0, "offset");
            const t2 = this[e2], r2 = this[e2 + 7];
            void 0 !== t2 && void 0 !== r2 || V(e2, this.length - 8);
            const n2 = (t2 << 24) + 65536 * this[++e2] + 256 * this[++e2] + this[++e2];
            return (BigInt(n2) << BigInt(32)) + BigInt(this[++e2] * 2 ** 24 + 65536 * this[++e2] + 256 * this[++e2] + r2);
          }), u.prototype.readFloatLE = function(e2, t2) {
            return e2 >>>= 0, t2 || T(e2, 4, this.length), o.read(this, e2, true, 23, 4);
          }, u.prototype.readFloatBE = function(e2, t2) {
            return e2 >>>= 0, t2 || T(e2, 4, this.length), o.read(this, e2, false, 23, 4);
          }, u.prototype.readDoubleLE = function(e2, t2) {
            return e2 >>>= 0, t2 || T(e2, 8, this.length), o.read(this, e2, true, 52, 8);
          }, u.prototype.readDoubleBE = function(e2, t2) {
            return e2 >>>= 0, t2 || T(e2, 8, this.length), o.read(this, e2, false, 52, 8);
          }, u.prototype.writeUintLE = u.prototype.writeUIntLE = function(e2, t2, r2, n2) {
            if (e2 = +e2, t2 >>>= 0, r2 >>>= 0, !n2) {
              L(this, e2, t2, r2, Math.pow(2, 8 * r2) - 1, 0);
            }
            let o2 = 1, i2 = 0;
            for (this[t2] = 255 & e2; ++i2 < r2 && (o2 *= 256); ) this[t2 + i2] = e2 / o2 & 255;
            return t2 + r2;
          }, u.prototype.writeUintBE = u.prototype.writeUIntBE = function(e2, t2, r2, n2) {
            if (e2 = +e2, t2 >>>= 0, r2 >>>= 0, !n2) {
              L(this, e2, t2, r2, Math.pow(2, 8 * r2) - 1, 0);
            }
            let o2 = r2 - 1, i2 = 1;
            for (this[t2 + o2] = 255 & e2; --o2 >= 0 && (i2 *= 256); ) this[t2 + o2] = e2 / i2 & 255;
            return t2 + r2;
          }, u.prototype.writeUint8 = u.prototype.writeUInt8 = function(e2, t2, r2) {
            return e2 = +e2, t2 >>>= 0, r2 || L(this, e2, t2, 1, 255, 0), this[t2] = 255 & e2, t2 + 1;
          }, u.prototype.writeUint16LE = u.prototype.writeUInt16LE = function(e2, t2, r2) {
            return e2 = +e2, t2 >>>= 0, r2 || L(this, e2, t2, 2, 65535, 0), this[t2] = 255 & e2, this[t2 + 1] = e2 >>> 8, t2 + 2;
          }, u.prototype.writeUint16BE = u.prototype.writeUInt16BE = function(e2, t2, r2) {
            return e2 = +e2, t2 >>>= 0, r2 || L(this, e2, t2, 2, 65535, 0), this[t2] = e2 >>> 8, this[t2 + 1] = 255 & e2, t2 + 2;
          }, u.prototype.writeUint32LE = u.prototype.writeUInt32LE = function(e2, t2, r2) {
            return e2 = +e2, t2 >>>= 0, r2 || L(this, e2, t2, 4, 4294967295, 0), this[t2 + 3] = e2 >>> 24, this[t2 + 2] = e2 >>> 16, this[t2 + 1] = e2 >>> 8, this[t2] = 255 & e2, t2 + 4;
          }, u.prototype.writeUint32BE = u.prototype.writeUInt32BE = function(e2, t2, r2) {
            return e2 = +e2, t2 >>>= 0, r2 || L(this, e2, t2, 4, 4294967295, 0), this[t2] = e2 >>> 24, this[t2 + 1] = e2 >>> 16, this[t2 + 2] = e2 >>> 8, this[t2 + 3] = 255 & e2, t2 + 4;
          }, u.prototype.writeBigUInt64LE = Z(function(e2, t2 = 0) {
            return B(this, e2, t2, BigInt(0), BigInt("0xffffffffffffffff"));
          }), u.prototype.writeBigUInt64BE = Z(function(e2, t2 = 0) {
            return k(this, e2, t2, BigInt(0), BigInt("0xffffffffffffffff"));
          }), u.prototype.writeIntLE = function(e2, t2, r2, n2) {
            if (e2 = +e2, t2 >>>= 0, !n2) {
              const n3 = Math.pow(2, 8 * r2 - 1);
              L(this, e2, t2, r2, n3 - 1, -n3);
            }
            let o2 = 0, i2 = 1, a2 = 0;
            for (this[t2] = 255 & e2; ++o2 < r2 && (i2 *= 256); ) e2 < 0 && 0 === a2 && 0 !== this[t2 + o2 - 1] && (a2 = 1), this[t2 + o2] = (e2 / i2 | 0) - a2 & 255;
            return t2 + r2;
          }, u.prototype.writeIntBE = function(e2, t2, r2, n2) {
            if (e2 = +e2, t2 >>>= 0, !n2) {
              const n3 = Math.pow(2, 8 * r2 - 1);
              L(this, e2, t2, r2, n3 - 1, -n3);
            }
            let o2 = r2 - 1, i2 = 1, a2 = 0;
            for (this[t2 + o2] = 255 & e2; --o2 >= 0 && (i2 *= 256); ) e2 < 0 && 0 === a2 && 0 !== this[t2 + o2 + 1] && (a2 = 1), this[t2 + o2] = (e2 / i2 | 0) - a2 & 255;
            return t2 + r2;
          }, u.prototype.writeInt8 = function(e2, t2, r2) {
            return e2 = +e2, t2 >>>= 0, r2 || L(this, e2, t2, 1, 127, -128), e2 < 0 && (e2 = 255 + e2 + 1), this[t2] = 255 & e2, t2 + 1;
          }, u.prototype.writeInt16LE = function(e2, t2, r2) {
            return e2 = +e2, t2 >>>= 0, r2 || L(this, e2, t2, 2, 32767, -32768), this[t2] = 255 & e2, this[t2 + 1] = e2 >>> 8, t2 + 2;
          }, u.prototype.writeInt16BE = function(e2, t2, r2) {
            return e2 = +e2, t2 >>>= 0, r2 || L(this, e2, t2, 2, 32767, -32768), this[t2] = e2 >>> 8, this[t2 + 1] = 255 & e2, t2 + 2;
          }, u.prototype.writeInt32LE = function(e2, t2, r2) {
            return e2 = +e2, t2 >>>= 0, r2 || L(this, e2, t2, 4, 2147483647, -2147483648), this[t2] = 255 & e2, this[t2 + 1] = e2 >>> 8, this[t2 + 2] = e2 >>> 16, this[t2 + 3] = e2 >>> 24, t2 + 4;
          }, u.prototype.writeInt32BE = function(e2, t2, r2) {
            return e2 = +e2, t2 >>>= 0, r2 || L(this, e2, t2, 4, 2147483647, -2147483648), e2 < 0 && (e2 = 4294967295 + e2 + 1), this[t2] = e2 >>> 24, this[t2 + 1] = e2 >>> 16, this[t2 + 2] = e2 >>> 8, this[t2 + 3] = 255 & e2, t2 + 4;
          }, u.prototype.writeBigInt64LE = Z(function(e2, t2 = 0) {
            return B(this, e2, t2, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
          }), u.prototype.writeBigInt64BE = Z(function(e2, t2 = 0) {
            return k(this, e2, t2, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
          }), u.prototype.writeFloatLE = function(e2, t2, r2) {
            return N(this, e2, t2, true, r2);
          }, u.prototype.writeFloatBE = function(e2, t2, r2) {
            return N(this, e2, t2, false, r2);
          }, u.prototype.writeDoubleLE = function(e2, t2, r2) {
            return D(this, e2, t2, true, r2);
          }, u.prototype.writeDoubleBE = function(e2, t2, r2) {
            return D(this, e2, t2, false, r2);
          }, u.prototype.copy = function(e2, t2, r2, n2) {
            if (!u.isBuffer(e2)) throw new TypeError("argument should be a Buffer");
            if (r2 || (r2 = 0), n2 || 0 === n2 || (n2 = this.length), t2 >= e2.length && (t2 = e2.length), t2 || (t2 = 0), n2 > 0 && n2 < r2 && (n2 = r2), n2 === r2) return 0;
            if (0 === e2.length || 0 === this.length) return 0;
            if (t2 < 0) throw new RangeError("targetStart out of bounds");
            if (r2 < 0 || r2 >= this.length) throw new RangeError("Index out of range");
            if (n2 < 0) throw new RangeError("sourceEnd out of bounds");
            n2 > this.length && (n2 = this.length), e2.length - t2 < n2 - r2 && (n2 = e2.length - t2 + r2);
            const o2 = n2 - r2;
            return this === e2 && "function" == typeof Uint8Array.prototype.copyWithin ? this.copyWithin(t2, r2, n2) : Uint8Array.prototype.set.call(e2, this.subarray(r2, n2), t2), o2;
          }, u.prototype.fill = function(e2, t2, r2, n2) {
            if ("string" == typeof e2) {
              if ("string" == typeof t2 ? (n2 = t2, t2 = 0, r2 = this.length) : "string" == typeof r2 && (n2 = r2, r2 = this.length), void 0 !== n2 && "string" != typeof n2) throw new TypeError("encoding must be a string");
              if ("string" == typeof n2 && !u.isEncoding(n2)) throw new TypeError("Unknown encoding: " + n2);
              if (1 === e2.length) {
                const t3 = e2.charCodeAt(0);
                ("utf8" === n2 && t3 < 128 || "latin1" === n2) && (e2 = t3);
              }
            } else "number" == typeof e2 ? e2 &= 255 : "boolean" == typeof e2 && (e2 = Number(e2));
            if (t2 < 0 || this.length < t2 || this.length < r2) throw new RangeError("Out of range index");
            if (r2 <= t2) return this;
            let o2;
            if (t2 >>>= 0, r2 = void 0 === r2 ? this.length : r2 >>> 0, e2 || (e2 = 0), "number" == typeof e2) for (o2 = t2; o2 < r2; ++o2) this[o2] = e2;
            else {
              const i2 = u.isBuffer(e2) ? e2 : u.from(e2, n2), a2 = i2.length;
              if (0 === a2) throw new TypeError('The value "' + e2 + '" is invalid for argument "value"');
              for (o2 = 0; o2 < r2 - t2; ++o2) this[o2 + t2] = i2[o2 % a2];
            }
            return this;
          };
          const F = {};
          function W(e2, t2, r2) {
            F[e2] = class extends r2 {
              constructor() {
                super(), Object.defineProperty(this, "message", { value: t2.apply(this, arguments), writable: true, configurable: true }), this.name = `${this.name} [${e2}]`, this.stack, delete this.name;
              }
              get code() {
                return e2;
              }
              set code(e3) {
                Object.defineProperty(this, "code", { configurable: true, enumerable: true, value: e3, writable: true });
              }
              toString() {
                return `${this.name} [${e2}]: ${this.message}`;
              }
            };
          }
          function U(e2) {
            let t2 = "", r2 = e2.length;
            const n2 = "-" === e2[0] ? 1 : 0;
            for (; r2 >= n2 + 4; r2 -= 3) t2 = `_${e2.slice(r2 - 3, r2)}${t2}`;
            return `${e2.slice(0, r2)}${t2}`;
          }
          function G(e2, t2, r2, n2, o2, i2) {
            if (e2 > r2 || e2 < t2) {
              const n3 = "bigint" == typeof t2 ? "n" : "";
              let o3;
              throw o3 = i2 > 3 ? 0 === t2 || t2 === BigInt(0) ? `>= 0${n3} and < 2${n3} ** ${8 * (i2 + 1)}${n3}` : `>= -(2${n3} ** ${8 * (i2 + 1) - 1}${n3}) and < 2 ** ${8 * (i2 + 1) - 1}${n3}` : `>= ${t2}${n3} and <= ${r2}${n3}`, new F.ERR_OUT_OF_RANGE("value", o3, e2);
            }
            !function(e3, t3, r3) {
              q(t3, "offset"), void 0 !== e3[t3] && void 0 !== e3[t3 + r3] || V(t3, e3.length - (r3 + 1));
            }(n2, o2, i2);
          }
          function q(e2, t2) {
            if ("number" != typeof e2) throw new F.ERR_INVALID_ARG_TYPE(t2, "number", e2);
          }
          function V(e2, t2, r2) {
            if (Math.floor(e2) !== e2) throw q(e2, r2), new F.ERR_OUT_OF_RANGE(r2 || "offset", "an integer", e2);
            if (t2 < 0) throw new F.ERR_BUFFER_OUT_OF_BOUNDS();
            throw new F.ERR_OUT_OF_RANGE(r2 || "offset", `>= ${r2 ? 1 : 0} and <= ${t2}`, e2);
          }
          W("ERR_BUFFER_OUT_OF_BOUNDS", function(e2) {
            return e2 ? `${e2} is outside of buffer bounds` : "Attempt to access memory outside buffer bounds";
          }, RangeError), W("ERR_INVALID_ARG_TYPE", function(e2, t2) {
            return `The "${e2}" argument must be of type number. Received type ${typeof t2}`;
          }, TypeError), W("ERR_OUT_OF_RANGE", function(e2, t2, r2) {
            let n2 = `The value of "${e2}" is out of range.`, o2 = r2;
            return Number.isInteger(r2) && Math.abs(r2) > 2 ** 32 ? o2 = U(String(r2)) : "bigint" == typeof r2 && (o2 = String(r2), (r2 > BigInt(2) ** BigInt(32) || r2 < -(BigInt(2) ** BigInt(32))) && (o2 = U(o2)), o2 += "n"), n2 += ` It must be ${t2}. Received ${o2}`, n2;
          }, RangeError);
          const z = /[^+/0-9A-Za-z-_]/g;
          function $(e2, t2) {
            let r2;
            t2 = t2 || 1 / 0;
            const n2 = e2.length;
            let o2 = null;
            const i2 = [];
            for (let a2 = 0; a2 < n2; ++a2) {
              if (r2 = e2.charCodeAt(a2), r2 > 55295 && r2 < 57344) {
                if (!o2) {
                  if (r2 > 56319) {
                    (t2 -= 3) > -1 && i2.push(239, 191, 189);
                    continue;
                  }
                  if (a2 + 1 === n2) {
                    (t2 -= 3) > -1 && i2.push(239, 191, 189);
                    continue;
                  }
                  o2 = r2;
                  continue;
                }
                if (r2 < 56320) {
                  (t2 -= 3) > -1 && i2.push(239, 191, 189), o2 = r2;
                  continue;
                }
                r2 = 65536 + (o2 - 55296 << 10 | r2 - 56320);
              } else o2 && (t2 -= 3) > -1 && i2.push(239, 191, 189);
              if (o2 = null, r2 < 128) {
                if ((t2 -= 1) < 0) break;
                i2.push(r2);
              } else if (r2 < 2048) {
                if ((t2 -= 2) < 0) break;
                i2.push(r2 >> 6 | 192, 63 & r2 | 128);
              } else if (r2 < 65536) {
                if ((t2 -= 3) < 0) break;
                i2.push(r2 >> 12 | 224, r2 >> 6 & 63 | 128, 63 & r2 | 128);
              } else {
                if (!(r2 < 1114112)) throw new Error("Invalid code point");
                if ((t2 -= 4) < 0) break;
                i2.push(r2 >> 18 | 240, r2 >> 12 & 63 | 128, r2 >> 6 & 63 | 128, 63 & r2 | 128);
              }
            }
            return i2;
          }
          function J(e2) {
            return n.toByteArray(function(e3) {
              if ((e3 = (e3 = e3.split("=")[0]).trim().replace(z, "")).length < 2) return "";
              for (; e3.length % 4 != 0; ) e3 += "=";
              return e3;
            }(e2));
          }
          function K(e2, t2, r2, n2) {
            let o2;
            for (o2 = 0; o2 < n2 && !(o2 + r2 >= t2.length || o2 >= e2.length); ++o2) t2[o2 + r2] = e2[o2];
            return o2;
          }
          function H(e2, t2) {
            return e2 instanceof t2 || null != e2 && null != e2.constructor && null != e2.constructor.name && e2.constructor.name === t2.name;
          }
          function Q(e2) {
            return e2 != e2;
          }
          const Y = function() {
            const e2 = "0123456789abcdef", t2 = new Array(256);
            for (let r2 = 0; r2 < 16; ++r2) {
              const n2 = 16 * r2;
              for (let o2 = 0; o2 < 16; ++o2) t2[n2 + o2] = e2[r2] + e2[o2];
            }
            return t2;
          }();
          function Z(e2) {
            return "undefined" == typeof BigInt ? X : e2;
          }
          function X() {
            throw new Error("BigInt not supported");
          }
        }, 75828(e, t, r) {
          "use strict";
          r.d(t, { compare: () => c });
          const n = /^[v^~<>=]*?(\d+)(?:\.([x*]|\d+)(?:\.([x*]|\d+)(?:\.([x*]|\d+))?(?:-([\da-z\-]+(?:\.[\da-z\-]+)*))?(?:\+[\da-z\-]+(?:\.[\da-z\-]+)*)?)?)?$/i, o = (e2) => {
            if ("string" != typeof e2) throw new TypeError("Invalid argument expected string");
            const t2 = e2.match(n);
            if (!t2) throw new Error(`Invalid argument not valid semver ('${e2}' received)`);
            return t2.shift(), t2;
          }, i = (e2) => "*" === e2 || "x" === e2 || "X" === e2, a = (e2) => {
            const t2 = parseInt(e2, 10);
            return isNaN(t2) ? e2 : t2;
          }, s = (e2, t2) => {
            if (i(e2) || i(t2)) return 0;
            const [r2, n2] = ((e3, t3) => typeof e3 != typeof t3 ? [String(e3), String(t3)] : [e3, t3])(a(e2), a(t2));
            return r2 > n2 ? 1 : r2 < n2 ? -1 : 0;
          }, u = (e2, t2) => {
            for (let r2 = 0; r2 < Math.max(e2.length, t2.length); r2++) {
              const n2 = s(e2[r2] || "0", t2[r2] || "0");
              if (0 !== n2) return n2;
            }
            return 0;
          }, c = (e2, t2, r2) => {
            f(r2);
            const n2 = ((e3, t3) => {
              const r3 = o(e3), n3 = o(t3), i2 = r3.pop(), a2 = n3.pop(), s2 = u(r3, n3);
              return 0 !== s2 ? s2 : i2 && a2 ? u(i2.split("."), a2.split(".")) : i2 || a2 ? i2 ? -1 : 1 : 0;
            })(e2, t2);
            return l[r2].includes(n2);
          }, l = { ">": [1], ">=": [0, 1], "=": [0], "<=": [-1, 0], "<": [-1], "!=": [-1, 1] }, d = Object.keys(l), f = (e2) => {
            if ("string" != typeof e2) throw new TypeError("Invalid operator type, expected string but got " + typeof e2);
            if (-1 === d.indexOf(e2)) throw new Error(`Invalid operator, expected one of ${d.join("|")}`);
          };
        }, 23807(e) {
          e.exports = function() {
            "use strict";
            function e2(e3, t2) {
              if (!(e3 instanceof t2)) throw new TypeError("Cannot call a class as a function");
            }
            function t(e3, t2) {
              for (var r2 = 0; r2 < t2.length; r2++) {
                var n2 = t2[r2];
                n2.enumerable = n2.enumerable || false, n2.configurable = true, "value" in n2 && (n2.writable = true), Object.defineProperty(e3, u(n2.key), n2);
              }
            }
            function r(e3, r2, n2) {
              return r2 && t(e3.prototype, r2), n2 && t(e3, n2), Object.defineProperty(e3, "prototype", { writable: false }), e3;
            }
            function n(e3, t2, r2) {
              return (t2 = u(t2)) in e3 ? Object.defineProperty(e3, t2, { value: r2, enumerable: true, configurable: true, writable: true }) : e3[t2] = r2, e3;
            }
            function o() {
              return o = Object.assign ? Object.assign.bind() : function(e3) {
                for (var t2 = 1; t2 < arguments.length; t2++) {
                  var r2 = arguments[t2];
                  for (var n2 in r2) ({}).hasOwnProperty.call(r2, n2) && (e3[n2] = r2[n2]);
                }
                return e3;
              }, o.apply(null, arguments);
            }
            function i(e3, t2) {
              var r2 = Object.keys(e3);
              if (Object.getOwnPropertySymbols) {
                var n2 = Object.getOwnPropertySymbols(e3);
                t2 && (n2 = n2.filter(function(t3) {
                  return Object.getOwnPropertyDescriptor(e3, t3).enumerable;
                })), r2.push.apply(r2, n2);
              }
              return r2;
            }
            function a(e3) {
              for (var t2 = 1; t2 < arguments.length; t2++) {
                var r2 = null != arguments[t2] ? arguments[t2] : {};
                t2 % 2 ? i(Object(r2), true).forEach(function(t3) {
                  n(e3, t3, r2[t3]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e3, Object.getOwnPropertyDescriptors(r2)) : i(Object(r2)).forEach(function(t3) {
                  Object.defineProperty(e3, t3, Object.getOwnPropertyDescriptor(r2, t3));
                });
              }
              return e3;
            }
            function s(e3, t2) {
              if ("object" != typeof e3 || !e3) return e3;
              var r2 = e3[Symbol.toPrimitive];
              if (void 0 !== r2) {
                var n2 = r2.call(e3, t2 || "default");
                if ("object" != typeof n2) return n2;
                throw new TypeError("@@toPrimitive must return a primitive value.");
              }
              return ("string" === t2 ? String : Number)(e3);
            }
            function u(e3) {
              var t2 = s(e3, "string");
              return "symbol" == typeof t2 ? t2 : t2 + "";
            }
            var c = { exports: {} };
            !function(e3) {
              "undefined" != typeof window && function(t2) {
                var r2 = t2.HTMLCanvasElement && t2.HTMLCanvasElement.prototype, n2 = t2.Blob && function() {
                  try {
                    return Boolean(new Blob());
                  } catch (e4) {
                    return false;
                  }
                }(), o2 = n2 && t2.Uint8Array && function() {
                  try {
                    return 100 === new Blob([new Uint8Array(100)]).size;
                  } catch (e4) {
                    return false;
                  }
                }(), i2 = t2.BlobBuilder || t2.WebKitBlobBuilder || t2.MozBlobBuilder || t2.MSBlobBuilder, a2 = /^data:((.*?)(;charset=.*?)?)(;base64)?,/, s2 = (n2 || i2) && t2.atob && t2.ArrayBuffer && t2.Uint8Array && function(e4) {
                  var t3, r3, s3, u2, c2, l2, d2, f2, p2;
                  if (!(t3 = e4.match(a2))) throw new Error("invalid data URI");
                  for (r3 = t3[2] ? t3[1] : "text/plain" + (t3[3] || ";charset=US-ASCII"), s3 = !!t3[4], u2 = e4.slice(t3[0].length), c2 = s3 ? atob(u2) : decodeURIComponent(u2), l2 = new ArrayBuffer(c2.length), d2 = new Uint8Array(l2), f2 = 0; f2 < c2.length; f2 += 1) d2[f2] = c2.charCodeAt(f2);
                  return n2 ? new Blob([o2 ? d2 : l2], { type: r3 }) : ((p2 = new i2()).append(l2), p2.getBlob(r3));
                };
                t2.HTMLCanvasElement && !r2.toBlob && (r2.mozGetAsFile ? r2.toBlob = function(e4, t3, n3) {
                  var o3 = this;
                  setTimeout(function() {
                    n3 && r2.toDataURL && s2 ? e4(s2(o3.toDataURL(t3, n3))) : e4(o3.mozGetAsFile("blob", t3));
                  });
                } : r2.toDataURL && s2 && (r2.msToBlob ? r2.toBlob = function(e4, t3, n3) {
                  var o3 = this;
                  setTimeout(function() {
                    (t3 && "image/png" !== t3 || n3) && r2.toDataURL && s2 ? e4(s2(o3.toDataURL(t3, n3))) : e4(o3.msToBlob(t3));
                  });
                } : r2.toBlob = function(e4, t3, r3) {
                  var n3 = this;
                  setTimeout(function() {
                    e4(s2(n3.toDataURL(t3, r3)));
                  });
                })), e3.exports ? e3.exports = s2 : t2.dataURLtoBlob = s2;
              }(window);
            }(c);
            var l = c.exports, d = function(e3) {
              return "undefined" != typeof Blob && (e3 instanceof Blob || "[object Blob]" === Object.prototype.toString.call(e3));
            }, f = { strict: true, checkOrientation: true, retainExif: false, maxWidth: 1 / 0, maxHeight: 1 / 0, minWidth: 0, minHeight: 0, width: void 0, height: void 0, resize: "none", quality: 0.8, mimeType: "auto", convertTypes: ["image/png"], convertSize: 5e6, beforeDraw: null, drew: null, success: null, error: null }, p = "undefined" != typeof window && void 0 !== window.document ? window : {}, g = function(e3) {
              return e3 > 0 && e3 < 1 / 0;
            }, m = Array.prototype.slice;
            function y(e3) {
              return Array.from ? Array.from(e3) : m.call(e3);
            }
            var v = /^image\/.+$/;
            function b(e3) {
              return v.test(e3);
            }
            function h(e3) {
              var t2 = b(e3) ? e3.substr(6) : "";
              return "jpeg" === t2 && (t2 = "jpg"), ".".concat(t2);
            }
            var _ = String.fromCharCode;
            function P(e3, t2, r2) {
              var n2, o2 = "";
              for (r2 += t2, n2 = t2; n2 < r2; n2 += 1) o2 += _(e3.getUint8(n2));
              return o2;
            }
            function M() {
              try {
                var e3 = document.createElement("canvas");
                e3.width = 2, e3.height = 1;
                var t2 = e3.getContext("2d");
                if (!t2) return false;
                var r2 = t2.createImageData(2, 1);
                r2.data[0] = 12, r2.data[1] = 23, r2.data[2] = 34, r2.data[3] = 255, r2.data[4] = 45, r2.data[5] = 56, r2.data[6] = 67, r2.data[7] = 255, t2.putImageData(r2, 0, 0);
                var n2 = t2.getImageData(0, 0, 2, 1), o2 = [12, 23, 34, 255, 45, 56, 67, 255];
                return n2.data.every(function(e4, t3) {
                  return e4 === o2[t3];
                });
              } catch (e4) {
                return false;
              }
            }
            var w = p.btoa;
            function O(e3, t2) {
              for (var r2 = [], n2 = 8192, o2 = new Uint8Array(e3); o2.length > 0; ) r2.push(_.apply(null, y(o2.subarray(0, n2)))), o2 = o2.subarray(n2);
              return "data:".concat(t2, ";base64,").concat(w(r2.join("")));
            }
            function j(e3) {
              var t2, r2 = new DataView(e3);
              try {
                var n2, o2, i2;
                if (255 === r2.getUint8(0) && 216 === r2.getUint8(1)) for (var a2 = r2.byteLength, s2 = 2; s2 + 1 < a2; ) {
                  if (255 === r2.getUint8(s2) && 225 === r2.getUint8(s2 + 1)) {
                    o2 = s2;
                    break;
                  }
                  s2 += 1;
                }
                if (o2) {
                  var u2 = o2 + 10;
                  if ("Exif" === P(r2, o2 + 4, 4)) {
                    var c2 = r2.getUint16(u2);
                    if (((n2 = 18761 === c2) || 19789 === c2) && 42 === r2.getUint16(u2 + 2, n2)) {
                      var l2 = r2.getUint32(u2 + 4, n2);
                      l2 >= 8 && (i2 = u2 + l2);
                    }
                  }
                }
                if (i2) {
                  var d2, f2, p2 = r2.getUint16(i2, n2);
                  for (f2 = 0; f2 < p2; f2 += 1) if (d2 = i2 + 12 * f2 + 2, 274 === r2.getUint16(d2, n2)) {
                    d2 += 8, t2 = r2.getUint16(d2, n2), r2.setUint16(d2, 1, n2);
                    break;
                  }
                }
              } catch (e4) {
                t2 = 1;
              }
              return t2;
            }
            function S(e3) {
              var t2 = 0, r2 = 1, n2 = 1;
              switch (e3) {
                case 2:
                  r2 = -1;
                  break;
                case 3:
                  t2 = -180;
                  break;
                case 4:
                  n2 = -1;
                  break;
                case 5:
                  t2 = 90, n2 = -1;
                  break;
                case 6:
                  t2 = 90;
                  break;
                case 7:
                  t2 = 90, r2 = -1;
                  break;
                case 8:
                  t2 = -90;
              }
              return { rotate: t2, scaleX: r2, scaleY: n2 };
            }
            var C = /\.\d*(?:0|9){12}\d*$/;
            function x(e3) {
              var t2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1e11;
              return C.test(e3) ? Math.round(e3 * t2) / t2 : e3;
            }
            function I(e3) {
              var t2 = e3.aspectRatio, r2 = e3.height, n2 = e3.width, o2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "none", i2 = g(n2), a2 = g(r2);
              if (i2 && a2) {
                var s2 = r2 * t2;
                ("contain" === o2 || "none" === o2) && s2 > n2 || "cover" === o2 && s2 < n2 ? r2 = n2 / t2 : n2 = r2 * t2;
              } else i2 ? r2 = n2 / t2 : a2 && (n2 = r2 * t2);
              return { width: n2, height: r2 };
            }
            function A(e3) {
              for (var t2 = y(new Uint8Array(e3)), r2 = t2.length, n2 = [], o2 = 0; o2 + 3 < r2; ) {
                var i2 = t2[o2], a2 = t2[o2 + 1];
                if (255 === i2 && 218 === a2) break;
                if (255 === i2 && 216 === a2) o2 += 2;
                else {
                  var s2 = o2 + (256 * t2[o2 + 2] + t2[o2 + 3]) + 2, u2 = t2.slice(o2, s2);
                  n2.push(u2), o2 = s2;
                }
              }
              return n2.reduce(function(e4, t3) {
                return 255 === t3[0] && 225 === t3[1] ? e4.concat(t3) : e4;
              }, []);
            }
            function E(e3, t2) {
              var r2 = y(new Uint8Array(e3));
              if (255 !== r2[2] || 224 !== r2[3]) return e3;
              var n2 = 256 * r2[4] + r2[5], o2 = [255, 216].concat(t2, r2.slice(4 + n2));
              return new Uint8Array(o2);
            }
            var T = p.ArrayBuffer, L = p.FileReader, B = p.URL || p.webkitURL, k = /\.\w+$/, R = p.Compressor;
            return function() {
              function t2(r2, n2) {
                e2(this, t2), this.file = r2, this.exif = [], this.image = new Image(), this.options = a(a({}, f), n2), this.aborted = false, this.result = null, this.init();
              }
              return r(t2, [{ key: "init", value: function() {
                var e3 = this, t3 = this.file, r2 = this.options;
                if (d(t3)) {
                  var n2 = t3.type;
                  if (b(n2)) if (B && L) {
                    T || (r2.checkOrientation = false, r2.retainExif = false);
                    var i2 = "image/jpeg" === n2, a2 = i2 && r2.checkOrientation, s2 = i2 && r2.retainExif;
                    if (!B || a2 || s2) {
                      var u2 = new L();
                      this.reader = u2, u2.onload = function(r3) {
                        var i3 = r3.target.result, u3 = {}, c2 = 1;
                        a2 && (c2 = j(i3)) > 1 && o(u3, S(c2)), s2 && (e3.exif = A(i3)), u3.url = a2 || s2 ? !B || c2 > 1 ? O(i3, n2) : B.createObjectURL(t3) : i3, e3.load(u3);
                      }, u2.onabort = function() {
                        e3.fail(new Error("Aborted to read the image with FileReader."));
                      }, u2.onerror = function() {
                        e3.fail(new Error("Failed to read the image with FileReader."));
                      }, u2.onloadend = function() {
                        e3.reader = null;
                      }, a2 || s2 ? u2.readAsArrayBuffer(t3) : u2.readAsDataURL(t3);
                    } else this.load({ url: B.createObjectURL(t3) });
                  } else this.fail(new Error("The current browser does not support image compression."));
                  else this.fail(new Error("The first argument must be an image File or Blob object."));
                } else this.fail(new Error("The first argument must be a File or Blob object."));
              } }, { key: "load", value: function(e3) {
                var t3 = this, r2 = this.file, n2 = this.image;
                n2.onload = function() {
                  M() ? t3.draw(a(a({}, e3), {}, { naturalWidth: n2.naturalWidth, naturalHeight: n2.naturalHeight })) : t3.done({ naturalWidth: n2.naturalWidth, naturalHeight: n2.naturalHeight, result: null });
                }, n2.onabort = function() {
                  t3.fail(new Error("Aborted to load the image."));
                }, n2.onerror = function() {
                  t3.fail(new Error("Failed to load the image."));
                }, p.navigator && /(?:iPad|iPhone|iPod).*?AppleWebKit/i.test(p.navigator.userAgent) && (n2.crossOrigin = "anonymous"), n2.alt = r2.name, n2.src = e3.url;
              } }, { key: "draw", value: function(e3) {
                var t3 = this, r2 = e3.naturalWidth, n2 = e3.naturalHeight, o2 = e3.rotate, i2 = void 0 === o2 ? 0 : o2, a2 = e3.scaleX, s2 = void 0 === a2 ? 1 : a2, u2 = e3.scaleY, c2 = void 0 === u2 ? 1 : u2, d2 = this.file, f2 = this.image, p2 = this.options, m2 = document.createElement("canvas"), y2 = m2.getContext("2d"), v2 = Math.abs(i2) % 180 == 90, h2 = ("contain" === p2.resize || "cover" === p2.resize) && g(p2.width) && g(p2.height), _2 = Math.max(p2.maxWidth, 0) || 1 / 0, P2 = Math.max(p2.maxHeight, 0) || 1 / 0, M2 = Math.max(p2.minWidth, 0) || 0, w2 = Math.max(p2.minHeight, 0) || 0, j2 = r2 / n2, S2 = p2.width, C2 = p2.height;
                if (v2) {
                  var A2 = [P2, _2];
                  _2 = A2[0], P2 = A2[1];
                  var T2 = [w2, M2];
                  M2 = T2[0], w2 = T2[1];
                  var B2 = [C2, S2];
                  S2 = B2[0], C2 = B2[1];
                }
                h2 && (j2 = S2 / C2);
                var k2 = I({ aspectRatio: j2, width: _2, height: P2 }, "contain");
                _2 = k2.width, P2 = k2.height;
                var R2 = I({ aspectRatio: j2, width: M2, height: w2 }, "cover");
                if (M2 = R2.width, w2 = R2.height, h2) {
                  var N = I({ aspectRatio: j2, width: S2, height: C2 }, p2.resize);
                  S2 = N.width, C2 = N.height;
                } else {
                  var D = I({ aspectRatio: j2, width: S2, height: C2 }), F = D.width;
                  S2 = void 0 === F ? r2 : F;
                  var W = D.height;
                  C2 = void 0 === W ? n2 : W;
                }
                var U = -(S2 = Math.floor(x(Math.min(Math.max(S2, M2), _2)))) / 2, G = -(C2 = Math.floor(x(Math.min(Math.max(C2, w2), P2)))) / 2, q = S2, V = C2, z = [];
                if (h2) {
                  var $ = 0, J = 0, K = r2, H = n2, Q = I({ aspectRatio: j2, width: r2, height: n2 }, { contain: "cover", cover: "contain" }[p2.resize]);
                  K = Q.width, H = Q.height, $ = (r2 - K) / 2, J = (n2 - H) / 2, z.push($, J, K, H);
                }
                if (z.push(U, G, q, V), v2) {
                  var Y = [C2, S2];
                  S2 = Y[0], C2 = Y[1];
                }
                m2.width = S2, m2.height = C2, b(p2.mimeType) || (p2.mimeType = d2.type);
                var Z = "transparent";
                d2.size > p2.convertSize && p2.convertTypes.indexOf(p2.mimeType) >= 0 && (p2.mimeType = "image/jpeg");
                var X = "image/jpeg" === p2.mimeType;
                if (X && (Z = "#fff"), y2.fillStyle = Z, y2.fillRect(0, 0, S2, C2), p2.beforeDraw && p2.beforeDraw.call(this, y2, m2), !this.aborted && (y2.save(), y2.translate(S2 / 2, C2 / 2), y2.rotate(i2 * Math.PI / 180), y2.scale(s2, c2), y2.drawImage.apply(y2, [f2].concat(z)), y2.restore(), p2.drew && p2.drew.call(this, y2, m2), !this.aborted)) {
                  var ee = function(e4) {
                    if (!t3.aborted) {
                      var o3 = function(e5) {
                        return t3.done({ naturalWidth: r2, naturalHeight: n2, result: e5 });
                      };
                      if (e4 && X && p2.retainExif && t3.exif && t3.exif.length > 0) {
                        var i3 = function(e5) {
                          return o3(l(O(E(e5, t3.exif), p2.mimeType)));
                        };
                        if (e4.arrayBuffer) e4.arrayBuffer().then(i3).catch(function() {
                          t3.fail(new Error("Failed to read the compressed image with Blob.arrayBuffer()."));
                        });
                        else {
                          var a3 = new L();
                          t3.reader = a3, a3.onload = function(e5) {
                            var t4 = e5.target;
                            i3(t4.result);
                          }, a3.onabort = function() {
                            t3.fail(new Error("Aborted to read the compressed image with FileReader."));
                          }, a3.onerror = function() {
                            t3.fail(new Error("Failed to read the compressed image with FileReader."));
                          }, a3.onloadend = function() {
                            t3.reader = null;
                          }, a3.readAsArrayBuffer(e4);
                        }
                      } else o3(e4);
                    }
                  };
                  m2.toBlob ? m2.toBlob(ee, p2.mimeType, p2.quality) : ee(l(m2.toDataURL(p2.mimeType, p2.quality)));
                }
              } }, { key: "done", value: function(e3) {
                var t3 = e3.naturalWidth, r2 = e3.naturalHeight, n2 = e3.result, o2 = this.file, i2 = this.image, a2 = this.options;
                if (B && 0 === i2.src.indexOf("blob:") && B.revokeObjectURL(i2.src), n2) if (a2.strict && !a2.retainExif && n2.size > o2.size && a2.mimeType === o2.type && !(a2.width > t3 || a2.height > r2 || a2.minWidth > t3 || a2.minHeight > r2 || a2.maxWidth < t3 || a2.maxHeight < r2)) n2 = o2;
                else {
                  var s2 = o2.name;
                  s2 && n2.type !== o2.type && (s2 = s2.replace(k, h(n2.type)));
                  try {
                    n2 = new File([n2], s2, { type: n2.type });
                  } catch (e4) {
                    var u2 = /* @__PURE__ */ new Date();
                    n2.name = s2, n2.lastModified = u2.getTime(), n2.lastModifiedDate = u2;
                  }
                }
                else n2 = o2;
                this.result = n2, a2.success && a2.success.call(this, n2);
              } }, { key: "fail", value: function(e3) {
                var t3 = this.options;
                if (!t3.error) throw e3;
                t3.error.call(this, e3);
              } }, { key: "abort", value: function() {
                this.aborted || (this.aborted = true, this.reader ? this.reader.abort() : this.image.complete ? this.fail(new Error("The compression process has been aborted.")) : (this.image.onload = null, this.image.onabort()));
              } }], [{ key: "noConflict", value: function() {
                return window.Compressor = R, t2;
              } }, { key: "setDefaults", value: function(e3) {
                o(f, e3);
              } }]);
            }();
          }();
        }, 17833(e, t, r) {
          t.formatArgs = function(t2) {
            if (t2[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + t2[0] + (this.useColors ? "%c " : " ") + "+" + e.exports.humanize(this.diff), !this.useColors) return;
            const r2 = "color: " + this.color;
            t2.splice(1, 0, r2, "color: inherit");
            let n2 = 0, o = 0;
            t2[0].replace(/%[a-zA-Z%]/g, (e2) => {
              "%%" !== e2 && (n2++, "%c" === e2 && (o = n2));
            }), t2.splice(o, 0, r2);
          }, t.save = function(e2) {
            try {
              e2 ? t.storage.setItem("debug", e2) : t.storage.removeItem("debug");
            } catch (e3) {
            }
          }, t.load = function() {
            let e2;
            try {
              e2 = t.storage.getItem("debug") || t.storage.getItem("DEBUG");
            } catch (e3) {
            }
            !e2 && "undefined" != typeof process && "env" in process && (e2 = process.env.DEBUG);
            return e2;
          }, t.useColors = function() {
            if ("undefined" != typeof window && window.process && ("renderer" === window.process.type || window.process.__nwjs)) return true;
            if ("undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) return false;
            let e2;
            return "undefined" != typeof document && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || "undefined" != typeof window && window.console && (window.console.firebug || window.console.exception && window.console.table) || "undefined" != typeof navigator && navigator.userAgent && (e2 = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(e2[1], 10) >= 31 || "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
          }, t.storage = function() {
            try {
              return localStorage;
            } catch (e2) {
            }
          }(), t.destroy = /* @__PURE__ */ (() => {
            let e2 = false;
            return () => {
              e2 || (e2 = true, console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."));
            };
          })(), t.colors = ["#0000CC", "#0000FF", "#0033CC", "#0033FF", "#0066CC", "#0066FF", "#0099CC", "#0099FF", "#00CC00", "#00CC33", "#00CC66", "#00CC99", "#00CCCC", "#00CCFF", "#3300CC", "#3300FF", "#3333CC", "#3333FF", "#3366CC", "#3366FF", "#3399CC", "#3399FF", "#33CC00", "#33CC33", "#33CC66", "#33CC99", "#33CCCC", "#33CCFF", "#6600CC", "#6600FF", "#6633CC", "#6633FF", "#66CC00", "#66CC33", "#9900CC", "#9900FF", "#9933CC", "#9933FF", "#99CC00", "#99CC33", "#CC0000", "#CC0033", "#CC0066", "#CC0099", "#CC00CC", "#CC00FF", "#CC3300", "#CC3333", "#CC3366", "#CC3399", "#CC33CC", "#CC33FF", "#CC6600", "#CC6633", "#CC9900", "#CC9933", "#CCCC00", "#CCCC33", "#FF0000", "#FF0033", "#FF0066", "#FF0099", "#FF00CC", "#FF00FF", "#FF3300", "#FF3333", "#FF3366", "#FF3399", "#FF33CC", "#FF33FF", "#FF6600", "#FF6633", "#FF9900", "#FF9933", "#FFCC00", "#FFCC33"], t.log = console.debug || console.log || (() => {
          }), e.exports = r(40736)(t);
          const { formatters: n } = e.exports;
          n.j = function(e2) {
            try {
              return JSON.stringify(e2);
            } catch (e3) {
              return "[UnexpectedJSONParseError]: " + e3.message;
            }
          };
        }, 40736(e, t, r) {
          e.exports = function(e2) {
            function t2(e3) {
              let r2, o2, i, a = null;
              function s(...e4) {
                if (!s.enabled) return;
                const n2 = s, o3 = Number(/* @__PURE__ */ new Date()), i2 = o3 - (r2 || o3);
                n2.diff = i2, n2.prev = r2, n2.curr = o3, r2 = o3, e4[0] = t2.coerce(e4[0]), "string" != typeof e4[0] && e4.unshift("%O");
                let a2 = 0;
                e4[0] = e4[0].replace(/%([a-zA-Z%])/g, (r3, o4) => {
                  if ("%%" === r3) return "%";
                  a2++;
                  const i3 = t2.formatters[o4];
                  if ("function" == typeof i3) {
                    const t3 = e4[a2];
                    r3 = i3.call(n2, t3), e4.splice(a2, 1), a2--;
                  }
                  return r3;
                }), t2.formatArgs.call(n2, e4);
                (n2.log || t2.log).apply(n2, e4);
              }
              return s.namespace = e3, s.useColors = t2.useColors(), s.color = t2.selectColor(e3), s.extend = n, s.destroy = t2.destroy, Object.defineProperty(s, "enabled", { enumerable: true, configurable: false, get: () => null !== a ? a : (o2 !== t2.namespaces && (o2 = t2.namespaces, i = t2.enabled(e3)), i), set: (e4) => {
                a = e4;
              } }), "function" == typeof t2.init && t2.init(s), s;
            }
            function n(e3, r2) {
              const n2 = t2(this.namespace + (void 0 === r2 ? ":" : r2) + e3);
              return n2.log = this.log, n2;
            }
            function o(e3, t3) {
              let r2 = 0, n2 = 0, o2 = -1, i = 0;
              for (; r2 < e3.length; ) if (n2 < t3.length && (t3[n2] === e3[r2] || "*" === t3[n2])) "*" === t3[n2] ? (o2 = n2, i = r2, n2++) : (r2++, n2++);
              else {
                if (-1 === o2) return false;
                n2 = o2 + 1, i++, r2 = i;
              }
              for (; n2 < t3.length && "*" === t3[n2]; ) n2++;
              return n2 === t3.length;
            }
            return t2.debug = t2, t2.default = t2, t2.coerce = function(e3) {
              if (e3 instanceof Error) return e3.stack || e3.message;
              return e3;
            }, t2.disable = function() {
              const e3 = [...t2.names, ...t2.skips.map((e4) => "-" + e4)].join(",");
              return t2.enable(""), e3;
            }, t2.enable = function(e3) {
              t2.save(e3), t2.namespaces = e3, t2.names = [], t2.skips = [];
              const r2 = ("string" == typeof e3 ? e3 : "").trim().replace(/\s+/g, ",").split(",").filter(Boolean);
              for (const e4 of r2) "-" === e4[0] ? t2.skips.push(e4.slice(1)) : t2.names.push(e4);
            }, t2.enabled = function(e3) {
              for (const r2 of t2.skips) if (o(e3, r2)) return false;
              for (const r2 of t2.names) if (o(e3, r2)) return true;
              return false;
            }, t2.humanize = r(6585), t2.destroy = function() {
              console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
            }, Object.keys(e2).forEach((r2) => {
              t2[r2] = e2[r2];
            }), t2.names = [], t2.skips = [], t2.formatters = {}, t2.selectColor = function(e3) {
              let r2 = 0;
              for (let t3 = 0; t3 < e3.length; t3++) r2 = (r2 << 5) - r2 + e3.charCodeAt(t3), r2 |= 0;
              return t2.colors[Math.abs(r2) % t2.colors.length];
            }, t2.enable(t2.load()), t2;
          };
        }, 53011(e, t, r) {
          var n;
          !function(o) {
            var i = Object.hasOwnProperty, a = Array.isArray ? Array.isArray : function(e2) {
              return "[object Array]" === Object.prototype.toString.call(e2);
            }, s = "object" == typeof process && "function" == typeof process.nextTick, u = "function" == typeof Symbol, c = "object" == typeof Reflect, l = "function" == typeof setImmediate ? setImmediate : setTimeout, d = u ? c && "function" == typeof Reflect.ownKeys ? Reflect.ownKeys : function(e2) {
              var t2 = Object.getOwnPropertyNames(e2);
              return t2.push.apply(t2, Object.getOwnPropertySymbols(e2)), t2;
            } : Object.keys;
            function f() {
              this._events = {}, this._conf && p.call(this, this._conf);
            }
            function p(e2) {
              e2 && (this._conf = e2, e2.delimiter && (this.delimiter = e2.delimiter), e2.maxListeners !== o && (this._maxListeners = e2.maxListeners), e2.wildcard && (this.wildcard = e2.wildcard), e2.newListener && (this._newListener = e2.newListener), e2.removeListener && (this._removeListener = e2.removeListener), e2.verboseMemoryLeak && (this.verboseMemoryLeak = e2.verboseMemoryLeak), e2.ignoreErrors && (this.ignoreErrors = e2.ignoreErrors), this.wildcard && (this.listenerTree = {}));
            }
            function g(e2, t2) {
              var r2 = "(node) warning: possible EventEmitter memory leak detected. " + e2 + " listeners added. Use emitter.setMaxListeners() to increase limit.";
              if (this.verboseMemoryLeak && (r2 += " Event name: " + t2 + "."), "undefined" != typeof process && process.emitWarning) {
                var n2 = new Error(r2);
                n2.name = "MaxListenersExceededWarning", n2.emitter = this, n2.count = e2, process.emitWarning(n2);
              } else console.error(r2), console.trace && console.trace();
            }
            var m = function(e2, t2, r2) {
              var n2 = arguments.length;
              switch (n2) {
                case 0:
                  return [];
                case 1:
                  return [e2];
                case 2:
                  return [e2, t2];
                case 3:
                  return [e2, t2, r2];
                default:
                  for (var o2 = new Array(n2); n2--; ) o2[n2] = arguments[n2];
                  return o2;
              }
            };
            function y(e2, t2) {
              for (var r2 = {}, n2 = e2.length, i2 = t2 ? t2.length : 0, a2 = 0; a2 < n2; a2++) r2[e2[a2]] = a2 < i2 ? t2[a2] : o;
              return r2;
            }
            function v(e2, t2, r2) {
              var n2, o2;
              if (this._emitter = e2, this._target = t2, this._listeners = {}, this._listenersCount = 0, (r2.on || r2.off) && (n2 = r2.on, o2 = r2.off), t2.addEventListener ? (n2 = t2.addEventListener, o2 = t2.removeEventListener) : t2.addListener ? (n2 = t2.addListener, o2 = t2.removeListener) : t2.on && (n2 = t2.on, o2 = t2.off), !n2 && !o2) throw Error("target does not implement any known event API");
              if ("function" != typeof n2) throw TypeError("on method must be a function");
              if ("function" != typeof o2) throw TypeError("off method must be a function");
              this._on = n2, this._off = o2;
              var i2 = e2._observers;
              i2 ? i2.push(this) : e2._observers = [this];
            }
            function b(e2, t2, r2, n2) {
              var a2 = Object.assign({}, t2);
              if (!e2) return a2;
              if ("object" != typeof e2) throw TypeError("options must be an object");
              var s2, u2, c2, l2 = Object.keys(e2), d2 = l2.length;
              function f2(e3) {
                throw Error('Invalid "' + s2 + '" option value' + (e3 ? ". Reason: " + e3 : ""));
              }
              for (var p2 = 0; p2 < d2; p2++) {
                if (s2 = l2[p2], !n2 && !i.call(t2, s2)) throw Error('Unknown "' + s2 + '" option');
                (u2 = e2[s2]) !== o && (c2 = r2[s2], a2[s2] = c2 ? c2(u2, f2) : u2);
              }
              return a2;
            }
            function h(e2, t2) {
              return "function" == typeof e2 && e2.hasOwnProperty("prototype") || t2("value must be a constructor"), e2;
            }
            function _(e2) {
              var t2 = "value must be type of " + e2.join("|"), r2 = e2.length, n2 = e2[0], o2 = e2[1];
              return 1 === r2 ? function(e3, r3) {
                if (typeof e3 === n2) return e3;
                r3(t2);
              } : 2 === r2 ? function(e3, r3) {
                var i2 = typeof e3;
                if (i2 === n2 || i2 === o2) return e3;
                r3(t2);
              } : function(n3, o3) {
                for (var i2 = typeof n3, a2 = r2; a2-- > 0; ) if (i2 === e2[a2]) return n3;
                o3(t2);
              };
            }
            Object.assign(v.prototype, { subscribe: function(e2, t2, r2) {
              var n2 = this, o2 = this._target, i2 = this._emitter, a2 = this._listeners, s2 = function() {
                var n3 = m.apply(null, arguments), a3 = { data: n3, name: t2, original: e2 };
                r2 ? false !== r2.call(o2, a3) && i2.emit.apply(i2, [a3.name].concat(n3)) : i2.emit.apply(i2, [t2].concat(n3));
              };
              if (a2[e2]) throw Error("Event '" + e2 + "' is already listening");
              this._listenersCount++, i2._newListener && i2._removeListener && !n2._onNewListener ? (this._onNewListener = function(r3) {
                r3 === t2 && null === a2[e2] && (a2[e2] = s2, n2._on.call(o2, e2, s2));
              }, i2.on("newListener", this._onNewListener), this._onRemoveListener = function(r3) {
                r3 === t2 && !i2.hasListeners(r3) && a2[e2] && (a2[e2] = null, n2._off.call(o2, e2, s2));
              }, a2[e2] = null, i2.on("removeListener", this._onRemoveListener)) : (a2[e2] = s2, n2._on.call(o2, e2, s2));
            }, unsubscribe: function(e2) {
              var t2, r2, n2, o2 = this, i2 = this._listeners, a2 = this._emitter, s2 = this._off, u2 = this._target;
              if (e2 && "string" != typeof e2) throw TypeError("event must be a string");
              function c2() {
                o2._onNewListener && (a2.off("newListener", o2._onNewListener), a2.off("removeListener", o2._onRemoveListener), o2._onNewListener = null, o2._onRemoveListener = null);
                var e3 = O.call(a2, o2);
                a2._observers.splice(e3, 1);
              }
              if (e2) {
                if (!(t2 = i2[e2])) return;
                s2.call(u2, e2, t2), delete i2[e2], --this._listenersCount || c2();
              } else {
                for (n2 = (r2 = d(i2)).length; n2-- > 0; ) e2 = r2[n2], s2.call(u2, e2, i2[e2]);
                this._listeners = {}, this._listenersCount = 0, c2();
              }
            } });
            var P = _(["function"]), M = _(["object", "function"]);
            function w(e2, t2, r2) {
              var n2, o2, i2, a2 = 0, s2 = new e2(function(u2, c2, l2) {
                function d2() {
                  o2 && (o2 = null), a2 && (clearTimeout(a2), a2 = 0);
                }
                r2 = b(r2, { timeout: 0, overload: false }, { timeout: function(e3, t3) {
                  return ("number" != typeof (e3 *= 1) || e3 < 0 || !Number.isFinite(e3)) && t3("timeout must be a positive number"), e3;
                } }), n2 = !r2.overload && "function" == typeof e2.prototype.cancel && "function" == typeof l2;
                var f2 = function(e3) {
                  d2(), u2(e3);
                }, p2 = function(e3) {
                  d2(), c2(e3);
                };
                n2 ? t2(f2, p2, l2) : (o2 = [function(e3) {
                  p2(e3 || Error("canceled"));
                }], t2(f2, p2, function(e3) {
                  if (i2) throw Error("Unable to subscribe on cancel event asynchronously");
                  if ("function" != typeof e3) throw TypeError("onCancel callback must be a function");
                  o2.push(e3);
                }), i2 = true), r2.timeout > 0 && (a2 = setTimeout(function() {
                  var e3 = Error("timeout");
                  e3.code = "ETIMEDOUT", a2 = 0, s2.cancel(e3), c2(e3);
                }, r2.timeout));
              });
              return n2 || (s2.cancel = function(e3) {
                if (o2) {
                  for (var t3 = o2.length, r3 = 1; r3 < t3; r3++) o2[r3](e3);
                  o2[0](e3), o2 = null;
                }
              }), s2;
            }
            function O(e2) {
              var t2 = this._observers;
              if (!t2) return -1;
              for (var r2 = t2.length, n2 = 0; n2 < r2; n2++) if (t2[n2]._target === e2) return n2;
              return -1;
            }
            function j(e2, t2, r2, n2, o2) {
              if (!r2) return null;
              if (0 === n2) {
                var i2 = typeof t2;
                if ("string" === i2) {
                  var a2, s2, u2 = 0, c2 = 0, l2 = this.delimiter, f2 = l2.length;
                  if (-1 !== (s2 = t2.indexOf(l2))) {
                    a2 = new Array(5);
                    do {
                      a2[u2++] = t2.slice(c2, s2), c2 = s2 + f2;
                    } while (-1 !== (s2 = t2.indexOf(l2, c2)));
                    a2[u2++] = t2.slice(c2), t2 = a2, o2 = u2;
                  } else t2 = [t2], o2 = 1;
                } else "object" === i2 ? o2 = t2.length : (t2 = [t2], o2 = 1);
              }
              var p2, g2, m2, y2, v2, b2, h2, _2 = null, P2 = t2[n2], M2 = t2[n2 + 1];
              if (n2 === o2) r2._listeners && ("function" == typeof r2._listeners ? (e2 && e2.push(r2._listeners), _2 = [r2]) : (e2 && e2.push.apply(e2, r2._listeners), _2 = [r2]));
              else {
                if ("*" === P2) {
                  for (s2 = (b2 = d(r2)).length; s2-- > 0; ) "_listeners" !== (p2 = b2[s2]) && (h2 = j(e2, t2, r2[p2], n2 + 1, o2)) && (_2 ? _2.push.apply(_2, h2) : _2 = h2);
                  return _2;
                }
                if ("**" === P2) {
                  for ((v2 = n2 + 1 === o2 || n2 + 2 === o2 && "*" === M2) && r2._listeners && (_2 = j(e2, t2, r2, o2, o2)), s2 = (b2 = d(r2)).length; s2-- > 0; ) "_listeners" !== (p2 = b2[s2]) && ("*" === p2 || "**" === p2 ? (r2[p2]._listeners && !v2 && (h2 = j(e2, t2, r2[p2], o2, o2)) && (_2 ? _2.push.apply(_2, h2) : _2 = h2), h2 = j(e2, t2, r2[p2], n2, o2)) : h2 = j(e2, t2, r2[p2], p2 === M2 ? n2 + 2 : n2, o2), h2 && (_2 ? _2.push.apply(_2, h2) : _2 = h2));
                  return _2;
                }
                r2[P2] && (_2 = j(e2, t2, r2[P2], n2 + 1, o2));
              }
              if ((g2 = r2["*"]) && j(e2, t2, g2, n2 + 1, o2), m2 = r2["**"]) if (n2 < o2) for (m2._listeners && j(e2, t2, m2, o2, o2), s2 = (b2 = d(m2)).length; s2-- > 0; ) "_listeners" !== (p2 = b2[s2]) && (p2 === M2 ? j(e2, t2, m2[p2], n2 + 2, o2) : p2 === P2 ? j(e2, t2, m2[p2], n2 + 1, o2) : ((y2 = {})[p2] = m2[p2], j(e2, t2, { "**": y2 }, n2 + 1, o2)));
              else m2._listeners ? j(e2, t2, m2, o2, o2) : m2["*"] && m2["*"]._listeners && j(e2, t2, m2["*"], o2, o2);
              return _2;
            }
            function S(e2, t2, r2) {
              var n2, o2, i2 = 0, a2 = 0, s2 = this.delimiter, u2 = s2.length;
              if ("string" == typeof e2) if (-1 !== (n2 = e2.indexOf(s2))) {
                o2 = new Array(5);
                do {
                  o2[i2++] = e2.slice(a2, n2), a2 = n2 + u2;
                } while (-1 !== (n2 = e2.indexOf(s2, a2)));
                o2[i2++] = e2.slice(a2);
              } else o2 = [e2], i2 = 1;
              else o2 = e2, i2 = e2.length;
              if (i2 > 1) {
                for (n2 = 0; n2 + 1 < i2; n2++) if ("**" === o2[n2] && "**" === o2[n2 + 1]) return;
              }
              var c2, l2 = this.listenerTree;
              for (n2 = 0; n2 < i2; n2++) if (l2 = l2[c2 = o2[n2]] || (l2[c2] = {}), n2 === i2 - 1) return l2._listeners ? ("function" == typeof l2._listeners && (l2._listeners = [l2._listeners]), r2 ? l2._listeners.unshift(t2) : l2._listeners.push(t2), !l2._listeners.warned && this._maxListeners > 0 && l2._listeners.length > this._maxListeners && (l2._listeners.warned = true, g.call(this, l2._listeners.length, c2))) : l2._listeners = t2, true;
              return true;
            }
            function C(e2, t2, r2, n2) {
              for (var o2, i2, a2, s2, u2 = d(e2), c2 = u2.length, l2 = e2._listeners; c2-- > 0; ) o2 = e2[i2 = u2[c2]], a2 = "_listeners" === i2 ? r2 : r2 ? r2.concat(i2) : [i2], s2 = n2 || "symbol" == typeof i2, l2 && t2.push(s2 ? a2 : a2.join(this.delimiter)), "object" == typeof o2 && C.call(this, o2, t2, a2, s2);
              return t2;
            }
            function x(e2) {
              for (var t2, r2, n2, o2 = d(e2), i2 = o2.length; i2-- > 0; ) (t2 = e2[r2 = o2[i2]]) && (n2 = true, "_listeners" === r2 || x(t2) || delete e2[r2]);
              return n2;
            }
            function I(e2, t2, r2) {
              this.emitter = e2, this.event = t2, this.listener = r2;
            }
            function A(e2, t2, r2) {
              if (true === r2) i2 = true;
              else if (false === r2) n2 = true;
              else {
                if (!r2 || "object" != typeof r2) throw TypeError("options should be an object or true");
                var n2 = r2.async, i2 = r2.promisify, a2 = r2.nextTick, u2 = r2.objectify;
              }
              if (n2 || a2 || i2) {
                var c2 = t2, d2 = t2._origin || t2;
                if (a2 && !s) throw Error("process.nextTick is not supported");
                i2 === o && (i2 = "AsyncFunction" === t2.constructor.name), t2 = function() {
                  var e3 = arguments, t3 = this, r3 = this.event;
                  return i2 ? a2 ? Promise.resolve() : new Promise(function(e4) {
                    l(e4);
                  }).then(function() {
                    return t3.event = r3, c2.apply(t3, e3);
                  }) : (a2 ? process.nextTick : l)(function() {
                    t3.event = r3, c2.apply(t3, e3);
                  });
                }, t2._async = true, t2._origin = d2;
              }
              return [t2, u2 ? new I(this, e2, t2) : this];
            }
            function E(e2) {
              this._events = {}, this._newListener = false, this._removeListener = false, this.verboseMemoryLeak = false, p.call(this, e2);
            }
            I.prototype.off = function() {
              return this.emitter.off(this.event, this.listener), this;
            }, E.EventEmitter2 = E, E.prototype.listenTo = function(e2, t2, r2) {
              if ("object" != typeof e2) throw TypeError("target musts be an object");
              var n2 = this;
              function i2(t3) {
                if ("object" != typeof t3) throw TypeError("events must be an object");
                var o2, i3 = r2.reducers, a2 = O.call(n2, e2);
                o2 = -1 === a2 ? new v(n2, e2, r2) : n2._observers[a2];
                for (var s2, u2 = d(t3), c2 = u2.length, l2 = "function" == typeof i3, f2 = 0; f2 < c2; f2++) s2 = u2[f2], o2.subscribe(s2, t3[s2] || s2, l2 ? i3 : i3 && i3[s2]);
              }
              return r2 = b(r2, { on: o, off: o, reducers: o }, { on: P, off: P, reducers: M }), a(t2) ? i2(y(t2)) : i2("string" == typeof t2 ? y(t2.split(/\s+/)) : t2), this;
            }, E.prototype.stopListeningTo = function(e2, t2) {
              var r2 = this._observers;
              if (!r2) return false;
              var n2, o2 = r2.length, i2 = false;
              if (e2 && "object" != typeof e2) throw TypeError("target should be an object");
              for (; o2-- > 0; ) n2 = r2[o2], e2 && n2._target !== e2 || (n2.unsubscribe(t2), i2 = true);
              return i2;
            }, E.prototype.delimiter = ".", E.prototype.setMaxListeners = function(e2) {
              e2 !== o && (this._maxListeners = e2, this._conf || (this._conf = {}), this._conf.maxListeners = e2);
            }, E.prototype.getMaxListeners = function() {
              return this._maxListeners;
            }, E.prototype.event = "", E.prototype.once = function(e2, t2, r2) {
              return this._once(e2, t2, false, r2);
            }, E.prototype.prependOnceListener = function(e2, t2, r2) {
              return this._once(e2, t2, true, r2);
            }, E.prototype._once = function(e2, t2, r2, n2) {
              return this._many(e2, 1, t2, r2, n2);
            }, E.prototype.many = function(e2, t2, r2, n2) {
              return this._many(e2, t2, r2, false, n2);
            }, E.prototype.prependMany = function(e2, t2, r2, n2) {
              return this._many(e2, t2, r2, true, n2);
            }, E.prototype._many = function(e2, t2, r2, n2, o2) {
              var i2 = this;
              if ("function" != typeof r2) throw new Error("many only accepts instances of Function");
              function a2() {
                return 0 === --t2 && i2.off(e2, a2), r2.apply(this, arguments);
              }
              return a2._origin = r2, this._on(e2, a2, n2, o2);
            }, E.prototype.emit = function() {
              if (!this._events && !this._all) return false;
              this._events || f.call(this);
              var e2, t2, r2, n2, o2, i2, a2 = arguments[0], s2 = this.wildcard;
              if ("newListener" === a2 && !this._newListener && !this._events.newListener) return false;
              if (s2 && (e2 = a2, "newListener" !== a2 && "removeListener" !== a2 && "object" == typeof a2)) {
                if (r2 = a2.length, u) {
                  for (n2 = 0; n2 < r2; n2++) if ("symbol" == typeof a2[n2]) {
                    i2 = true;
                    break;
                  }
                }
                i2 || (a2 = a2.join(this.delimiter));
              }
              var c2, l2 = arguments.length;
              if (this._all && this._all.length) for (n2 = 0, r2 = (c2 = this._all.slice()).length; n2 < r2; n2++) switch (this.event = a2, l2) {
                case 1:
                  c2[n2].call(this, a2);
                  break;
                case 2:
                  c2[n2].call(this, a2, arguments[1]);
                  break;
                case 3:
                  c2[n2].call(this, a2, arguments[1], arguments[2]);
                  break;
                default:
                  c2[n2].apply(this, arguments);
              }
              if (s2) c2 = [], j.call(this, c2, e2, this.listenerTree, 0, r2);
              else {
                if ("function" == typeof (c2 = this._events[a2])) {
                  switch (this.event = a2, l2) {
                    case 1:
                      c2.call(this);
                      break;
                    case 2:
                      c2.call(this, arguments[1]);
                      break;
                    case 3:
                      c2.call(this, arguments[1], arguments[2]);
                      break;
                    default:
                      for (t2 = new Array(l2 - 1), o2 = 1; o2 < l2; o2++) t2[o2 - 1] = arguments[o2];
                      c2.apply(this, t2);
                  }
                  return true;
                }
                c2 && (c2 = c2.slice());
              }
              if (c2 && c2.length) {
                if (l2 > 3) for (t2 = new Array(l2 - 1), o2 = 1; o2 < l2; o2++) t2[o2 - 1] = arguments[o2];
                for (n2 = 0, r2 = c2.length; n2 < r2; n2++) switch (this.event = a2, l2) {
                  case 1:
                    c2[n2].call(this);
                    break;
                  case 2:
                    c2[n2].call(this, arguments[1]);
                    break;
                  case 3:
                    c2[n2].call(this, arguments[1], arguments[2]);
                    break;
                  default:
                    c2[n2].apply(this, t2);
                }
                return true;
              }
              if (!this.ignoreErrors && !this._all && "error" === a2) throw arguments[1] instanceof Error ? arguments[1] : new Error("Uncaught, unspecified 'error' event.");
              return !!this._all;
            }, E.prototype.emitAsync = function() {
              if (!this._events && !this._all) return false;
              this._events || f.call(this);
              var e2, t2, r2, n2, o2, i2, a2 = arguments[0], s2 = this.wildcard;
              if ("newListener" === a2 && !this._newListener && !this._events.newListener) return Promise.resolve([false]);
              if (s2 && (e2 = a2, "newListener" !== a2 && "removeListener" !== a2 && "object" == typeof a2)) {
                if (n2 = a2.length, u) {
                  for (o2 = 0; o2 < n2; o2++) if ("symbol" == typeof a2[o2]) {
                    t2 = true;
                    break;
                  }
                }
                t2 || (a2 = a2.join(this.delimiter));
              }
              var c2, l2 = [], d2 = arguments.length;
              if (this._all) for (o2 = 0, n2 = this._all.length; o2 < n2; o2++) switch (this.event = a2, d2) {
                case 1:
                  l2.push(this._all[o2].call(this, a2));
                  break;
                case 2:
                  l2.push(this._all[o2].call(this, a2, arguments[1]));
                  break;
                case 3:
                  l2.push(this._all[o2].call(this, a2, arguments[1], arguments[2]));
                  break;
                default:
                  l2.push(this._all[o2].apply(this, arguments));
              }
              if (s2 ? (c2 = [], j.call(this, c2, e2, this.listenerTree, 0)) : c2 = this._events[a2], "function" == typeof c2) switch (this.event = a2, d2) {
                case 1:
                  l2.push(c2.call(this));
                  break;
                case 2:
                  l2.push(c2.call(this, arguments[1]));
                  break;
                case 3:
                  l2.push(c2.call(this, arguments[1], arguments[2]));
                  break;
                default:
                  for (r2 = new Array(d2 - 1), i2 = 1; i2 < d2; i2++) r2[i2 - 1] = arguments[i2];
                  l2.push(c2.apply(this, r2));
              }
              else if (c2 && c2.length) {
                if (c2 = c2.slice(), d2 > 3) for (r2 = new Array(d2 - 1), i2 = 1; i2 < d2; i2++) r2[i2 - 1] = arguments[i2];
                for (o2 = 0, n2 = c2.length; o2 < n2; o2++) switch (this.event = a2, d2) {
                  case 1:
                    l2.push(c2[o2].call(this));
                    break;
                  case 2:
                    l2.push(c2[o2].call(this, arguments[1]));
                    break;
                  case 3:
                    l2.push(c2[o2].call(this, arguments[1], arguments[2]));
                    break;
                  default:
                    l2.push(c2[o2].apply(this, r2));
                }
              } else if (!this.ignoreErrors && !this._all && "error" === a2) return arguments[1] instanceof Error ? Promise.reject(arguments[1]) : Promise.reject("Uncaught, unspecified 'error' event.");
              return Promise.all(l2);
            }, E.prototype.on = function(e2, t2, r2) {
              return this._on(e2, t2, false, r2);
            }, E.prototype.prependListener = function(e2, t2, r2) {
              return this._on(e2, t2, true, r2);
            }, E.prototype.onAny = function(e2) {
              return this._onAny(e2, false);
            }, E.prototype.prependAny = function(e2) {
              return this._onAny(e2, true);
            }, E.prototype.addListener = E.prototype.on, E.prototype._onAny = function(e2, t2) {
              if ("function" != typeof e2) throw new Error("onAny only accepts instances of Function");
              return this._all || (this._all = []), t2 ? this._all.unshift(e2) : this._all.push(e2), this;
            }, E.prototype._on = function(e2, t2, r2, n2) {
              if ("function" == typeof e2) return this._onAny(e2, t2), this;
              if ("function" != typeof t2) throw new Error("on only accepts instances of Function");
              this._events || f.call(this);
              var i2, a2 = this;
              return n2 !== o && (t2 = (i2 = A.call(this, e2, t2, n2))[0], a2 = i2[1]), this._newListener && this.emit("newListener", e2, t2), this.wildcard ? (S.call(this, e2, t2, r2), a2) : (this._events[e2] ? ("function" == typeof this._events[e2] && (this._events[e2] = [this._events[e2]]), r2 ? this._events[e2].unshift(t2) : this._events[e2].push(t2), !this._events[e2].warned && this._maxListeners > 0 && this._events[e2].length > this._maxListeners && (this._events[e2].warned = true, g.call(this, this._events[e2].length, e2))) : this._events[e2] = t2, a2);
            }, E.prototype.off = function(e2, t2) {
              if ("function" != typeof t2) throw new Error("removeListener only takes instances of Function");
              var r2, n2 = [];
              if (this.wildcard) {
                var o2 = "string" == typeof e2 ? e2.split(this.delimiter) : e2.slice();
                if (!(n2 = j.call(this, null, o2, this.listenerTree, 0))) return this;
              } else {
                if (!this._events[e2]) return this;
                r2 = this._events[e2], n2.push({ _listeners: r2 });
              }
              for (var i2 = 0; i2 < n2.length; i2++) {
                var s2 = n2[i2];
                if (r2 = s2._listeners, a(r2)) {
                  for (var u2 = -1, c2 = 0, l2 = r2.length; c2 < l2; c2++) if (r2[c2] === t2 || r2[c2].listener && r2[c2].listener === t2 || r2[c2]._origin && r2[c2]._origin === t2) {
                    u2 = c2;
                    break;
                  }
                  if (u2 < 0) continue;
                  return this.wildcard ? s2._listeners.splice(u2, 1) : this._events[e2].splice(u2, 1), 0 === r2.length && (this.wildcard ? delete s2._listeners : delete this._events[e2]), this._removeListener && this.emit("removeListener", e2, t2), this;
                }
                (r2 === t2 || r2.listener && r2.listener === t2 || r2._origin && r2._origin === t2) && (this.wildcard ? delete s2._listeners : delete this._events[e2], this._removeListener && this.emit("removeListener", e2, t2));
              }
              return this.listenerTree && x(this.listenerTree), this;
            }, E.prototype.offAny = function(e2) {
              var t2, r2 = 0, n2 = 0;
              if (e2 && this._all && this._all.length > 0) {
                for (r2 = 0, n2 = (t2 = this._all).length; r2 < n2; r2++) if (e2 === t2[r2]) return t2.splice(r2, 1), this._removeListener && this.emit("removeListenerAny", e2), this;
              } else {
                if (t2 = this._all, this._removeListener) for (r2 = 0, n2 = t2.length; r2 < n2; r2++) this.emit("removeListenerAny", t2[r2]);
                this._all = [];
              }
              return this;
            }, E.prototype.removeListener = E.prototype.off, E.prototype.removeAllListeners = function(e2) {
              if (e2 === o) return !this._events || f.call(this), this;
              if (this.wildcard) {
                var t2, r2 = j.call(this, null, e2, this.listenerTree, 0);
                if (!r2) return this;
                for (t2 = 0; t2 < r2.length; t2++) r2[t2]._listeners = null;
                this.listenerTree && x(this.listenerTree);
              } else this._events && (this._events[e2] = null);
              return this;
            }, E.prototype.listeners = function(e2) {
              var t2, r2, n2, i2, a2, s2 = this._events;
              if (e2 === o) {
                if (this.wildcard) throw Error("event name required for wildcard emitter");
                if (!s2) return [];
                for (i2 = (t2 = d(s2)).length, n2 = []; i2-- > 0; ) "function" == typeof (r2 = s2[t2[i2]]) ? n2.push(r2) : n2.push.apply(n2, r2);
                return n2;
              }
              if (this.wildcard) {
                if (!(a2 = this.listenerTree)) return [];
                var u2 = [], c2 = "string" == typeof e2 ? e2.split(this.delimiter) : e2.slice();
                return j.call(this, u2, c2, a2, 0), u2;
              }
              return s2 && (r2 = s2[e2]) ? "function" == typeof r2 ? [r2] : r2 : [];
            }, E.prototype.eventNames = function(e2) {
              var t2 = this._events;
              return this.wildcard ? C.call(this, this.listenerTree, [], null, e2) : t2 ? d(t2) : [];
            }, E.prototype.listenerCount = function(e2) {
              return this.listeners(e2).length;
            }, E.prototype.hasListeners = function(e2) {
              if (this.wildcard) {
                var t2 = [], r2 = "string" == typeof e2 ? e2.split(this.delimiter) : e2.slice();
                return j.call(this, t2, r2, this.listenerTree, 0), t2.length > 0;
              }
              var n2 = this._events, i2 = this._all;
              return !!(i2 && i2.length || n2 && (e2 === o ? d(n2).length : n2[e2]));
            }, E.prototype.listenersAny = function() {
              return this._all ? this._all : [];
            }, E.prototype.waitFor = function(e2, t2) {
              var r2 = this, n2 = typeof t2;
              return "number" === n2 ? t2 = { timeout: t2 } : "function" === n2 && (t2 = { filter: t2 }), w((t2 = b(t2, { timeout: 0, filter: o, handleError: false, Promise, overload: false }, { filter: P, Promise: h })).Promise, function(n3, o2, i2) {
                function a2() {
                  var i3 = t2.filter;
                  if (!i3 || i3.apply(r2, arguments)) if (r2.off(e2, a2), t2.handleError) {
                    var s2 = arguments[0];
                    s2 ? o2(s2) : n3(m.apply(null, arguments).slice(1));
                  } else n3(m.apply(null, arguments));
                }
                i2(function() {
                  r2.off(e2, a2);
                }), r2._on(e2, a2, false);
              }, { timeout: t2.timeout, overload: t2.overload });
            };
            var T = E.prototype;
            Object.defineProperties(E, { defaultMaxListeners: { get: function() {
              return T._maxListeners;
            }, set: function(e2) {
              if ("number" != typeof e2 || e2 < 0 || Number.isNaN(e2)) throw TypeError("n must be a non-negative number");
              T._maxListeners = e2;
            }, enumerable: true }, once: { value: function(e2, t2, r2) {
              return w((r2 = b(r2, { Promise, timeout: 0, overload: false }, { Promise: h })).Promise, function(r3, n2, o2) {
                var i2;
                if ("function" == typeof e2.addEventListener) return i2 = function() {
                  r3(m.apply(null, arguments));
                }, o2(function() {
                  e2.removeEventListener(t2, i2);
                }), void e2.addEventListener(t2, i2, { once: true });
                var a2, s2 = function() {
                  a2 && e2.removeListener("error", a2), r3(m.apply(null, arguments));
                };
                "error" !== t2 && (a2 = function(r4) {
                  e2.removeListener(t2, s2), n2(r4);
                }, e2.once("error", a2)), o2(function() {
                  a2 && e2.removeListener("error", a2), e2.removeListener(t2, s2);
                }), e2.once(t2, s2);
              }, { timeout: r2.timeout, overload: r2.overload });
            }, writable: true, configurable: true } }), Object.defineProperties(T, { _maxListeners: { value: 10, writable: true, configurable: true }, _observers: { value: null, writable: true, configurable: true } }), (n = function() {
              return E;
            }.call(t, r, t, e)) === o || (e.exports = n);
          }();
        }, 5707(module, __unused_webpack_exports, __webpack_require__) {
          "use strict";
          var Buffer = __webpack_require__(48287).hp;
          const Token = __webpack_require__(44266), strtok3 = __webpack_require__(96452), { stringToBytes, tarHeaderChecksumMatches, uint32SyncSafeToken } = __webpack_require__(86760), supported = __webpack_require__(71664), minimumBytes = 4100;
          async function fromStream(e) {
            const t = await strtok3.fromStream(e);
            try {
              return await fromTokenizer(t);
            } finally {
              await t.close();
            }
          }
          async function fromBuffer(e) {
            if (!(e instanceof Uint8Array || e instanceof ArrayBuffer || Buffer.isBuffer(e))) throw new TypeError(`Expected the \`input\` argument to be of type \`Uint8Array\` or \`Buffer\` or \`ArrayBuffer\`, got \`${typeof e}\``);
            const t = e instanceof Buffer ? e : Buffer.from(e);
            if (!(t && t.length > 1)) return;
            return fromTokenizer(strtok3.fromBuffer(t));
          }
          function _check(e, t, r) {
            r = { offset: 0, ...r };
            for (const [n, o] of t.entries()) if (r.mask) {
              if (o !== (r.mask[n] & e[n + r.offset])) return false;
            } else if (o !== e[n + r.offset]) return false;
            return true;
          }
          async function fromTokenizer(e) {
            try {
              return _fromTokenizer(e);
            } catch (e2) {
              if (!(e2 instanceof strtok3.EndOfStreamError)) throw e2;
            }
          }
          async function _fromTokenizer(e) {
            let t = Buffer.alloc(minimumBytes);
            const r = (e2, r2) => _check(t, e2, r2), n = (e2, t2) => r(stringToBytes(e2), t2);
            if (e.fileInfo.size || (e.fileInfo.size = Number.MAX_SAFE_INTEGER), await e.peekBuffer(t, { length: 12, mayBeLess: true }), r([66, 77])) return { ext: "bmp", mime: "image/bmp" };
            if (r([11, 119])) return { ext: "ac3", mime: "audio/vnd.dolby.dd-raw" };
            if (r([120, 1])) return { ext: "dmg", mime: "application/x-apple-diskimage" };
            if (r([77, 90])) return { ext: "exe", mime: "application/x-msdownload" };
            if (r([37, 33])) return await e.peekBuffer(t, { length: 24, mayBeLess: true }), n("PS-Adobe-", { offset: 2 }) && n(" EPSF-", { offset: 14 }) ? { ext: "eps", mime: "application/eps" } : { ext: "ps", mime: "application/postscript" };
            if (r([31, 160]) || r([31, 157])) return { ext: "Z", mime: "application/x-compress" };
            if (r([255, 216, 255])) return { ext: "jpg", mime: "image/jpeg" };
            if (r([73, 73, 188])) return { ext: "jxr", mime: "image/vnd.ms-photo" };
            if (r([31, 139, 8])) return { ext: "gz", mime: "application/gzip" };
            if (r([66, 90, 104])) return { ext: "bz2", mime: "application/x-bzip2" };
            if (n("ID3")) {
              await e.ignore(6);
              const o = await e.readToken(uint32SyncSafeToken);
              return e.position + o > e.fileInfo.size ? { ext: "mp3", mime: "audio/mpeg" } : (await e.ignore(o), fromTokenizer(e));
            }
            if (n("MP+")) return { ext: "mpc", mime: "audio/x-musepack" };
            if ((67 === t[0] || 70 === t[0]) && r([87, 83], { offset: 1 })) return { ext: "swf", mime: "application/x-shockwave-flash" };
            if (r([71, 73, 70])) return { ext: "gif", mime: "image/gif" };
            if (n("FLIF")) return { ext: "flif", mime: "image/flif" };
            if (n("8BPS")) return { ext: "psd", mime: "image/vnd.adobe.photoshop" };
            if (n("WEBP", { offset: 8 })) return { ext: "webp", mime: "image/webp" };
            if (n("MPCK")) return { ext: "mpc", mime: "audio/x-musepack" };
            if (n("FORM")) return { ext: "aif", mime: "audio/aiff" };
            if (n("icns", { offset: 0 })) return { ext: "icns", mime: "image/icns" };
            if (r([80, 75, 3, 4])) {
              try {
                for (; e.position + 30 < e.fileInfo.size; ) {
                  await e.readBuffer(t, { length: 30 });
                  const i = { compressedSize: t.readUInt32LE(18), uncompressedSize: t.readUInt32LE(22), filenameLength: t.readUInt16LE(26), extraFieldLength: t.readUInt16LE(28) };
                  if (i.filename = await e.readToken(new Token.StringType(i.filenameLength, "utf-8")), await e.ignore(i.extraFieldLength), "META-INF/mozilla.rsa" === i.filename) return { ext: "xpi", mime: "application/x-xpinstall" };
                  if (i.filename.endsWith(".rels") || i.filename.endsWith(".xml")) {
                    switch (i.filename.split("/")[0]) {
                      case "_rels":
                      default:
                        break;
                      case "word":
                        return { ext: "docx", mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" };
                      case "ppt":
                        return { ext: "pptx", mime: "application/vnd.openxmlformats-officedocument.presentationml.presentation" };
                      case "xl":
                        return { ext: "xlsx", mime: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" };
                    }
                  }
                  if (i.filename.startsWith("xl/")) return { ext: "xlsx", mime: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" };
                  if (i.filename.startsWith("3D/") && i.filename.endsWith(".model")) return { ext: "3mf", mime: "model/3mf" };
                  if ("mimetype" === i.filename && i.compressedSize === i.uncompressedSize) {
                    switch (await e.readToken(new Token.StringType(i.compressedSize, "utf-8"))) {
                      case "application/epub+zip":
                        return { ext: "epub", mime: "application/epub+zip" };
                      case "application/vnd.oasis.opendocument.text":
                        return { ext: "odt", mime: "application/vnd.oasis.opendocument.text" };
                      case "application/vnd.oasis.opendocument.spreadsheet":
                        return { ext: "ods", mime: "application/vnd.oasis.opendocument.spreadsheet" };
                      case "application/vnd.oasis.opendocument.presentation":
                        return { ext: "odp", mime: "application/vnd.oasis.opendocument.presentation" };
                    }
                  }
                  if (0 === i.compressedSize) {
                    let a = -1;
                    for (; a < 0 && e.position < e.fileInfo.size; ) await e.peekBuffer(t, { mayBeLess: true }), a = t.indexOf("504B0304", 0, "hex"), await e.ignore(a >= 0 ? a : t.length);
                  } else await e.ignore(i.compressedSize);
                }
              } catch (s) {
                if (!(s instanceof strtok3.EndOfStreamError)) throw s;
              }
              return { ext: "zip", mime: "application/zip" };
            }
            if (n("OggS")) {
              await e.ignore(28);
              const u = Buffer.alloc(8);
              return await e.readBuffer(u), _check(u, [79, 112, 117, 115, 72, 101, 97, 100]) ? { ext: "opus", mime: "audio/opus" } : _check(u, [128, 116, 104, 101, 111, 114, 97]) ? { ext: "ogv", mime: "video/ogg" } : _check(u, [1, 118, 105, 100, 101, 111, 0]) ? { ext: "ogm", mime: "video/ogg" } : _check(u, [127, 70, 76, 65, 67]) ? { ext: "oga", mime: "audio/ogg" } : _check(u, [83, 112, 101, 101, 120, 32, 32]) ? { ext: "spx", mime: "audio/ogg" } : _check(u, [1, 118, 111, 114, 98, 105, 115]) ? { ext: "ogg", mime: "audio/ogg" } : { ext: "ogx", mime: "application/ogg" };
            }
            if (r([80, 75]) && (3 === t[2] || 5 === t[2] || 7 === t[2]) && (4 === t[3] || 6 === t[3] || 8 === t[3])) return { ext: "zip", mime: "application/zip" };
            if (n("ftyp", { offset: 4 }) && 96 & t[8]) {
              const c = t.toString("binary", 8, 12).replace("\0", " ").trim();
              switch (c) {
                case "avif":
                  return { ext: "avif", mime: "image/avif" };
                case "mif1":
                  return { ext: "heic", mime: "image/heif" };
                case "msf1":
                  return { ext: "heic", mime: "image/heif-sequence" };
                case "heic":
                case "heix":
                  return { ext: "heic", mime: "image/heic" };
                case "hevc":
                case "hevx":
                  return { ext: "heic", mime: "image/heic-sequence" };
                case "qt":
                  return { ext: "mov", mime: "video/quicktime" };
                case "M4V":
                case "M4VH":
                case "M4VP":
                  return { ext: "m4v", mime: "video/x-m4v" };
                case "M4P":
                  return { ext: "m4p", mime: "video/mp4" };
                case "M4B":
                  return { ext: "m4b", mime: "audio/mp4" };
                case "M4A":
                  return { ext: "m4a", mime: "audio/x-m4a" };
                case "F4V":
                  return { ext: "f4v", mime: "video/mp4" };
                case "F4P":
                  return { ext: "f4p", mime: "video/mp4" };
                case "F4A":
                  return { ext: "f4a", mime: "audio/mp4" };
                case "F4B":
                  return { ext: "f4b", mime: "audio/mp4" };
                case "crx":
                  return { ext: "cr3", mime: "image/x-canon-cr3" };
                default:
                  return c.startsWith("3g") ? c.startsWith("3g2") ? { ext: "3g2", mime: "video/3gpp2" } : { ext: "3gp", mime: "video/3gpp" } : { ext: "mp4", mime: "video/mp4" };
              }
            }
            if (n("MThd")) return { ext: "mid", mime: "audio/midi" };
            if (n("wOFF") && (r([0, 1, 0, 0], { offset: 4 }) || n("OTTO", { offset: 4 }))) return { ext: "woff", mime: "font/woff" };
            if (n("wOF2") && (r([0, 1, 0, 0], { offset: 4 }) || n("OTTO", { offset: 4 }))) return { ext: "woff2", mime: "font/woff2" };
            if (r([212, 195, 178, 161]) || r([161, 178, 195, 212])) return { ext: "pcap", mime: "application/vnd.tcpdump.pcap" };
            if (n("DSD ")) return { ext: "dsf", mime: "audio/x-dsf" };
            if (n("LZIP")) return { ext: "lz", mime: "application/x-lzip" };
            if (n("fLaC")) return { ext: "flac", mime: "audio/x-flac" };
            if (r([66, 80, 71, 251])) return { ext: "bpg", mime: "image/bpg" };
            if (n("wvpk")) return { ext: "wv", mime: "audio/wavpack" };
            if (n("%PDF")) {
              await e.ignore(1350);
              const l = 10485760, d = Buffer.alloc(Math.min(l, e.fileInfo.size));
              return await e.readBuffer(d, { mayBeLess: true }), d.includes(Buffer.from("AIPrivateData")) ? { ext: "ai", mime: "application/postscript" } : { ext: "pdf", mime: "application/pdf" };
            }
            if (r([0, 97, 115, 109])) return { ext: "wasm", mime: "application/wasm" };
            if (r([73, 73, 42, 0])) return n("CR", { offset: 8 }) ? { ext: "cr2", mime: "image/x-canon-cr2" } : r([28, 0, 254, 0], { offset: 8 }) || r([31, 0, 11, 0], { offset: 8 }) ? { ext: "nef", mime: "image/x-nikon-nef" } : r([8, 0, 0, 0], { offset: 4 }) && (r([45, 0, 254, 0], { offset: 8 }) || r([39, 0, 254, 0], { offset: 8 })) ? { ext: "dng", mime: "image/x-adobe-dng" } : (t = Buffer.alloc(24), await e.peekBuffer(t), (r([16, 251, 134, 1], { offset: 4 }) || r([8, 0, 0, 0], { offset: 4 })) && r([0, 254, 0, 4, 0, 1, 0, 0, 0, 1, 0, 0, 0, 3, 1], { offset: 9 }) ? { ext: "arw", mime: "image/x-sony-arw" } : { ext: "tif", mime: "image/tiff" });
            if (r([77, 77, 0, 42])) return { ext: "tif", mime: "image/tiff" };
            if (n("MAC ")) return { ext: "ape", mime: "audio/ape" };
            if (r([26, 69, 223, 163])) {
              async function f() {
                const t2 = await e.peekNumber(Token.UINT8);
                let r2 = 128, n2 = 0;
                for (; 0 === (t2 & r2) && 0 !== r2; ) ++n2, r2 >>= 1;
                const o = Buffer.alloc(n2 + 1);
                return await e.readBuffer(o), o;
              }
              async function p() {
                const e2 = await f(), t2 = await f();
                t2[0] ^= 128 >> t2.length - 1;
                const r2 = Math.min(6, t2.length);
                return { id: e2.readUIntBE(0, e2.length), len: t2.readUIntBE(t2.length - r2, r2) };
              }
              async function g(t2, r2) {
                for (; r2 > 0; ) {
                  const t3 = await p();
                  if (17026 === t3.id) return e.readToken(new Token.StringType(t3.len, "utf-8"));
                  await e.ignore(t3.len), --r2;
                }
              }
              const m = await p();
              switch (await g(0, m.len)) {
                case "webm":
                  return { ext: "webm", mime: "video/webm" };
                case "matroska":
                  return { ext: "mkv", mime: "video/x-matroska" };
                default:
                  return;
              }
            }
            if (r([82, 73, 70, 70])) {
              if (r([65, 86, 73], { offset: 8 })) return { ext: "avi", mime: "video/vnd.avi" };
              if (r([87, 65, 86, 69], { offset: 8 })) return { ext: "wav", mime: "audio/vnd.wave" };
              if (r([81, 76, 67, 77], { offset: 8 })) return { ext: "qcp", mime: "audio/qcelp" };
            }
            if (n("SQLi")) return { ext: "sqlite", mime: "application/x-sqlite3" };
            if (r([78, 69, 83, 26])) return { ext: "nes", mime: "application/x-nintendo-nes-rom" };
            if (n("Cr24")) return { ext: "crx", mime: "application/x-google-chrome-extension" };
            if (n("MSCF") || n("ISc(")) return { ext: "cab", mime: "application/vnd.ms-cab-compressed" };
            if (r([237, 171, 238, 219])) return { ext: "rpm", mime: "application/x-rpm" };
            if (r([197, 208, 211, 198])) return { ext: "eps", mime: "application/eps" };
            if (r([40, 181, 47, 253])) return { ext: "zst", mime: "application/zstd" };
            if (r([79, 84, 84, 79, 0])) return { ext: "otf", mime: "font/otf" };
            if (n("#!AMR")) return { ext: "amr", mime: "audio/amr" };
            if (n("{\\rtf")) return { ext: "rtf", mime: "application/rtf" };
            if (r([70, 76, 86, 1])) return { ext: "flv", mime: "video/x-flv" };
            if (n("IMPM")) return { ext: "it", mime: "audio/x-it" };
            if (n("-lh0-", { offset: 2 }) || n("-lh1-", { offset: 2 }) || n("-lh2-", { offset: 2 }) || n("-lh3-", { offset: 2 }) || n("-lh4-", { offset: 2 }) || n("-lh5-", { offset: 2 }) || n("-lh6-", { offset: 2 }) || n("-lh7-", { offset: 2 }) || n("-lzs-", { offset: 2 }) || n("-lz4-", { offset: 2 }) || n("-lz5-", { offset: 2 }) || n("-lhd-", { offset: 2 })) return { ext: "lzh", mime: "application/x-lzh-compressed" };
            if (r([0, 0, 1, 186])) {
              if (r([33], { offset: 4, mask: [241] })) return { ext: "mpg", mime: "video/MP1S" };
              if (r([68], { offset: 4, mask: [196] })) return { ext: "mpg", mime: "video/MP2P" };
            }
            if (n("ITSF")) return { ext: "chm", mime: "application/vnd.ms-htmlhelp" };
            if (r([253, 55, 122, 88, 90, 0])) return { ext: "xz", mime: "application/x-xz" };
            if (n("<?xml ")) return { ext: "xml", mime: "application/xml" };
            if (r([55, 122, 188, 175, 39, 28])) return { ext: "7z", mime: "application/x-7z-compressed" };
            if (r([82, 97, 114, 33, 26, 7]) && (0 === t[6] || 1 === t[6])) return { ext: "rar", mime: "application/x-rar-compressed" };
            if (n("solid ")) return { ext: "stl", mime: "model/stl" };
            if (n("BLENDER")) return { ext: "blend", mime: "application/x-blender" };
            if (n("!<arch>")) {
              await e.ignore(8);
              return "debian-binary" === await e.readToken(new Token.StringType(13, "ascii")) ? { ext: "deb", mime: "application/x-deb" } : { ext: "ar", mime: "application/x-unix-archive" };
            }
            if (r([137, 80, 78, 71, 13, 10, 26, 10])) {
              async function y() {
                return { length: await e.readToken(Token.INT32_BE), type: await e.readToken(new Token.StringType(4, "binary")) };
              }
              await e.ignore(8);
              do {
                const v = await y();
                if (v.length < 0) return;
                switch (v.type) {
                  case "IDAT":
                    return { ext: "png", mime: "image/png" };
                  case "acTL":
                    return { ext: "apng", mime: "image/apng" };
                  default:
                    await e.ignore(v.length + 4);
                }
              } while (e.position + 8 < e.fileInfo.size);
              return { ext: "png", mime: "image/png" };
            }
            if (r([65, 82, 82, 79, 87, 49, 0, 0])) return { ext: "arrow", mime: "application/x-apache-arrow" };
            if (r([103, 108, 84, 70, 2, 0, 0, 0])) return { ext: "glb", mime: "model/gltf-binary" };
            if (r([102, 114, 101, 101], { offset: 4 }) || r([109, 100, 97, 116], { offset: 4 }) || r([109, 111, 111, 118], { offset: 4 }) || r([119, 105, 100, 101], { offset: 4 })) return { ext: "mov", mime: "video/quicktime" };
            if (r([73, 73, 82, 79, 8, 0, 0, 0, 24])) return { ext: "orf", mime: "image/x-olympus-orf" };
            if (n("gimp xcf ")) return { ext: "xcf", mime: "image/x-xcf" };
            if (r([73, 73, 85, 0, 24, 0, 0, 0, 136, 231, 116, 216])) return { ext: "rw2", mime: "image/x-panasonic-rw2" };
            if (r([48, 38, 178, 117, 142, 102, 207, 17, 166, 217])) {
              async function b() {
                const t2 = Buffer.alloc(16);
                return await e.readBuffer(t2), { id: t2, size: Number(await e.readToken(Token.UINT64_LE)) };
              }
              for (await e.ignore(30); e.position + 24 < e.fileInfo.size; ) {
                const h = await b();
                let _ = h.size - 24;
                if (_check(h.id, [145, 7, 220, 183, 183, 169, 207, 17, 142, 230, 0, 192, 12, 32, 83, 101])) {
                  const P = Buffer.alloc(16);
                  if (_ -= await e.readBuffer(P), _check(P, [64, 158, 105, 248, 77, 91, 207, 17, 168, 253, 0, 128, 95, 92, 68, 43])) return { ext: "asf", mime: "audio/x-ms-asf" };
                  if (_check(P, [192, 239, 25, 188, 77, 91, 207, 17, 168, 253, 0, 128, 95, 92, 68, 43])) return { ext: "asf", mime: "video/x-ms-asf" };
                  break;
                }
                await e.ignore(_);
              }
              return { ext: "asf", mime: "application/vnd.ms-asf" };
            }
            if (r([171, 75, 84, 88, 32, 49, 49, 187, 13, 10, 26, 10])) return { ext: "ktx", mime: "image/ktx" };
            if ((r([126, 16, 4]) || r([126, 24, 4])) && r([48, 77, 73, 69], { offset: 4 })) return { ext: "mie", mime: "application/x-mie" };
            if (r([39, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], { offset: 2 })) return { ext: "shp", mime: "application/x-esri-shape" };
            if (r([0, 0, 0, 12, 106, 80, 32, 32, 13, 10, 135, 10])) {
              await e.ignore(20);
              switch (await e.readToken(new Token.StringType(4, "ascii"))) {
                case "jp2 ":
                  return { ext: "jp2", mime: "image/jp2" };
                case "jpx ":
                  return { ext: "jpx", mime: "image/jpx" };
                case "jpm ":
                  return { ext: "jpm", mime: "image/jpm" };
                case "mjp2":
                  return { ext: "mj2", mime: "image/mj2" };
                default:
                  return;
              }
            }
            if (r([255, 10]) || r([0, 0, 0, 12, 74, 88, 76, 32, 13, 10, 135, 10])) return { ext: "jxl", mime: "image/jxl" };
            if (r([0, 0, 1, 186]) || r([0, 0, 1, 179])) return { ext: "mpg", mime: "video/mpeg" };
            if (r([0, 1, 0, 0, 0])) return { ext: "ttf", mime: "font/ttf" };
            if (r([0, 0, 1, 0])) return { ext: "ico", mime: "image/x-icon" };
            if (r([0, 0, 2, 0])) return { ext: "cur", mime: "image/x-icon" };
            if (r([208, 207, 17, 224, 161, 177, 26, 225])) return { ext: "cfb", mime: "application/x-cfb" };
            if (await e.peekBuffer(t, { length: Math.min(256, e.fileInfo.size), mayBeLess: true }), n("BEGIN:")) {
              if (n("VCARD", { offset: 6 })) return { ext: "vcf", mime: "text/vcard" };
              if (n("VCALENDAR", { offset: 6 })) return { ext: "ics", mime: "text/calendar" };
            }
            if (n("FUJIFILMCCD-RAW")) return { ext: "raf", mime: "image/x-fujifilm-raf" };
            if (n("Extended Module:")) return { ext: "xm", mime: "audio/x-xm" };
            if (n("Creative Voice File")) return { ext: "voc", mime: "audio/x-voc" };
            if (r([4, 0, 0, 0]) && t.length >= 16) {
              const M = t.readUInt32LE(12);
              if (M > 12 && t.length >= M + 16) try {
                const w = t.slice(16, M + 16).toString();
                if (JSON.parse(w).files) return { ext: "asar", mime: "application/x-asar" };
              } catch (O) {
              }
            }
            if (r([6, 14, 43, 52, 2, 5, 1, 1, 13, 1, 2, 1, 1, 2])) return { ext: "mxf", mime: "application/mxf" };
            if (n("SCRM", { offset: 44 })) return { ext: "s3m", mime: "audio/x-s3m" };
            if (r([71], { offset: 4 }) && (r([71], { offset: 192 }) || r([71], { offset: 196 }))) return { ext: "mts", mime: "video/mp2t" };
            if (r([66, 79, 79, 75, 77, 79, 66, 73], { offset: 60 })) return { ext: "mobi", mime: "application/x-mobipocket-ebook" };
            if (r([68, 73, 67, 77], { offset: 128 })) return { ext: "dcm", mime: "application/dicom" };
            if (r([76, 0, 0, 0, 1, 20, 2, 0, 0, 0, 0, 0, 192, 0, 0, 0, 0, 0, 0, 70])) return { ext: "lnk", mime: "application/x.ms.shortcut" };
            if (r([98, 111, 111, 107, 0, 0, 0, 0, 109, 97, 114, 107, 0, 0, 0, 0])) return { ext: "alias", mime: "application/x.apple.alias" };
            if (r([76, 80], { offset: 34 }) && (r([0, 0, 1], { offset: 8 }) || r([1, 0, 2], { offset: 8 }) || r([2, 0, 2], { offset: 8 }))) return { ext: "eot", mime: "application/vnd.ms-fontobject" };
            if (r([6, 6, 237, 245, 216, 29, 70, 229, 189, 49, 239, 231, 254, 116, 183, 29])) return { ext: "indd", mime: "application/x-indesign" };
            if (await e.peekBuffer(t, { length: Math.min(512, e.fileInfo.size), mayBeLess: true }), tarHeaderChecksumMatches(t)) return { ext: "tar", mime: "application/x-tar" };
            if (r([255, 254, 255, 14, 83, 0, 107, 0, 101, 0, 116, 0, 99, 0, 104, 0, 85, 0, 112, 0, 32, 0, 77, 0, 111, 0, 100, 0, 101, 0, 108, 0])) return { ext: "skp", mime: "application/vnd.sketchup.skp" };
            if (n("-----BEGIN PGP MESSAGE-----")) return { ext: "pgp", mime: "application/pgp-encrypted" };
            if (t.length >= 2 && r([255, 224], { offset: 0, mask: [255, 224] })) {
              if (r([16], { offset: 1, mask: [22] })) return r([8], { offset: 1, mask: [8] }), { ext: "aac", mime: "audio/aac" };
              if (r([2], { offset: 1, mask: [6] })) return { ext: "mp3", mime: "audio/mpeg" };
              if (r([4], { offset: 1, mask: [6] })) return { ext: "mp2", mime: "audio/mpeg" };
              if (r([6], { offset: 1, mask: [6] })) return { ext: "mp1", mime: "audio/mpeg" };
            }
          }
          const stream = (readableStream) => new Promise((resolve, reject) => {
            const stream = eval("require")("stream");
            readableStream.on("error", reject), readableStream.once("readable", async () => {
              const e = new stream.PassThrough();
              let t;
              t = stream.pipeline ? stream.pipeline(readableStream, e, () => {
              }) : readableStream.pipe(e);
              const r = readableStream.read(minimumBytes) || readableStream.read() || Buffer.alloc(0);
              try {
                const t2 = await fromBuffer(r);
                e.fileType = t2;
              } catch (e2) {
                reject(e2);
              }
              resolve(t);
            });
          }), fileType = { fromStream, fromTokenizer, fromBuffer, stream };
          Object.defineProperty(fileType, "extensions", { get: () => new Set(supported.extensions) }), Object.defineProperty(fileType, "mimeTypes", { get: () => new Set(supported.mimeTypes) }), module.exports = fileType;
        }, 53846(e, t, r) {
          "use strict";
          const n = r(80363), o = r(5707);
          const i = { fromFile: async function(e2) {
            const t2 = await n.fromFile(e2);
            try {
              return await o.fromTokenizer(t2);
            } finally {
              await t2.close();
            }
          } };
          Object.assign(i, o), Object.defineProperty(i, "extensions", { get: () => o.extensions }), Object.defineProperty(i, "mimeTypes", { get: () => o.mimeTypes }), e.exports = i;
        }, 71664(e) {
          "use strict";
          e.exports = { extensions: ["jpg", "png", "apng", "gif", "webp", "flif", "xcf", "cr2", "cr3", "orf", "arw", "dng", "nef", "rw2", "raf", "tif", "bmp", "icns", "jxr", "psd", "indd", "zip", "tar", "rar", "gz", "bz2", "7z", "dmg", "mp4", "mid", "mkv", "webm", "mov", "avi", "mpg", "mp2", "mp3", "m4a", "oga", "ogg", "ogv", "opus", "flac", "wav", "spx", "amr", "pdf", "epub", "exe", "swf", "rtf", "wasm", "woff", "woff2", "eot", "ttf", "otf", "ico", "flv", "ps", "xz", "sqlite", "nes", "crx", "xpi", "cab", "deb", "ar", "rpm", "Z", "lz", "cfb", "mxf", "mts", "blend", "bpg", "docx", "pptx", "xlsx", "3gp", "3g2", "jp2", "jpm", "jpx", "mj2", "aif", "qcp", "odt", "ods", "odp", "xml", "mobi", "heic", "cur", "ktx", "ape", "wv", "dcm", "ics", "glb", "pcap", "dsf", "lnk", "alias", "voc", "ac3", "m4v", "m4p", "m4b", "f4v", "f4p", "f4b", "f4a", "mie", "asf", "ogm", "ogx", "mpc", "arrow", "shp", "aac", "mp1", "it", "s3m", "xm", "ai", "skp", "avif", "eps", "lzh", "pgp", "asar", "stl", "chm", "3mf", "zst", "jxl", "vcf"], mimeTypes: ["image/jpeg", "image/png", "image/gif", "image/webp", "image/flif", "image/x-xcf", "image/x-canon-cr2", "image/x-canon-cr3", "image/tiff", "image/bmp", "image/vnd.ms-photo", "image/vnd.adobe.photoshop", "application/x-indesign", "application/epub+zip", "application/x-xpinstall", "application/vnd.oasis.opendocument.text", "application/vnd.oasis.opendocument.spreadsheet", "application/vnd.oasis.opendocument.presentation", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/zip", "application/x-tar", "application/x-rar-compressed", "application/gzip", "application/x-bzip2", "application/x-7z-compressed", "application/x-apple-diskimage", "application/x-apache-arrow", "video/mp4", "audio/midi", "video/x-matroska", "video/webm", "video/quicktime", "video/vnd.avi", "audio/vnd.wave", "audio/qcelp", "audio/x-ms-asf", "video/x-ms-asf", "application/vnd.ms-asf", "video/mpeg", "video/3gpp", "audio/mpeg", "audio/mp4", "audio/opus", "video/ogg", "audio/ogg", "application/ogg", "audio/x-flac", "audio/ape", "audio/wavpack", "audio/amr", "application/pdf", "application/x-msdownload", "application/x-shockwave-flash", "application/rtf", "application/wasm", "font/woff", "font/woff2", "application/vnd.ms-fontobject", "font/ttf", "font/otf", "image/x-icon", "video/x-flv", "application/postscript", "application/eps", "application/x-xz", "application/x-sqlite3", "application/x-nintendo-nes-rom", "application/x-google-chrome-extension", "application/vnd.ms-cab-compressed", "application/x-deb", "application/x-unix-archive", "application/x-rpm", "application/x-compress", "application/x-lzip", "application/x-cfb", "application/x-mie", "application/mxf", "video/mp2t", "application/x-blender", "image/bpg", "image/jp2", "image/jpx", "image/jpm", "image/mj2", "audio/aiff", "application/xml", "application/x-mobipocket-ebook", "image/heif", "image/heif-sequence", "image/heic", "image/heic-sequence", "image/icns", "image/ktx", "application/dicom", "audio/x-musepack", "text/calendar", "text/vcard", "model/gltf-binary", "application/vnd.tcpdump.pcap", "audio/x-dsf", "application/x.ms.shortcut", "application/x.apple.alias", "audio/x-voc", "audio/vnd.dolby.dd-raw", "audio/x-m4a", "image/apng", "image/x-olympus-orf", "image/x-sony-arw", "image/x-adobe-dng", "image/x-nikon-nef", "image/x-panasonic-rw2", "image/x-fujifilm-raf", "video/x-m4v", "video/3gpp2", "application/x-esri-shape", "audio/aac", "audio/x-it", "audio/x-s3m", "audio/x-xm", "video/MP1S", "video/MP2P", "application/vnd.sketchup.skp", "image/avif", "application/x-lzh-compressed", "application/pgp-encrypted", "application/x-asar", "model/stl", "application/vnd.ms-htmlhelp", "model/3mf", "image/jxl", "application/zstd"] };
        }, 86760(e, t) {
          "use strict";
          t.stringToBytes = (e2) => [...e2].map((e3) => e3.charCodeAt(0)), t.tarHeaderChecksumMatches = (e2, t2 = 0) => {
            const r = parseInt(e2.toString("utf8", 148, 154).replace(/\0.*$/, "").trim(), 8);
            if (isNaN(r)) return false;
            let n = 256;
            for (let r2 = t2; r2 < t2 + 148; r2++) n += e2[r2];
            for (let r2 = t2 + 156; r2 < t2 + 512; r2++) n += e2[r2];
            return r === n;
          }, t.uint32SyncSafeToken = { get: (e2, t2) => 127 & e2[t2 + 3] | e2[t2 + 2] << 7 | e2[t2 + 1] << 14 | e2[t2] << 21, len: 4 };
        }, 251(e, t) {
          t.read = function(e2, t2, r, n, o) {
            var i, a, s = 8 * o - n - 1, u = (1 << s) - 1, c = u >> 1, l = -7, d = r ? o - 1 : 0, f = r ? -1 : 1, p = e2[t2 + d];
            for (d += f, i = p & (1 << -l) - 1, p >>= -l, l += s; l > 0; i = 256 * i + e2[t2 + d], d += f, l -= 8) ;
            for (a = i & (1 << -l) - 1, i >>= -l, l += n; l > 0; a = 256 * a + e2[t2 + d], d += f, l -= 8) ;
            if (0 === i) i = 1 - c;
            else {
              if (i === u) return a ? NaN : 1 / 0 * (p ? -1 : 1);
              a += Math.pow(2, n), i -= c;
            }
            return (p ? -1 : 1) * a * Math.pow(2, i - n);
          }, t.write = function(e2, t2, r, n, o, i) {
            var a, s, u, c = 8 * i - o - 1, l = (1 << c) - 1, d = l >> 1, f = 23 === o ? Math.pow(2, -24) - Math.pow(2, -77) : 0, p = n ? 0 : i - 1, g = n ? 1 : -1, m = t2 < 0 || 0 === t2 && 1 / t2 < 0 ? 1 : 0;
            for (t2 = Math.abs(t2), isNaN(t2) || t2 === 1 / 0 ? (s = isNaN(t2) ? 1 : 0, a = l) : (a = Math.floor(Math.log(t2) / Math.LN2), t2 * (u = Math.pow(2, -a)) < 1 && (a--, u *= 2), (t2 += a + d >= 1 ? f / u : f * Math.pow(2, 1 - d)) * u >= 2 && (a++, u /= 2), a + d >= l ? (s = 0, a = l) : a + d >= 1 ? (s = (t2 * u - 1) * Math.pow(2, o), a += d) : (s = t2 * Math.pow(2, d - 1) * Math.pow(2, o), a = 0)); o >= 8; e2[r + p] = 255 & s, p += g, s /= 256, o -= 8) ;
            for (a = a << o | s, c += o; c > 0; e2[r + p] = 255 & a, p += g, a /= 256, c -= 8) ;
            e2[r + p - g] |= 128 * m;
          };
        }, 6585(e) {
          var t = 1e3, r = 60 * t, n = 60 * r, o = 24 * n, i = 7 * o, a = 365.25 * o;
          function s(e2, t2, r2, n2) {
            var o2 = t2 >= 1.5 * r2;
            return Math.round(e2 / r2) + " " + n2 + (o2 ? "s" : "");
          }
          e.exports = function(e2, u) {
            u = u || {};
            var c = typeof e2;
            if ("string" === c && e2.length > 0) return function(e3) {
              if ((e3 = String(e3)).length > 100) return;
              var s2 = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(e3);
              if (!s2) return;
              var u2 = parseFloat(s2[1]);
              switch ((s2[2] || "ms").toLowerCase()) {
                case "years":
                case "year":
                case "yrs":
                case "yr":
                case "y":
                  return u2 * a;
                case "weeks":
                case "week":
                case "w":
                  return u2 * i;
                case "days":
                case "day":
                case "d":
                  return u2 * o;
                case "hours":
                case "hour":
                case "hrs":
                case "hr":
                case "h":
                  return u2 * n;
                case "minutes":
                case "minute":
                case "mins":
                case "min":
                case "m":
                  return u2 * r;
                case "seconds":
                case "second":
                case "secs":
                case "sec":
                case "s":
                  return u2 * t;
                case "milliseconds":
                case "millisecond":
                case "msecs":
                case "msec":
                case "ms":
                  return u2;
                default:
                  return;
              }
            }(e2);
            if ("number" === c && isFinite(e2)) return u.long ? function(e3) {
              var i2 = Math.abs(e3);
              if (i2 >= o) return s(e3, i2, o, "day");
              if (i2 >= n) return s(e3, i2, n, "hour");
              if (i2 >= r) return s(e3, i2, r, "minute");
              if (i2 >= t) return s(e3, i2, t, "second");
              return e3 + " ms";
            }(e2) : function(e3) {
              var i2 = Math.abs(e3);
              if (i2 >= o) return Math.round(e3 / o) + "d";
              if (i2 >= n) return Math.round(e3 / n) + "h";
              if (i2 >= r) return Math.round(e3 / r) + "m";
              if (i2 >= t) return Math.round(e3 / t) + "s";
              return e3 + "ms";
            }(e2);
            throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(e2));
          };
        }, 62759(e, t, r) {
          "use strict";
          var n = r(48287).hp;
          const o = r(44276);
          e.exports = (e2) => {
            if (!o(e2)) return false;
            const t2 = e2.trim().match(o.regex), r2 = {};
            if (t2[1]) {
              r2.mediaType = t2[1].toLowerCase();
              const e3 = t2[1].split(";").map((e4) => e4.toLowerCase());
              r2.contentType = e3[0], e3.slice(1).forEach((e4) => {
                const t3 = e4.split("=");
                r2[t3[0]] = t3[1];
              });
            }
            return r2.base64 = !!t2[t2.length - 2], r2.data = t2[t2.length - 1] || "", r2.toBuffer = () => {
              const e3 = r2.base64 ? "base64" : "utf8";
              return n.from(r2.base64 ? r2.data : decodeURIComponent(r2.data), e3);
            }, r2;
          };
        }, 78122(e, t) {
          "use strict";
          t.Deferred = void 0;
          t.Deferred = class {
            constructor() {
              this.resolve = () => null, this.reject = () => null, this.promise = new Promise((e2, t2) => {
                this.reject = t2, this.resolve = e2;
              });
            }
          };
        }, 75523(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.EndOfStreamError = t.defaultMessages = void 0, t.defaultMessages = "End-Of-Stream";
          class r extends Error {
            constructor() {
              super(t.defaultMessages);
            }
          }
          t.EndOfStreamError = r;
        }, 51510(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.StreamReader = t.EndOfStreamError = void 0;
          const n = r(75523), o = r(78122);
          var i = r(75523);
          Object.defineProperty(t, "EndOfStreamError", { enumerable: true, get: function() {
            return i.EndOfStreamError;
          } });
          t.StreamReader = class {
            constructor(e2) {
              if (this.s = e2, this.deferred = null, this.endOfStream = false, this.peekQueue = [], !e2.read || !e2.once) throw new Error("Expected an instance of stream.Readable");
              this.s.once("end", () => this.reject(new n.EndOfStreamError())), this.s.once("error", (e3) => this.reject(e3)), this.s.once("close", () => this.reject(new Error("Stream closed")));
            }
            async peek(e2, t2, r2) {
              const n2 = await this.read(e2, t2, r2);
              return this.peekQueue.push(e2.subarray(t2, t2 + n2)), n2;
            }
            async read(e2, t2, r2) {
              if (0 === r2) return 0;
              if (0 === this.peekQueue.length && this.endOfStream) throw new n.EndOfStreamError();
              let o2 = r2, i2 = 0;
              for (; this.peekQueue.length > 0 && o2 > 0; ) {
                const r3 = this.peekQueue.pop();
                if (!r3) throw new Error("peekData should be defined");
                const n2 = Math.min(r3.length, o2);
                e2.set(r3.subarray(0, n2), t2 + i2), i2 += n2, o2 -= n2, n2 < r3.length && this.peekQueue.push(r3.subarray(n2));
              }
              for (; o2 > 0 && !this.endOfStream; ) {
                const r3 = Math.min(o2, 1048576), n2 = await this.readFromStream(e2, t2 + i2, r3);
                if (i2 += n2, n2 < r3) break;
                o2 -= n2;
              }
              return i2;
            }
            async readFromStream(e2, t2, r2) {
              const n2 = this.s.read(r2);
              if (n2) return e2.set(n2, t2), n2.length;
              {
                const n3 = { buffer: e2, offset: t2, length: r2, deferred: new o.Deferred() };
                return this.deferred = n3.deferred, this.s.once("readable", () => {
                  this.readDeferred(n3);
                }), n3.deferred.promise;
              }
            }
            readDeferred(e2) {
              const t2 = this.s.read(e2.length);
              t2 ? (e2.buffer.set(t2, e2.offset), e2.deferred.resolve(t2.length), this.deferred = null) : this.s.once("readable", () => {
                this.readDeferred(e2);
              });
            }
            reject(e2) {
              this.endOfStream = true, this.deferred && (this.deferred.reject(e2), this.deferred = null);
            }
          };
        }, 48705(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.StreamReader = t.EndOfStreamError = void 0;
          var n = r(75523);
          Object.defineProperty(t, "EndOfStreamError", { enumerable: true, get: function() {
            return n.EndOfStreamError;
          } });
          var o = r(51510);
          Object.defineProperty(t, "StreamReader", { enumerable: true, get: function() {
            return o.StreamReader;
          } });
        }, 98632(e, t, r) {
          "use strict";
          var n = r(48287).hp;
          t.AbstractTokenizer = void 0;
          const o = r(48705);
          t.AbstractTokenizer = class {
            constructor(e2) {
              this.position = 0, this.numBuffer = new Uint8Array(8), this.fileInfo = e2 || {};
            }
            async readToken(e2, t2 = this.position) {
              const r2 = n.alloc(e2.len);
              if (await this.readBuffer(r2, { position: t2 }) < e2.len) throw new o.EndOfStreamError();
              return e2.get(r2, 0);
            }
            async peekToken(e2, t2 = this.position) {
              const r2 = n.alloc(e2.len);
              if (await this.peekBuffer(r2, { position: t2 }) < e2.len) throw new o.EndOfStreamError();
              return e2.get(r2, 0);
            }
            async readNumber(e2) {
              if (await this.readBuffer(this.numBuffer, { length: e2.len }) < e2.len) throw new o.EndOfStreamError();
              return e2.get(this.numBuffer, 0);
            }
            async peekNumber(e2) {
              if (await this.peekBuffer(this.numBuffer, { length: e2.len }) < e2.len) throw new o.EndOfStreamError();
              return e2.get(this.numBuffer, 0);
            }
            async ignore(e2) {
              if (void 0 !== this.fileInfo.size) {
                const t2 = this.fileInfo.size - this.position;
                if (e2 > t2) return this.position += t2, t2;
              }
              return this.position += e2, e2;
            }
            async close() {
            }
            normalizeOptions(e2, t2) {
              if (t2 && void 0 !== t2.position && t2.position < this.position) throw new Error("`options.position` must be equal or greater than `tokenizer.position`");
              return t2 ? { mayBeLess: true === t2.mayBeLess, offset: t2.offset ? t2.offset : 0, length: t2.length ? t2.length : e2.length - (t2.offset ? t2.offset : 0), position: t2.position ? t2.position : this.position } : { mayBeLess: false, offset: 0, length: e2.length, position: this.position };
            }
          };
        }, 93492(e, t, r) {
          "use strict";
          t.BufferTokenizer = void 0;
          const n = r(48705), o = r(98632);
          class i extends o.AbstractTokenizer {
            constructor(e2, t2) {
              super(t2), this.uint8Array = e2, this.fileInfo.size = this.fileInfo.size ? this.fileInfo.size : e2.length;
            }
            async readBuffer(e2, t2) {
              if (t2 && t2.position) {
                if (t2.position < this.position) throw new Error("`options.position` must be equal or greater than `tokenizer.position`");
                this.position = t2.position;
              }
              const r2 = await this.peekBuffer(e2, t2);
              return this.position += r2, r2;
            }
            async peekBuffer(e2, t2) {
              const r2 = this.normalizeOptions(e2, t2), o2 = Math.min(this.uint8Array.length - r2.position, r2.length);
              if (!r2.mayBeLess && o2 < r2.length) throw new n.EndOfStreamError();
              return e2.set(this.uint8Array.subarray(r2.position, r2.position + o2), r2.offset), o2;
            }
            async close() {
            }
          }
          t.BufferTokenizer = i;
        }, 91456(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.fromFile = t.FileTokenizer = void 0;
          const n = r(98632), o = r(48705), i = r(91343);
          class a extends n.AbstractTokenizer {
            constructor(e2, t2) {
              super(t2), this.fd = e2;
            }
            async readBuffer(e2, t2) {
              const r2 = this.normalizeOptions(e2, t2);
              this.position = r2.position;
              const n2 = await i.read(this.fd, e2, r2.offset, r2.length, r2.position);
              if (this.position += n2.bytesRead, n2.bytesRead < r2.length && (!t2 || !t2.mayBeLess)) throw new o.EndOfStreamError();
              return n2.bytesRead;
            }
            async peekBuffer(e2, t2) {
              const r2 = this.normalizeOptions(e2, t2), n2 = await i.read(this.fd, e2, r2.offset, r2.length, r2.position);
              if (!r2.mayBeLess && n2.bytesRead < r2.length) throw new o.EndOfStreamError();
              return n2.bytesRead;
            }
            async close() {
              return i.close(this.fd);
            }
          }
          t.FileTokenizer = a, t.fromFile = async function(e2) {
            const t2 = await i.stat(e2);
            if (!t2.isFile) throw new Error(`File not a file: ${e2}`);
            const r2 = await i.open(e2, "r");
            return new a(r2, { path: e2, size: t2.size });
          };
        }, 91343(e, t, r) {
          "use strict";
          t.read = t.open = t.close = t.stat = void 0;
          const n = r(54428);
          n.existsSync, n.createReadStream, t.stat = async function(e2) {
            return new Promise((t2, r2) => {
              n.stat(e2, (e3, n2) => {
                e3 ? r2(e3) : t2(n2);
              });
            });
          }, t.close = async function(e2) {
            return new Promise((t2, r2) => {
              n.close(e2, (e3) => {
                e3 ? r2(e3) : t2();
              });
            });
          }, t.open = async function(e2, t2) {
            return new Promise((r2, o) => {
              n.open(e2, t2, (e3, t3) => {
                e3 ? o(e3) : r2(t3);
              });
            });
          }, t.read = async function(e2, t2, r2, o, i) {
            return new Promise((a, s) => {
              n.read(e2, t2, r2, o, i, (e3, t3, r3) => {
                e3 ? s(e3) : a({ bytesRead: t3, buffer: r3 });
              });
            });
          };
        }, 36066(e, t, r) {
          "use strict";
          t.ReadStreamTokenizer = void 0;
          const n = r(98632), o = r(48705);
          class i extends n.AbstractTokenizer {
            constructor(e2, t2) {
              super(t2), this.streamReader = new o.StreamReader(e2);
            }
            async getFileInfo() {
              return this.fileInfo;
            }
            async readBuffer(e2, t2) {
              const r2 = this.normalizeOptions(e2, t2), n2 = r2.position - this.position;
              if (n2 > 0) return await this.ignore(n2), this.readBuffer(e2, t2);
              if (n2 < 0) throw new Error("`options.position` must be equal or greater than `tokenizer.position`");
              if (0 === r2.length) return 0;
              const i2 = await this.streamReader.read(e2, r2.offset, r2.length);
              if (this.position += i2, (!t2 || !t2.mayBeLess) && i2 < r2.length) throw new o.EndOfStreamError();
              return i2;
            }
            async peekBuffer(e2, t2) {
              const r2 = this.normalizeOptions(e2, t2);
              let n2 = 0;
              if (r2.position) {
                const t3 = r2.position - this.position;
                if (t3 > 0) {
                  const o2 = new Uint8Array(r2.length + t3);
                  return n2 = await this.peekBuffer(o2, { mayBeLess: r2.mayBeLess }), e2.set(o2.subarray(t3), r2.offset), n2 - t3;
                }
                if (t3 < 0) throw new Error("Cannot peek from a negative offset in a stream");
              }
              if (r2.length > 0) {
                try {
                  n2 = await this.streamReader.peek(e2, r2.offset, r2.length);
                } catch (e3) {
                  if (t2 && t2.mayBeLess && e3 instanceof o.EndOfStreamError) return 0;
                  throw e3;
                }
                if (!r2.mayBeLess && n2 < r2.length) throw new o.EndOfStreamError();
              }
              return n2;
            }
            async ignore(e2) {
              const t2 = Math.min(256e3, e2), r2 = new Uint8Array(t2);
              let n2 = 0;
              for (; n2 < e2; ) {
                const o2 = e2 - n2, i2 = await this.readBuffer(r2, { length: Math.min(t2, o2) });
                if (i2 < 0) return i2;
                n2 += i2;
              }
              return n2;
            }
          }
          t.ReadStreamTokenizer = i;
        }, 96452(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.fromBuffer = t.fromStream = t.EndOfStreamError = void 0;
          const n = r(36066), o = r(93492);
          var i = r(48705);
          Object.defineProperty(t, "EndOfStreamError", { enumerable: true, get: function() {
            return i.EndOfStreamError;
          } }), t.fromStream = function(e2, t2) {
            return t2 = t2 || {}, new n.ReadStreamTokenizer(e2, t2);
          }, t.fromBuffer = function(e2, t2) {
            return new o.BufferTokenizer(e2, t2);
          };
        }, 80363(e, t, r) {
          "use strict";
          t.fromFile = void 0;
          const n = r(91343), o = r(96452);
          var i = r(91456);
          Object.defineProperty(t, "fromFile", { enumerable: true, get: function() {
            return i.fromFile;
          } });
          var a = r(96452);
        }, 44266(e, t, r) {
          "use strict";
          var n = r(48287).hp;
          t.StringType = t.UINT64_LE = t.INT32_BE = t.Tb = t.pR = t.UINT8 = void 0;
          const o = r(251);
          function i(e2) {
            return new DataView(e2.buffer, e2.byteOffset);
          }
          t.UINT8 = { len: 1, get: (e2, t2) => i(e2).getUint8(t2), put: (e2, t2, r2) => (i(e2).setUint8(t2, r2), t2 + 1) }, t.pR = { len: 3, get(e2, t2) {
            const r2 = i(e2);
            return r2.getUint8(t2) + (r2.getUint16(t2 + 1, true) << 8);
          }, put(e2, t2, r2) {
            const n2 = i(e2);
            return n2.setUint8(t2, 255 & r2), n2.setUint16(t2 + 1, r2 >> 8, true), t2 + 3;
          } }, t.Tb = { len: 3, get(e2, t2) {
            const r2 = i(e2);
            return (r2.getUint16(t2) << 8) + r2.getUint8(t2 + 2);
          }, put(e2, t2, r2) {
            const n2 = i(e2);
            return n2.setUint16(t2, r2 >> 8), n2.setUint8(t2 + 2, 255 & r2), t2 + 3;
          } }, t.INT32_BE = { len: 4, get: (e2, t2) => i(e2).getInt32(t2), put: (e2, t2, r2) => (i(e2).setInt32(t2, r2), t2 + 4) }, t.UINT64_LE = { len: 8, get: (e2, t2) => i(e2).getBigUint64(t2, true), put: (e2, t2, r2) => (i(e2).setBigUint64(t2, r2, true), t2 + 8) };
          t.StringType = class {
            constructor(e2, t2) {
              this.len = e2, this.encoding = t2;
            }
            get(e2, t2) {
              return n.from(e2).toString(this.encoding, t2, t2 + this.len);
            }
          };
          class a {
            constructor(e2) {
              this.len = e2;
            }
            static decode(e2, t2, r2) {
              let n2 = "";
              for (let o2 = t2; o2 < r2; ++o2) n2 += a.codePointToString(a.singleByteDecoder(e2[o2]));
              return n2;
            }
            static inRange(e2, t2, r2) {
              return t2 <= e2 && e2 <= r2;
            }
            static codePointToString(e2) {
              return e2 <= 65535 ? String.fromCharCode(e2) : (e2 -= 65536, String.fromCharCode(55296 + (e2 >> 10), 56320 + (1023 & e2)));
            }
            static singleByteDecoder(e2) {
              if (a.inRange(e2, 0, 127)) return e2;
              const t2 = a.windows1252[e2 - 128];
              if (null === t2) throw Error("invaliding encoding");
              return t2;
            }
            get(e2, t2 = 0) {
              return a.decode(e2, t2, t2 + this.len);
            }
          }
          a.windows1252 = [8364, 129, 8218, 402, 8222, 8230, 8224, 8225, 710, 8240, 352, 8249, 338, 141, 381, 143, 144, 8216, 8217, 8220, 8221, 8226, 8211, 8212, 732, 8482, 353, 8250, 339, 157, 382, 376, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255];
        }, 60015(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.InvalidChat = void 0, t.assertFindChat = async function(e2) {
            const t2 = await n.chat.find(e2);
            if (!t2) throw new a(e2);
            return t2;
          }, t.assertGetChat = function(e2) {
            let t2 = null;
            t2 = e2.toString().includes("newsletter") ? i.NewsletterStore.get(e2) : n.chat.get(e2);
            if (!t2) throw new a(e2);
            return t2;
          };
          const n = r(28156), o = r(62857), i = r(14647);
          class a extends o.WPPError {
            constructor(e2) {
              super("chat_not_found", `Chat not found for ${e2}`), this.id = e2;
            }
          }
          t.InvalidChat = a;
        }, 4526(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.InvalidColor = void 0, t.assertColor = function(e2) {
            let t2;
            if ("number" == typeof e2) t2 = e2 > 0 ? e2 : 4294967295 + Number(e2) + 1;
            else {
              if ("string" != typeof e2) throw new o(e2);
              {
                let r2 = e2.trim().replace("#", "");
                r2.length <= 6 && (r2 = "FF" + r2.padStart(6, "0")), t2 = parseInt(r2, 16);
              }
            }
            return t2;
          };
          const n = r(62857);
          class o extends n.WPPError {
            constructor(e2) {
              super("invalid_color", `Invalid Color value for ${e2}`), this.color = e2;
            }
          }
          t.InvalidColor = o;
        }, 44763(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.NotIsBusinessError = void 0, t.assertIsBusiness = function() {
            if (!o.Conn.isSMB) throw new i();
          };
          const n = r(62857), o = r(14647);
          class i extends n.WPPError {
            constructor() {
              super("is_not_business", "This account is not a business version");
            }
          }
          t.NotIsBusinessError = i;
        }, 63990(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.InvalidProduct = void 0, t.assertGetProduct = async function(e2) {
            const t2 = (await i.CatalogStore.findProduct({ catalogWid: (0, n.getMyUserWid)(), productId: e2 }))[0].msgProductCollection._index[e2];
            if (!t2) throw new a(e2);
            return t2;
          };
          const n = r(21942), o = r(62857), i = r(14647);
          class a extends o.WPPError {
            constructor(e2) {
              super("product_not_found", `Product not found for ${e2}`), this.id = e2;
            }
          }
          t.InvalidProduct = a;
        }, 63665(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.InvalidWid = void 0, t.assertWid = function(e2) {
            const t2 = (0, n.createWid)(e2);
            if (!t2) throw new o(e2);
            return t2;
          };
          const n = r(62857);
          class o extends n.WPPError {
            constructor(e2) {
              super("invalid_wid", `Invalid WID value for ${e2}`), this.id = e2;
            }
          }
          t.InvalidWid = o;
        }, 41687(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(60015), t), o(r(4526), t), o(r(44763), t), o(r(63990), t), o(r(63665), t);
        }, 24846(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), r(63539);
        }, 63539(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(() => {
            c.BlocklistStore.on("sort", () => {
              s.internalEv.emit("blocklist.sync");
            });
          });
        }, 86671(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.all = function() {
            return n.BlocklistStore.getModelsArray().map((e2) => e2.id);
          };
          const n = r(14647);
        }, 7937(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.blockContact = async function(e2) {
            const t2 = (0, u.assertWid)(e2), r2 = c.ContactStore.get(t2) || new c.ContactModel({ id: t2 });
            (0, s.compare)(l.SANITIZED_VERSION_STR, "2.2323.4", ">=") ? await d.blockContact({ contact: r2, blockEntryPoint: "block_list", bizOptOutArgs: null }) : await d.blockContact(r2);
            return { wid: t2, isBlocked: (0, f.isBlocked)(t2) };
          };
          const s = r(75828), u = r(41687), c = r(14647), l = r(19198), d = a(r(52757)), f = r(14944);
        }, 54480(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.unblockContact = t.isBlocked = t.blockContact = t.all = void 0;
          var n = r(86671);
          Object.defineProperty(t, "all", { enumerable: true, get: function() {
            return n.all;
          } });
          var o = r(7937);
          Object.defineProperty(t, "blockContact", { enumerable: true, get: function() {
            return o.blockContact;
          } });
          var i = r(14944);
          Object.defineProperty(t, "isBlocked", { enumerable: true, get: function() {
            return i.isBlocked;
          } });
          var a = r(78306);
          Object.defineProperty(t, "unblockContact", { enumerable: true, get: function() {
            return a.unblockContact;
          } });
        }, 14944(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.isBlocked = function(e2) {
            const t2 = (0, n.assertWid)(e2);
            return !!o.BlocklistStore.get(t2);
          };
          const n = r(41687), o = r(14647);
        }, 78306(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.unblockContact = async function(e2) {
            const t2 = (0, s.assertWid)(e2), r2 = u.ContactStore.get(t2) || new u.ContactModel({ id: t2 });
            return await c.unblockContact(r2), { wid: t2, isBlocked: (0, l.isBlocked)(t2) };
          };
          const s = r(41687), u = r(14647), c = a(r(52757)), l = r(14944);
        }, 61042(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), r(24846), o(r(54480), t);
        }, 75495(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), r(75848);
        }, 75848(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          }), s = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true });
          const u = s(r(17833)), c = r(13691), l = a(r(7222)), d = r(13257), f = r(14647), p = (0, u.default)("WA-JS:call:registerIncomingCallEvent");
          l.onInjected(() => function() {
            p("Registering incoming call event listeners");
            const e2 = /* @__PURE__ */ new Set(), t2 = f.CallStore.processIncomingCall.bind(f.CallStore);
            f.CallStore.processIncomingCall = function(...r2) {
              const n2 = t2(...r2);
              return !n2 || e2.has(n2.id) || (e2.add(n2.id), p("New call via processIncomingCall", n2), c.internalEv.emit("call.incoming_call", { id: n2.id, isGroup: n2.isGroup, isVideo: n2.isVideo, offerTime: n2.offerTime, sender: (0, d.createWid)(n2.peerJid), peerJid: n2.peerJid })), n2;
            };
          }());
        }, 21139(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.accept = async function(e2) {
            let t2;
            t2 = e2 ? o.CallStore.get(e2) : o.CallStore.getModelsArray().find((e3) => e3.getState() === i.CALL_STATES.INCOMING_RING || e3.isGroup);
            if (!t2) throw new n.WPPError("call_not_found", `Call ${e2 || "<empty>"} not found`, { callId: e2 });
            if ("INCOMING_RING" !== t2.getState() && !t2.isGroup) throw new n.WPPError("call_is_not_incoming_ring", `Call ${e2 || "<empty>"} is not incoming ring`, { callId: e2, state: t2.getState() });
            t2.peerJid.isGroupCall() || await o.websocket.ensureE2ESessions([t2.peerJid]);
            const r2 = [o.websocket.smax("audio", { enc: "opus", rate: "16000" }, null), o.websocket.smax("audio", { enc: "opus", rate: "8000" }, null)];
            t2.isVideo && r2.push(o.websocket.smax("video", { orientation: "0", screen_width: "1920", screen_height: "1080", device_orientation: "0", enc: "vp8", dec: "vp8" }, null));
            r2.push(o.websocket.smax("net", { medium: "3" }, null), o.websocket.smax("encopt", { keygen: "2" }, null));
            const a = o.websocket.smax("call", { to: t2.peerJid.toString({ legacy: true }), id: o.websocket.generateId() }, [o.websocket.smax("accept", { "call-id": t2.id, "call-creator": t2.peerJid.toString({ legacy: true }) }, r2)]);
            return await o.websocket.sendSmaxStanza(a), true;
          };
          const n = r(62857), o = r(14647), i = r(20514);
        }, 88617(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.enableCallInterface = async function() {
            if (i) return;
            i = true, (0, n.wrapModuleFunction)(o.getABPropConfigValue, (e2, ...t2) => {
              const [r2] = t2;
              switch (r2) {
                case "enable_web_calling":
                case "enable_web_group_calling":
                case "web_voip_call_tab_new_call":
                case "enable_wds_calling_dropdown":
                case "enable_web_calling_nux":
                case "enable_web_calling_beta_upsell":
                  return true;
                case "calling_lid_version":
                  return 1;
                case "heartbeat_interval_s":
                  return 5;
                default:
                  return e2(...t2);
              }
            }), (0, n.wrapModuleFunction)(o.isCallingEnabled, () => true), (0, n.wrapModuleFunction)(o.isUnsupportedBrowserForWebCalling, () => false), (0, n.wrapModuleFunction)(o.getUnsupportedBrowserReason, () => null), (0, n.wrapModuleFunction)(o.isVoipDownloadEnabled, () => true);
            try {
              const e2 = await (0, o.requireVoipJsBackend)();
              e2 && e2.WAWebVoipInit && "function" == typeof e2.WAWebVoipInit.initWAWebVoip && await e2.WAWebVoipInit.initWAWebVoip();
            } catch (e2) {
              console.warn("[WA-JS] Falha ao tentar inicializar manualmente o VoIP backend:", e2);
            }
          };
          const n = r(54993), o = r(52757);
          let i = false;
        }, 86094(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.end = async function() {
            const e2 = await (0, o.getVoipStackInterface)();
            if (!e2) throw new n.WPPError("voip_stack_not_found", "VoIP stack interface is not available");
            return await e2.endCall(2, true), true;
          };
          const n = r(62857), o = r(52757);
        }, 96263(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.rejectCall = t.reject = t.offer = t.end = t.enableCallInterface = t.accept = void 0;
          var n = r(21139);
          Object.defineProperty(t, "accept", { enumerable: true, get: function() {
            return n.accept;
          } });
          var o = r(88617);
          Object.defineProperty(t, "enableCallInterface", { enumerable: true, get: function() {
            return o.enableCallInterface;
          } });
          var i = r(86094);
          Object.defineProperty(t, "end", { enumerable: true, get: function() {
            return i.end;
          } });
          var a = r(82349);
          Object.defineProperty(t, "offer", { enumerable: true, get: function() {
            return a.offer;
          } });
          var s = r(9144);
          Object.defineProperty(t, "reject", { enumerable: true, get: function() {
            return s.reject;
          } }), Object.defineProperty(t, "rejectCall", { enumerable: true, get: function() {
            return s.reject;
          } });
        }, 82349(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.offer = async function(e2, t2 = {}) {
            await (0, u.enableCallInterface)(), t2 = Object.assign({ isVideo: false }, t2);
            const r2 = (0, n.assertWid)(e2);
            if (!r2.isUser()) throw new i.WPPError("call_is_not_user", `The ${r2} is not a user to call`, { to: e2 });
            const c = await (0, o.queryExists)(r2);
            if (!c) throw new i.WPPError("contact_not_found", `The contact ${r2} does not exist on WhatsApp`, { to: e2 });
            const l = c.lid || c.wid;
            await (0, s.getVoipStackInterface)(), await (0, s.startWAWebVoipCall)(l, !!t2.isVideo, 8, 5);
            return a.CallStore.getModelsArray().find((e3) => e3.peerJid.toString({ legacy: true }) === l.toString({ legacy: true }) || e3.peerJid.toString({ legacy: true }) === r2.toString({ legacy: true }));
          };
          const n = r(41687), o = r(53141), i = r(62857), a = r(14647), s = r(52757), u = r(88617);
        }, 9144(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.reject = async function(e2) {
            let t2;
            t2 = e2 ? i.CallStore.get(e2) : i.CallStore.getModelsArray().find((e3) => e3.getState() === a.CALL_STATES.INCOMING_RING || e3.isGroup || e3.getState() === a.CALL_STATES.ReceivedCall || e3.isGroup);
            if (!t2) throw new o.WPPError("call_not_found", `Call ${e2 || "<empty>"} not found`, { callId: e2 });
            if (t2.getState() !== a.CALL_STATES.INCOMING_RING && t2.getState() !== a.CALL_STATES.ReceivedCall && !t2.isGroup) throw new o.WPPError("call_is_not_incoming_ring", `Call ${e2 || "<empty>"} is not incoming ring`, { callId: e2, state: t2.getState() });
            t2.peerJid.isGroupCall() || await i.websocket.ensureE2ESessions([t2.peerJid]);
            const r2 = i.websocket.smax("call", { from: (0, n.getMyUserWid)().toString({ legacy: true }), to: t2.peerJid.toString({ legacy: true }), id: i.websocket.generateId() }, [i.websocket.smax("reject", { "call-id": t2.id, "call-creator": t2.peerJid.toString({ legacy: true }), count: "0" }, null)]);
            return await i.websocket.sendSmaxStanza(r2), true;
          };
          const n = r(21942), o = r(62857), i = r(14647), a = r(20514);
        }, 38893(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), r(75495), o(r(96263), t);
        }, 71722(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.add = async function(e2, t2) {
            if (!e2 || !t2) throw new o.WPPError("send_required_params", "For add item in cart send chatId and products array");
            for (const r2 of t2) {
              const t3 = await (0, n.getProductById)(e2, r2.id);
              if (t3) {
                const n2 = new i.ProductModel({ id: t3.id, isHidden: t3.is_hidden || false, catalogWid: e2, url: t3.url, name: t3.name, description: t3.description, availability: t3.availability, maxAvailable: null == t3 ? void 0 : t3.maxAvailable, reviewStatus: null == t3 ? void 0 : t3.capability_to_review_status[0].value, currency: t3.currency, priceAmount1000: t3.price, salePriceAmount1000: null, retailerId: t3.retailer_id, imageCount: t3.image_cdn_urls.length + t3.additional_image_cdn_urls.length, additionalImageCdnUrl: t3.additional_image_cdn_urls, additionalImageHashes: t3.image_hashes_for_whatsapp, imageCdnUrl: t3.image_cdn_urls[0].value, imageHash: t3.image_hashes_for_whatsapp[0] });
                await (0, a.addProductToCart)(n2), await (0, a.updateProductQuantityCart)(n2, r2.qnt);
              }
            }
            return i.CartStore.findCart(e2);
          };
          const n = r(40164), o = r(62857), i = r(14647), a = r(52757);
        }, 70932(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.clear = async function(e2) {
            var t2, r2;
            const a = o.CartStore.findCart(e2);
            if (!a || !(null === (t2 = null == a ? void 0 : a.cartItemCollection) || void 0 === t2 ? void 0 : t2.length)) throw new n.WPPError("cart_not_have_products", `Cart from  ${e2 || "<empty>"} not have products`, { wid: e2 });
            null === (r2 = a.cartItemCollection) || void 0 === r2 || r2.reset(), a.set("message", ""), a.trigger("change:cartItemCollection"), (0, i.updateCart)(a);
          };
          const n = r(62857), o = r(14647), i = r(52757);
        }, 9453(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.get = function(e2) {
            return n.CartStore.get(e2);
          };
          const n = r(14647);
        }, 65731(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getThumbFromCart = async function(e2) {
            var t2, r2;
            const i = await o.CartStore.findCart(e2), a = null === (t2 = null == i ? void 0 : i.cartItemCollection) || void 0 === t2 ? void 0 : t2.at(0);
            if (!a || !i) return "";
            const s = o.CatalogStore.get((0, n.createWid)(e2));
            if (!s) return "";
            const u = s.productCollection.get(a.id);
            if (!u) return "";
            const c = await (null == u ? void 0 : u.getProductImageCollectionHead());
            if (!c) return "";
            const l = null == c ? void 0 : c.mediaData;
            if (null == l) return "";
            if (l.preview) {
              const e3 = await (null === (r2 = null == l ? void 0 : l.preview) || void 0 === r2 ? void 0 : r2.getBase64());
              if (null != e3) return e3;
            }
            return "";
          };
          const n = r(62857), o = r(14647);
        }, 89133(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.update = t.submit = t.remove = t.getThumbFromCart = t.get = t.clear = t.add = void 0;
          var n = r(71722);
          Object.defineProperty(t, "add", { enumerable: true, get: function() {
            return n.add;
          } });
          var o = r(70932);
          Object.defineProperty(t, "clear", { enumerable: true, get: function() {
            return o.clear;
          } });
          var i = r(9453);
          Object.defineProperty(t, "get", { enumerable: true, get: function() {
            return i.get;
          } });
          var a = r(65731);
          Object.defineProperty(t, "getThumbFromCart", { enumerable: true, get: function() {
            return a.getThumbFromCart;
          } });
          var s = r(74553);
          Object.defineProperty(t, "remove", { enumerable: true, get: function() {
            return s.remove;
          } });
          var u = r(24393);
          Object.defineProperty(t, "submit", { enumerable: true, get: function() {
            return u.submit;
          } });
          var c = r(57288);
          Object.defineProperty(t, "update", { enumerable: true, get: function() {
            return c.update;
          } });
        }, 74553(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.remove = async function(e2, t2) {
            if (!e2 || !t2) throw new n.WPPError("send_required_params", "For update item in cart send chatId and productId");
            return await (0, i.deleteProductFromCart)(e2, t2), o.CartStore.findCart(e2);
          };
          const n = r(62857), o = r(14647), i = r(52757);
        }, 24393(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.submit = async function(e2, t2, r2) {
            var l, d, f;
            if (e2.toString() == (null === (l = (0, i.getMyUserId)()) || void 0 === l ? void 0 : l.toString())) throw new a.WPPError("can_not_submit_order_to_yourself", "You can not submit order to yourself");
            const p = s.CartStore.findCart(e2);
            if (!p || !(null === (d = null == p ? void 0 : p.cartItemCollection) || void 0 === d ? void 0 : d.length)) throw new a.WPPError("cart_not_have_products", `Cart from  ${e2 || "<empty>"} not have products`, { wid: e2 });
            const g = await (0, n.assertFindChat)((0, a.createWid)(e2)), m = await (0, u.createOrder)(g.id, p.cartItemCollection.toArray()), y = null === (f = m.price) || void 0 === f ? void 0 : f.total, v = await (0, o.prepareRawMessage)(g, { type: "order", orderId: m.id, token: m.token, orderTitle: g.name || g.formattedTitle, sellerJid: g.id.toString({ legacy: true }), status: 1, messageVersion: 2, thumbnail: await (0, c.getThumbFromCart)(e2), itemCount: p.itemCount, message: t2 || p.message, totalAmount1000: y && y.length > 0 ? parseInt(y, 10) : void 0, totalCurrencyCode: m.price.currency && m.price.currency.length > 0 ? m.price.currency : 0 }, r2);
            if (await (0, u.addAndSendMsgToChat)(g, v), (0, u.updateCart)(p), await (0, c.clear)(e2), !m.id) throw new a.WPPError("error_send_order_request", "Error when sending order request");
            return await (0, o.getMessageById)(v.id);
          };
          const n = r(41687), o = r(74023), i = r(72927), a = r(62857), s = r(14647), u = r(52757), c = r(89133);
        }, 57288(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.update = async function(e2, t2, r2) {
            if (!e2 || !t2 || !r2.quantity) throw new n.WPPError("send_required_params", "For update item in cart send chatId, productId and options");
            return (0, o.add)(e2, [{ id: t2, qnt: r2.quantity }]);
          };
          const n = r(62857), o = r(71722);
        }, 81151(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(89133), t);
        }, 373(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.addProductImage = async function(e2, t2) {
            const r2 = await (0, o.convertToFile)(t2), s = await i.OpaqueData.createFromData(r2, r2.type), u = await (0, a.calculateFilehashFromBlob)(r2), c = await (0, a.uploadProductImage)(s, u), l = await (0, n.assertGetProduct)(e2);
            return l.additionalImageCdnUrl.push(c), (0, a.editProduct)(l);
          };
          const n = r(41687), o = r(62857), i = r(14647), a = r(52757);
        }, 11532(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.changeProductImage = async function(e2, t2) {
            const r2 = await (0, o.convertToFile)(t2), s = await i.OpaqueData.createFromData(r2, r2.type), u = await (0, a.calculateFilehashFromBlob)(r2), c = await (0, a.uploadProductImage)(s, u), l = await (0, n.assertGetProduct)(e2);
            return l.imageCdnUrl = c, (0, a.editProduct)(l);
          };
          const n = r(41687), o = r(62857), i = r(14647), a = r(52757);
        }, 69092(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.createCollection = async function(e2, t2) {
            const { sessionId: r2 } = new n.ProductCatalogSession(true);
            return await (0, o.createCollection)(e2, t2, `${r2}`);
          };
          const n = r(14647), o = r(52757);
        }, 11561(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.createProduct = async function(e2) {
            const t2 = await (0, n.convertToFile)(e2.image), r2 = await o.OpaqueData.createFromData(t2, t2.type), a = await (0, i.calculateFilehashFromBlob)(t2), s = await (0, i.uploadProductImage)(r2, a), u = new o.ProductModel();
            u.name = e2.name.toString();
            const c = o.UserPrefs.getMaybeMePnUser(), l = o.UserPrefs.getMaybeMeLidUser();
            u.catalogWid = c || l, u.imageCdnUrl = s, u.productImageCollection = new o.ProductImageModel({ mediaUrl: s }), e2.description && (u.description = e2.description);
            e2.price && (u.priceAmount1000 = 1e4 * e2.price, u.currency = e2.currency || "BRL");
            e2.isHidden && (u.isHidden = e2.isHidden);
            e2.url && (u.url = e2.url);
            e2.retailerId && (u.retailerId = e2.retailerId);
            return await (0, i.addProduct)(u, 100, 100);
          };
          const n = r(62857), o = r(14647), i = r(52757);
        }, 14639(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.deleteCollection = async function(e2) {
            const { sessionId: t2 } = new n.ProductCatalogSession(true);
            return await (0, o.deleteCollection)(e2, `${t2}`), "Collection deleted sucessful";
          };
          const n = r(14647), o = r(52757);
        }, 61612(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.delProducts = async function(e2) {
            let t2 = 200;
            try {
              Array.isArray(e2) ? await (0, n.deleteProducts)(e2) : await (0, n.deleteProducts)([e2]);
            } catch (e3) {
              t2 = 500;
            }
            return { productsIds: e2, status: t2 };
          };
          const n = r(52757);
        }, 25312(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.editCollection = async function(e2, t2) {
            const { sessionId: r2 } = new n.ProductCatalogSession(true);
            return await (0, o.editCollection)(e2, t2.name, false, t2.productsToAdd || [], t2.productsToRemove || [], `${r2}`);
          };
          const n = r(14647), o = r(52757);
        }, 77893(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.editProduct = async function(e2, t2) {
            const r2 = await (0, n.assertGetProduct)(e2);
            Object.keys(t2).forEach((e3) => void 0 === t2[e3] && delete t2[e3]);
            const i = Object.assign(r2, t2);
            return await (0, o.editProduct)(i);
          };
          const n = r(41687), o = r(52757);
        }, 11201(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getCollections = async function(e2, t2, r2) {
            const { collections: i } = await (0, o.queryCollectionsIQ)({ afterCursor: "", catalogWid: (0, n.createWid)(e2), height: 100, width: 100, limit: t2 || 10, productsCount: r2 || 10 });
            return i;
          };
          const n = r(62857), o = r(52757);
        }, 6973(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMyCatalog = async function() {
            return n.CatalogStore.get(n.UserPrefs.getMaybeMePnUser());
          };
          const n = r(14647);
        }, 64639(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getProductById = async function(e2, t2) {
            const r2 = (0, n.createWid)(e2), { data: i } = await (0, o.queryProduct)(r2, t2);
            return i;
          };
          const n = r(62857), o = r(52757);
        }, 94970(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getProducts = async function(e2, t2) {
            const { data: r2 } = await (0, o.queryCatalog)((0, n.createWid)(e2), void 0, t2 || 10, 100, 100);
            return r2;
          };
          const n = r(62857), o = r(52757);
        }, 98486(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.updateCartEnabled = t.setProductVisibility = t.removeProductImage = t.getProducts = t.getProductById = t.getMyCatalog = t.getCollections = t.editProduct = t.editCollection = t.delProducts = t.deleteCollection = t.createProduct = t.createCollection = t.changeProductImage = t.addProductImage = void 0;
          var n = r(373);
          Object.defineProperty(t, "addProductImage", { enumerable: true, get: function() {
            return n.addProductImage;
          } });
          var o = r(11532);
          Object.defineProperty(t, "changeProductImage", { enumerable: true, get: function() {
            return o.changeProductImage;
          } });
          var i = r(69092);
          Object.defineProperty(t, "createCollection", { enumerable: true, get: function() {
            return i.createCollection;
          } });
          var a = r(11561);
          Object.defineProperty(t, "createProduct", { enumerable: true, get: function() {
            return a.createProduct;
          } });
          var s = r(14639);
          Object.defineProperty(t, "deleteCollection", { enumerable: true, get: function() {
            return s.deleteCollection;
          } });
          var u = r(61612);
          Object.defineProperty(t, "delProducts", { enumerable: true, get: function() {
            return u.delProducts;
          } });
          var c = r(25312);
          Object.defineProperty(t, "editCollection", { enumerable: true, get: function() {
            return c.editCollection;
          } });
          var l = r(77893);
          Object.defineProperty(t, "editProduct", { enumerable: true, get: function() {
            return l.editProduct;
          } });
          var d = r(11201);
          Object.defineProperty(t, "getCollections", { enumerable: true, get: function() {
            return d.getCollections;
          } });
          var f = r(6973);
          Object.defineProperty(t, "getMyCatalog", { enumerable: true, get: function() {
            return f.getMyCatalog;
          } });
          var p = r(64639);
          Object.defineProperty(t, "getProductById", { enumerable: true, get: function() {
            return p.getProductById;
          } });
          var g = r(94970);
          Object.defineProperty(t, "getProducts", { enumerable: true, get: function() {
            return g.getProducts;
          } });
          var m = r(59196);
          Object.defineProperty(t, "removeProductImage", { enumerable: true, get: function() {
            return m.removeProductImage;
          } });
          var y = r(85719);
          Object.defineProperty(t, "setProductVisibility", { enumerable: true, get: function() {
            return y.setProductVisibility;
          } });
          var v = r(93114);
          Object.defineProperty(t, "updateCartEnabled", { enumerable: true, get: function() {
            return v.updateCartEnabled;
          } });
        }, 59196(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.removeProductImage = async function(e2, t2) {
            const r2 = await (0, n.assertGetProduct)(e2);
            return r2.additionalImageCdnUrl.splice(t2, 1), (0, o.editProduct)(r2);
          };
          const n = r(41687), o = r(52757);
        }, 85719(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setProductVisibility = async function(e2, t2) {
            return await (0, o.productVisibilitySet)(e2, t2), await (0, n.assertGetProduct)(e2);
          };
          const n = r(41687), o = r(52757);
        }, 93114(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.updateCartEnabled = async function(e2) {
            return await (0, n.updateCartEnabled)(e2);
          };
          const n = r(52757);
        }, 40164(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(98486), t);
        }, 50175(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.defaultSendMessageOptions = void 0, t.defaultSendMessageOptions = { detectMentioned: true, linkPreview: true, markIsRead: true, waitForAck: true, delay: 0 };
        }, 31853(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), r(70510), r(16854), r(1430), r(56136), r(77810), r(51118), r(59474), r(16349), r(62557), r(61905), r(37740), r(67147), r(59798);
        }, 70510(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647), l = r(54993), d = r(52757);
          u.onFullReady(function() {
            function e2(e3) {
              if (e3.ack < 2 || "sender" === e3.ackString) return;
              const t2 = e3.from, r2 = e3.participant || void 0, n2 = c.UserPrefs.getMaybeMePnUser(), o2 = c.UserPrefs.getMaybeMeLidUser(), i2 = e3.from, a2 = !e3.recipient || (null == n2 ? void 0 : n2.equals(e3.recipient)) || (null == o2 ? void 0 : o2.equals(e3.recipient));
              if (!a2) return;
              const u2 = e3.externalIds.map((t3) => new c.MsgKey({ id: t3, remote: i2, fromMe: a2, participant: e3.participant }));
              s.internalEv.emit("chat.msg_ack_change", { ack: e3.ack, chat: t2, sender: r2, ids: u2 });
            }
            c.MsgStore.on("change:ack", (e3) => {
              1 === e3.ack && queueMicrotask(() => {
                s.internalEv.emit("chat.msg_ack_change", { ack: e3.ack, chat: e3.to, ids: [e3.id] });
              });
            }), (0, l.wrapModuleFunction)(d.handleChatSimpleReceipt, (t2, ...r2) => {
              const [n2] = r2;
              return queueMicrotask(() => {
                e2(n2);
              }), t2(...r2);
            }), (0, l.wrapModuleFunction)(d.handleGroupSimpleReceipt, (t2, ...r2) => {
              const [n2] = r2;
              return queueMicrotask(() => {
                e2(n2);
              }), t2(...r2);
            }), (0, l.wrapModuleFunction)(d.handleStatusSimpleReceipt, (t2, ...r2) => {
              const [n2] = r2;
              return queueMicrotask(() => {
                e2(n2);
              }), t2(...r2);
            });
          });
        }, 16854(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(() => {
            c.ChatStore.on("change:active", (e2) => {
              l && clearTimeout(l), l = setTimeout(() => {
                s.internalEv.emit("chat.active_chat", e2.active ? e2 : null);
              }, 50);
            });
          });
          let l = null;
        }, 1430(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222));
          u.onFullReady(function() {
            const e2 = u.search((e3, t3) => {
              var r3, n3;
              return "WAWebChatSearchQuery" === t3 || "function" == typeof (null === (n3 = null === (r3 = e3.SearchQuery) || void 0 === r3 ? void 0 : r3.prototype) || void 0 === n3 ? void 0 : n3.updateLabelQuery);
            }, false, "ChatSearchQuery");
            if (!e2) return void console.error("WAWebChatSearchQuery module was not found");
            const t2 = e2.SearchQuery.prototype, r2 = t2.updateLabelQuery, n2 = (e3) => {
              var t3, r3;
              return { kind: null !== (t3 = null == e3 ? void 0 : e3.kind) && void 0 !== t3 ? t3 : null, label: null !== (r3 = null == e3 ? void 0 : e3.label) && void 0 !== r3 ? r3 : null };
            };
            t2.updateLabelQuery = function(e3) {
              const t3 = n2(this.filter), o2 = r2.call(this, e3), i2 = n2(this.filter);
              return t3.kind === i2.kind && t3.label === i2.label || s.internalEv.emit("chat.active_filter", i2), o2;
            };
          });
        }, 56136(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onFullReady(function() {
            c.MsgStore.on("change:latestEditMsgKey", (e2) => {
              queueMicrotask(() => {
                s.internalEv.emit("chat.msg_edited", { chat: e2.to, id: e2.id.toString(), msg: e2 });
              });
            });
          });
        }, 77810(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(72927), u = r(13691), c = r(48486), l = a(r(7222)), d = r(54993), f = r(52757), p = r(97829);
          l.onFullReady(function() {
            async function e2(e3, ...t2) {
              const r2 = t2[0], n2 = Array.isArray(r2[1]) ? r2[1] : [r2[1]], o2 = r2[0];
              if ((0, s.isMainReady)()) {
                const t3 = [];
                for (const e4 of n2) t3.push(await (0, c.getLabelById)(e4));
                u.internalEv.emit("chat.update_label", { chat: (0, p.get)(o2), ids: n2, labels: t3, type: e3 });
              }
            }
            (0, d.wrapModuleFunction)(f.addToLabelCollection, async (t2, ...r2) => (queueMicrotask(() => {
              e2("add", r2);
            }), t2(...r2))), (0, d.wrapModuleFunction)(f.removeLabelFromCollection, async (t2, ...r2) => (queueMicrotask(() => {
              e2("remove", r2);
            }), t2(...r2)));
          });
        }, 51118(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(() => {
            c.MsgStore.on("add", (e2) => {
              e2.isNewMsg && e2.isLive && queueMicrotask(() => {
                s.internalEv.emit("chat.live_location_start", { id: e2.sender, msgId: e2.id, chat: e2.chat.id, lat: e2.lat, lng: e2.lng, accuracy: e2.accuracy, speed: e2.speed, degrees: e2.degrees, shareDuration: e2.shareDuration });
              });
            });
          });
        }, 59474(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(() => {
            c.ChatStore.on("add", (e2) => {
              queueMicrotask(() => {
                s.internalEv.emit("chat.new_chat", e2);
              });
            });
          });
        }, 16349(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647), l = r(52757), d = r(97829);
          u.onInjected(() => function() {
            c.MsgStore.on("add", (e2) => {
              e2.isNewMsg && queueMicrotask(async () => {
                "ciphertext" === (e2 = await async function(e3) {
                  if (void 0 !== e3.quotedStanzaID) {
                    const t2 = (0, l.getQuotedMsgObj)(e3);
                    if (!t2) return e3;
                    Object.defineProperties(e3, { _quotedMsgObj: { value: t2, writable: false }, quotedMsgId: { value: t2.id, writable: false } });
                  }
                  return e3;
                }(e2)).type && e2.once("change:type", () => {
                  queueMicrotask(() => {
                    s.internalEv.emit("chat.new_message", e2);
                  });
                }), s.internalEv.emit("chat.new_message", e2);
              });
            }), void 0 === c.MsgModel.prototype.chat && Object.defineProperty(c.MsgModel.prototype, "chat", { get: function() {
              var e2;
              return c.ChatStore.get((null === (e2 = this.id) || void 0 === e2 ? void 0 : e2.fromMe) ? this.to : this.from);
            }, configurable: true });
            void 0 === c.MsgModel.prototype.isGroupMsg && Object.defineProperty(c.MsgModel.prototype, "isGroupMsg", { get: function() {
              var e2, t2;
              return null === (t2 = null === (e2 = null == this ? void 0 : this.chat) || void 0 === e2 ? void 0 : e2.id) || void 0 === t2 ? void 0 : t2.isGroup();
            }, configurable: true });
            void 0 === c.MsgModel.prototype.quotedMsgId && Object.defineProperty(c.MsgModel.prototype, "quotedMsgId", { get: function() {
              return (0, d.getQuotedMsgKey)(this);
            }, configurable: true });
          }());
        }, 62557(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(54993), l = r(52757), d = r(97829);
          u.onFullReady(function() {
            (0, c.wrapModuleFunction)(l.upsertVotes, async (e2, ...t2) => {
              const [r2] = t2;
              for (const e3 of r2) try {
                if (e3.senderTimestampMs < f) continue;
                const t3 = await (0, d.getMessageById)(e3.parentMsgKey), r3 = [];
                for (const n2 of e3.selectedOptionLocalIds) r3[n2] = t3.pollOptions.filter((e4) => e4.localId == n2)[0];
                s.internalEv.emitAsync("chat.poll_response", { msgId: e3.parentMsgKey, chatId: e3.parentMsgKey.remote, selectedOptions: r3, timestamp: e3.senderTimestampMs, sender: e3.sender }).catch(() => null);
              } catch (e4) {
              }
              return e2(...t2);
            });
          });
          const f = Date.now();
        }, 61905(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(13691), o = r(14647);
          n.internalEv.on("conn.main_ready", async () => {
            const e2 = o.ChatStore.map((e3) => e3.presence.subscribe());
            await Promise.all(e2), o.PresenceStore.on("change:chatstate.type", (e3) => {
              var t2;
              const r2 = o.PresenceStore.getModelsArray().find((t3) => t3.chatstate === e3);
              r2 && r2.hasData && (null === (t2 = r2.chatstate) || void 0 === t2 ? void 0 : t2.type) && queueMicrotask(() => {
                var e4, t3;
                const i = o.ContactStore.get(r2.id), a = { id: r2.id, isOnline: r2.isOnline, isGroup: r2.isGroup, isUser: r2.isUser, shortName: i ? i.formattedShortName : "", state: null === (e4 = r2.chatstate) || void 0 === e4 ? void 0 : e4.type, t: Date.now() };
                r2.isUser && (a.isContact = !(null === (t3 = r2.chatstate) || void 0 === t3 ? void 0 : t3.deny)), r2.isGroup && (a.participants = r2.chatstates.getModelsArray().filter((e5) => !!e5.type).map((e5) => {
                  const t4 = o.ContactStore.get(e5.id);
                  return { id: e5.id.toString(), state: e5.type, shortName: t4 ? t4.formattedShortName : "" };
                })), n.internalEv.emit("chat.presence_change", a);
              });
            });
          });
        }, 37740(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(62857), l = r(14647), d = r(54993), f = r(52757);
          u.onFullReady(function() {
            (0, d.wrapModuleFunction)(f.createOrUpdateReactions, (e2, ...t2) => {
              const [r2] = t2, n2 = Date.now();
              if (Array.isArray(r2)) for (const e3 of r2) try {
                if (e3.t < n2) continue;
                s.internalEv.emitAsync("chat.new_reaction", { id: l.MsgKey.fromString(e3.id), orphan: e3.orphan, orphanReason: e3.orphanReason, msgId: l.MsgKey.fromString(e3.reactionParentKey), reactionText: e3.reactionText, read: e3.read, sender: (0, c.createWid)(e3.from), timestamp: e3.t });
              } catch (e4) {
              }
              else try {
                if (t2[1]) {
                  if (p[r2.msgKey]) return e2(...t2);
                  p[r2.msgKey] = r2, s.internalEv.emitAsync("chat.new_reaction", { id: l.MsgKey.fromString(r2.msgKey), orphan: r2.orphan, orphanReason: null, msgId: l.MsgKey.fromString(r2.parentMsgKey), reactionText: r2.reactionText, read: r2.read, sender: (0, c.createWid)(r2.senderUserJid), timestamp: r2.t }), setTimeout(() => {
                    delete p[r2.msgKey];
                  }, 1e4);
                }
              } catch (e3) {
              }
              return e2(...t2);
            });
          });
          const p = [];
        }, 67147(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(() => function() {
            const e2 = c.MsgStore.processMultipleMessages, t2 = ["revoke", "sender_revoke", "admin_revoke"];
            c.MsgStore.processMultipleMessages = (r2, n2, ...o2) => new Promise((i2, a2) => {
              try {
                for (const e3 of n2) e3.isNewMsg && "protocol" === e3.type && t2.includes(e3.subtype) && s.internalEv.emit("chat.msg_revoke", { author: e3.author, from: e3.from, id: e3.id, refId: e3.protocolMessageKey, to: e3.to, type: e3.subtype });
              } catch (e3) {
              }
              e2.call(c.MsgStore, r2, n2, ...o2).then(i2, a2);
            });
          }());
        }, 59798(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(() => {
            c.ChatStore.on("change:unreadCount", (e2, t2, r2) => {
              l && clearTimeout(l), l = setTimeout(() => {
                s.internalEv.emit("chat.unread_count_changed", { chat: e2, unreadCount: t2, previousUnreadCount: r2 });
              }, 50);
            });
          });
          let l = null;
        }, 95071(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.archive = c, t.unarchive = async function(e2) {
            return c(e2, false);
          };
          const n = r(75828), o = r(41687), i = r(62857), a = r(14647), s = r(19198), u = r(52757);
          async function c(e2, t2 = true) {
            const r2 = (0, o.assertWid)(e2), c2 = (0, o.assertGetChat)(r2);
            if (c2.archive === t2) throw new i.WPPError((t2 ? "archive" : "unarchive") + "_error", `The chat ${r2.toString()} is already ${t2 ? "archived" : "unarchived"}`, { wid: r2, archive: t2 });
            return (0, n.compare)(s.SANITIZED_VERSION_STR, "2.3000.0", ">=") ? a.Cmd.archiveChat(c2, t2) : await (0, u.setArchive)(c2, t2), { wid: r2, archive: t2 };
          }
        }, 15035(e, t) {
          "use strict";
          t.encryptAndParserMsgButtons = async function(e2, t2, r, n, o, i, a) {
            var s, u;
            "function" == typeof i && (a = i);
            const c = [];
            if (null === (u = null === (s = null == t2 ? void 0 : t2.viewOnceMessage) || void 0 === s ? void 0 : s.message) || void 0 === u ? void 0 : u.interactiveMessage) {
              const s2 = function(e3, t3) {
                var r2, n2, o2, i2, a2, s3, u2, c2, l2;
                const d = t3.filter((e4) => !e4.device), f = t3.filter((e4) => e4.device), p = null === (n2 = null === (r2 = e3.viewOnceMessage) || void 0 === r2 ? void 0 : r2.message) || void 0 === n2 ? void 0 : n2.interactiveMessage;
                let g = false;
                const m = JSON.parse(JSON.stringify(e3));
                if (p) {
                  const t4 = ["documentMessage", "documentWithCaptionMessage", "imageMessage", "videoMessage"];
                  let r3, n3 = 1;
                  for (let e4 of t4) if (e4 in p.header) {
                    const t5 = e4;
                    "documentWithCaptionMessage" === e4 && (e4 = "documentMessage"), r3 = { [t5]: p.header[t5] }, n3 = "imageMessage" == t5 ? 4 : t5.includes("document") ? 3 : "videoMessage" == t5 ? 5 : 1;
                    break;
                  }
                  const d2 = { message: { buttonsMessage: Object.assign(Object.assign({ headerType: n3, contentText: (null === (o2 = null == p ? void 0 : p.body) || void 0 === o2 ? void 0 : o2.text) || " ", footerText: (null === (i2 = null == p ? void 0 : p.footer) || void 0 === i2 ? void 0 : i2.text) || " " }, r3), { buttons: null === (a2 = null == p ? void 0 : p.nativeFlowMessage) || void 0 === a2 ? void 0 : a2.buttons.map((e4, t5) => {
                    var r4, n4;
                    return "quick_reply" == e4.name ? { type: 1, buttonId: (null === (r4 = JSON.parse(e4.buttonParamsJson)) || void 0 === r4 ? void 0 : r4.id) || `${t5}`, buttonText: { displayText: (null === (n4 = JSON.parse(e4.buttonParamsJson)) || void 0 === n4 ? void 0 : n4.display_text) || " " } } : (g = true, null);
                  }).filter((e4) => null != e4) }) } }, f2 = { message: { templateMessage: { hydratedTemplate: Object.assign(Object.assign(Object.assign({ hydratedButtons: null === (s3 = null == p ? void 0 : p.nativeFlowMessage) || void 0 === s3 ? void 0 : s3.buttons.map((e4, t5) => {
                    var r4, n4, o3, i3, a3, s4, u3, c3;
                    return "quick_reply" == e4.name ? { index: t5, quickReplyButton: { displayText: (null === (r4 = JSON.parse(e4.buttonParamsJson)) || void 0 === r4 ? void 0 : r4.display_text) || " ", id: (null === (n4 = JSON.parse(e4.buttonParamsJson)) || void 0 === n4 ? void 0 : n4.id) || `${t5}` } } : "cta_url" == e4.name ? { index: t5, urlButton: { displayText: (null === (o3 = JSON.parse(e4.buttonParamsJson)) || void 0 === o3 ? void 0 : o3.display_text) || " ", url: null === (i3 = JSON.parse(e4.buttonParamsJson)) || void 0 === i3 ? void 0 : i3.url } } : "cta_copy" == e4.name ? { index: t5, urlButton: { displayText: (null === (a3 = JSON.parse(e4.buttonParamsJson)) || void 0 === a3 ? void 0 : a3.display_text) || " ", url: `https://www.whatsapp.com/otp/code/?otp_type=COPY_CODE&code=otp${null === (s4 = JSON.parse(e4.buttonParamsJson)) || void 0 === s4 ? void 0 : s4.copy_code}` } } : "cta_call" == e4.name ? { index: t5, callButton: { displayText: (null === (u3 = JSON.parse(e4.buttonParamsJson)) || void 0 === u3 ? void 0 : u3.display_text) || " ", phoneNumber: null === (c3 = JSON.parse(e4.buttonParamsJson)) || void 0 === c3 ? void 0 : c3.phone_number } } : null;
                  }).filter((e4) => null != e4) }, r3), 1 == n3 ? { hydratedTitleText: (null === (u2 = p.header) || void 0 === u2 ? void 0 : u2.title) || " " } : void 0), { hydratedContentText: (null === (c2 = null == p ? void 0 : p.body) || void 0 === c2 ? void 0 : c2.text) || " ", hydratedFooterText: (null === (l2 = null == p ? void 0 : p.footer) || void 0 === l2 ? void 0 : l2.text) || " " }) } } };
                  delete m.viewOnceMessage, m.documentWithCaptionMessage = g ? f2 : d2, m.messageContextInfo = e3.messageContextInfo;
                }
                return [{ proto: e3, devices: d }, { proto: m, devices: f }];
              }(t2, r);
              s2.map(async (t3) => {
                const r2 = await a(e2, t3.proto, t3.devices, n, o, "function" != typeof i ? i : void 0);
                c.push(...r2.stanza.content[0].content);
              });
            }
            const l = await a(e2, t2, r, n, o, "function" != typeof i ? i : void 0);
            c.length > 0 && (l.stanza.content[0].content = c);
            return l;
          };
        }, 31777(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.canMarkPlayed = async function(e2) {
            e2 instanceof n.MsgModel || "string" == typeof e2 || "function" != typeof e2.toString || (e2 = e2.toString());
            const t2 = e2 instanceof n.MsgModel ? e2 : await (0, i.getMessageById)(e2.toString());
            return (0, o.canMarkPlayed)(t2);
          };
          const n = r(14647), o = r(52757), i = r(17530);
        }, 10802(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.canMute = function(e2) {
            const t2 = (0, n.assertWid)(e2);
            return (0, n.assertGetChat)(t2).mute.canMute();
          };
          const n = r(41687);
        }, 50271(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.canReply = async function(e2) {
            e2 instanceof n.MsgModel || "string" == typeof e2 || "function" != typeof e2.toString || (e2 = e2.toString());
            const t2 = e2 instanceof n.MsgModel ? e2 : await (0, i.getMessageById)(e2.toString());
            return (0, o.canReplyMsg)(t2);
          };
          const n = r(14647), o = r(52757), i = r(17530);
        }, 1260(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.clear = async function(e2, t2 = true) {
            const r2 = (0, n.assertWid)(e2), i = (0, n.assertGetChat)(r2);
            (0, o.sendClear)(i, t2);
            let a = 200;
            if (i.promises.sendClear) {
              a = (await i.promises.sendClear.catch(() => ({ status: 500 }))).status || a;
            }
            return { wid: r2, status: a, keepStarred: t2 };
          };
          const n = r(41687), o = r(52757);
        }, 99459(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.closeChat = async function() {
            const e2 = (0, o.getActiveChat)();
            return !!e2 && (n.Cmd.closeChat(e2), true);
          };
          const n = r(14647), o = r(97829);
        }, 84378(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.delete = async function(e2) {
            const t2 = (0, n.assertWid)(e2), r2 = await (0, n.assertFindChat)(t2);
            (0, o.sendDelete)(r2);
            let i = 200;
            if (r2.promises.sendDelete) {
              i = (await r2.promises.sendDelete.catch(() => ({ status: 500 }))).status || i;
            }
            return { wid: t2, status: i };
          };
          const n = r(41687), o = r(52757);
        }, 74931(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.deleteMessage = async function(e2, t2, r2 = false, l = false) {
            const d = (0, o.assertGetChat)(e2);
            let f = false;
            Array.isArray(t2) || (f = true, t2 = [t2]);
            const p = await (0, c.getMessageById)(t2), g = [];
            for (const t3 of p) {
              let o2 = u.SendMsgResult.ERROR_UNKNOWN, c2 = false, f2 = false;
              const p2 = t3.senderObj.isMe;
              let m = false;
              d.id.isGroup() && (m = await (0, i.iAmAdmin)(e2));
              const y = p2 || m;
              t3.type === u.MSG_TYPE.REVOKED && l ? (o2 = u.SendMsgResult.ERROR_UNKNOWN, c2 = true) : l && y ? ("list" === t3.type && (t3.__x_isUserCreatedType = true), (0, n.compare)(s.SANITIZED_VERSION_STR, "2.3000.0", ">=") ? await a.Cmd.sendRevokeMsgs(d, { type: "message", list: [t3] }, { clearMedia: r2 }) : await a.Cmd.sendRevokeMsgs(d, [t3], { clearMedia: r2 }), o2 = u.SendMsgResult.OK, c2 = true) : ((0, n.compare)(s.SANITIZED_VERSION_STR, "2.3000.0", ">=") ? await a.Cmd.sendDeleteMsgs(d, { type: "message", list: [t3] }, r2) : await a.Cmd.sendDeleteMsgs(d, [t3], { clearMedia: r2 }), o2 = u.SendMsgResult.OK, f2 = !d.msgs.get(t3.id)), g.push({ id: t3.id.toString(), sendMsgResult: o2, isRevoked: c2, isDeleted: f2, isSentByMe: p2 });
            }
            return f ? g[0] : g;
          };
          const n = r(75828), o = r(41687), i = r(64456), a = r(14647), s = r(19198), u = r(20514), c = r(97829);
        }, 48157(e, t, r) {
          "use strict";
          var n = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.downloadMedia = async function e2(t2) {
            var r2;
            const n2 = await (0, s.getMessageById)(t2);
            if (!n2.mediaData) throw new i.WPPError("message_not_contains_media", `Message ${t2} not contains media`, { id: t2 });
            const o2 = n2.mediaData, c = async () => {
              var e3;
              const r3 = o2.filehash;
              if (r3 && "function" == typeof (null === a.LruMediaStore || void 0 === a.LruMediaStore ? void 0 : a.LruMediaStore.get)) {
                const e4 = await a.LruMediaStore.get(r3).catch(() => null), t3 = (0, i.toArrayBuffer)(e4);
                if (t3) return u("Media found in LruMediaStore cache for filehash", r3), new Blob([t3], { type: o2.mimetype || "application/octet-stream" });
              }
              if (r3 && (null === (e3 = null === a.MediaBlobCache || void 0 === a.MediaBlobCache ? void 0 : a.MediaBlobCache.has) || void 0 === e3 ? void 0 : e3.call(a.MediaBlobCache, r3))) return u("Media found in MediaBlobCache for filehash", r3), a.MediaBlobCache.get(r3);
              if (o2.mediaBlob) {
                const e4 = o2.mediaBlob.forceToBlob();
                if (e4) return u("Media found in mediaBlob for message", t2), e4;
              }
              return null;
            }, l = await c();
            if (l) return l;
            u("Downloading media for message", t2), await n2.downloadMedia({ downloadEvenIfExpensive: true, rmrReason: 1, isUserInitiated: true });
            const d = await c();
            if (!d && "VIDEO" === (null === (r2 = n2.mediaObject) || void 0 === r2 ? void 0 : r2.type)) {
              u("Retrying download as document for message", t2);
              try {
                return n2.type = "document", n2.mediaObject.type = "DOCUMENT", await e2(t2);
              } finally {
                n2.type = "video", n2.mediaObject.type = "VIDEO";
              }
            }
            if (!d) throw u("Media not found after download for message", t2), { error: true, code: "media_not_found", message: "Media not found" };
            return d;
          };
          const o = n(r(17833)), i = r(62857), a = r(14647), s = r(97829), u = (0, o.default)("WA-JS:chat:downloadMedia");
        }, 35090(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.editMessage = async function(e2, t2, r2 = {}) {
            r2 = Object.assign(Object.assign({}, a.defaultSendMessageOptions), r2);
            const u = await (0, s.getMessageById)(e2), c = (0, i.canEditMsg)(u), l = (0, i.canEditCaption)(u);
            if (!c && !l) throw new o.WPPError("edit_message_error", "Cannot edit this message");
            let d = { type: "protocol", subtype: "message_edit", protocolMessageKey: u.id, body: t2.trim(), caption: t2.trim(), editMsgType: u.type };
            const f = u.chat || (0, n.assertGetChat)(u.id.remote);
            return d = await (0, s.prepareRawMessage)(f, d, r2), d.latestEditMsgKey = d.id, d.latestEditSenderTimestampMs = d.t, await (0, s.sendRawMessage)(f.id, d, r2);
          };
          const n = r(41687), o = r(62857), i = r(52757), a = r(74023), s = r(97829);
        }, 36618(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.find = async function(e2) {
            var t2;
            const r2 = (0, n.assertWid)(e2), a = await (0, i.findOrCreateLatestChat)(r2, "newChatFlow");
            if (!(null === (t2 = null == a ? void 0 : a.chat) || void 0 === t2 ? void 0 : t2.id)) throw new Error(`Failed to find or create chat for ${r2.toString()}`);
            const s = o.ChatStore.get(a.chat.id);
            if (!s) throw new Error(`Chat not found in ChatStore for ${r2.toString()}`);
            s.id.isGroup() && await o.GroupMetadataStore.find(s.id);
            return s;
          };
          const n = r(41687), o = r(14647), i = r(52757);
        }, 74997(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.forwardMessage = async function(e2, t2, r2 = {}) {
            const a = await (0, n.assertFindChat)(e2), s = await (0, i.getMessageById)(t2);
            return await (0, o.forwardMessagesToChats)([s], [a], r2.displayCaptionText);
          };
          const n = r(41687), o = r(52757), i = r(74023);
        }, 59580(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.forwardMessages = async function(e2, t2, r2 = {}) {
            var s, u, c;
            const l = await (0, n.assertFindChat)(e2), d = [];
            for (const e3 of t2) e3 instanceof o.MsgModel ? d.push(e3) : d.push(await (0, a.getMessageById)(e3));
            return await (0, i.forwardMessages)({ chat: l, msgs: d, multicast: null !== (s = r2.multicast) && void 0 !== s && s, includeCaption: null !== (u = r2.displayCaptionText) && void 0 !== u && u, appendedText: null !== (c = r2.appendedText) && void 0 !== c && c });
          };
          const n = r(41687), o = r(14647), i = r(52757), a = r(17530);
        }, 78626(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.generateMessageID = async function(e2) {
            let t2, r2;
            t2 = e2 instanceof i.Wid ? e2 : e2 instanceof i.ChatModel ? e2.id : (0, n.assertWid)(e2);
            r2 = t2.isGroup() || t2.isLid() ? (0, o.getMyUserLid)() : (0, o.getMyUserWid)();
            const s = t2.isGroup() ? r2 : void 0;
            return new i.MsgKey({ from: r2, to: t2, id: await Promise.resolve((0, a.randomMessageId)()), participant: s, selfDir: "out" });
          };
          const n = r(41687), o = r(72927), i = r(14647), a = r(52757);
        }, 63829(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.get = function(e2) {
            const t2 = (0, n.assertWid)(e2);
            return "newsletter" === t2.server ? o.NewsletterStore.get(t2) : o.ChatStore.get(t2);
          };
          const n = r(41687), o = r(14647);
        }, 11513(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getActiveChat = function() {
            return n.ChatStore.findFirst((e2) => e2.active) || n.NewsletterStore.findFirst((e2) => e2.active);
          };
          const n = r(14647);
        }, 73546(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getLastSeen = async function(e2) {
            const t2 = (0, n.assertWid)(e2), r2 = await o.ChatStore.get(t2);
            if (!r2) return false;
            r2.presence.hasData || (await r2.presence.subscribe(), await new Promise((e3) => setTimeout(e3, 100)));
            return r2.presence.chatstate.t || false;
          };
          const n = r(41687), o = r(14647);
        }, 17181(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMessageACK = async function(e2) {
            const t2 = await (0, o.getMessageById)(e2), r2 = await n.MsgInfoStore.find(t2.id), i = /* @__PURE__ */ new Map(), a = (e3, t3) => {
              const r3 = e3.id.toString(), n2 = i.get(r3) || { id: r3, wid: e3.id };
              n2[t3] = e3.t, i.set(r3, n2);
            };
            return null == r2 || r2.delivery.forEach((e3) => a(e3, "deliveredAt")), null == r2 || r2.read.forEach((e3) => a(e3, "readAt")), null == r2 || r2.played.forEach((e3) => a(e3, "playedAt")), { ack: t2.ack, fromMe: t2.id.fromMe, deliveryRemaining: (null == r2 ? void 0 : r2.deliveryRemaining) || 0, readRemaining: (null == r2 ? void 0 : r2.readRemaining) || 0, playedRemaining: (null == r2 ? void 0 : r2.playedRemaining) || 0, participants: Array.from(i.values()) };
          };
          const n = r(14647), o = r(74023);
        }, 17530(e, t, r) {
          "use strict";
          var n = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.getMessageById = async function(e2) {
            var t2, r2, n2, o2;
            let l = false;
            Array.isArray(e2) || (l = true, e2 = [e2]);
            const d = e2.map((e3) => s.MsgKey.fromString(e3.toString()));
            let f = [];
            for (const e3 of d) {
              let l2 = s.MsgStore.get(e3);
              const d2 = "function" == typeof (null === (t2 = e3.remote) || void 0 === t2 ? void 0 : t2.isStatusV3) ? null === (r2 = e3.remote) || void 0 === r2 ? void 0 : r2.isStatusV3() : null === (o2 = null === (n2 = e3.remote) || void 0 === n2 ? void 0 : n2.toString()) || void 0 === o2 ? void 0 : o2.includes("status@broadcast");
              if (!l2) if (d2) l2 = s.StatusV3Store.getMyStatus().msgs.get(e3);
              else {
                const t3 = (0, i.assertGetChat)(e3.remote);
                if (l2 = t3.msgs.get(e3), !l2) {
                  c(`searching remote message with id ${e3.toString()}`);
                  const r3 = (0, u.callGetSearchContext)(t3, e3);
                  await r3.collection.loadAroundPromise, l2 = t3.msgs.get(e3) || r3.collection.get(e3);
                }
              }
              if (!l2) throw c(`message id ${e3.toString()} not found`), new a.WPPError("msg_not_found", `Message ${e3.toString()} not found`, { id: e3.toString() });
              f.push(l2);
            }
            if (f = f.map((e3) => e3 instanceof s.MsgModel ? e3 : s.MsgStore.get(e3) || new s.MsgModel(e3)), l) return f[0];
            return f;
          };
          const o = n(r(17833)), i = r(41687), a = r(62857), s = r(14647), u = r(90722), c = (0, o.default)("WA-JS:message:getMessageById");
        }, 48769(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMessages = async function(e2, t2 = {}) {
            var r2, u;
            const c = (0, n.assertGetChat)(e2);
            let l = t2.count || 20;
            const d = "after" === t2.direction ? "after" : "before", f = t2.id || (null === (r2 = c.lastReceivedKey) || void 0 === r2 ? void 0 : r2.toString());
            if (t2.onlyUnread) {
              if (!c.hasUnread) return [];
              const e3 = c.unreadCount < 0 ? 2 : c.unreadCount;
              l = l < 0 ? e3 : Math.min(l, e3);
            }
            -1 === l && (0, o.isMultiDevice)() && (l = 1 / 0);
            !t2.id && f && l--;
            const p = "function" == typeof s.msgFindQuery, g = p && f ? i.MsgKey.fromString(f) : { remote: c.id, count: l, direction: d };
            p && (g.count = l, g.direction = d);
            const m = f ? i.MsgKey.fromString(f) : void 0;
            let y = [];
            if ("all" === t2.media) if (p) {
              const { messages: e3 } = await (0, s.msgFindQuery)("media", g);
              Array.isArray(e3) && y.push(...e3);
            } else {
              const e3 = await (0, s.msgFindMedia)({ anchor: m, count: l, mediaType: "allMedia", direction: d, chat: c.id });
              Array.isArray(e3) ? y.push(...e3) : (null == e3 ? void 0 : e3.messages) && y.push(...e3.messages);
            }
            else if ("image" === t2.media) if (p) {
              const { messages: e3 } = await (0, s.msgFindQuery)("media", g);
              for (const t3 of e3) "image" === t3.type && y.push(t3);
            } else {
              const e3 = await (0, s.msgFindMedia)({ anchor: m, count: l, mediaType: "allMedia", direction: d, chat: c.id }), t3 = Array.isArray(e3) ? e3 : (null == e3 ? void 0 : e3.messages) || [];
              for (const e4 of t3) "image" === e4.type && y.push(e4);
            }
            else if (void 0 !== t2.media) if (p) {
              g.media = t2.media;
              const { messages: e3 } = await (0, s.msgFindQuery)("media", g);
              Array.isArray(e3) && y.push(...e3);
            } else {
              const e3 = await (0, s.msgFindMedia)({ anchor: m, count: l, mediaType: "document" === t2.media ? "allDocs" : "url" === t2.media ? "allLinks" : void 0, direction: d, chat: c.id });
              Array.isArray(e3) ? y.push(...e3) : (null == e3 ? void 0 : e3.messages) && y.push(...e3.messages);
            }
            else if (p) y = await (0, s.msgFindQuery)(d, g);
            else {
              if (!m) return [];
              const e3 = await (0, s.msgFindByDirection)({ anchor: m, count: l, direction: d });
              Array.isArray(e3) ? y.push(...e3) : (null == e3 ? void 0 : e3.messages) && y.push(...e3.messages);
            }
            if (!t2.id && f) {
              const e3 = i.MsgStore.get(f);
              e3 && y.push(e3.attributes);
            }
            if (y = y.map((e3) => ((null == t2 ? void 0 : t2.onlyUnread) && (e3.isNewMsg = true), e3 instanceof i.MsgModel ? e3 : i.MsgStore.get(e3) || new i.MsgModel(e3))), t2.includeCallMessages) try {
              let e3;
              if (e3 = p ? await (0, s.msgFindQuery)(a.MSG_TYPE.CALL_LOG, g) : await (0, s.msgFindCallLog)({ anchor: m, count: l }), e3 && e3.length > 0) {
                const t3 = e3.map((e4) => e4 instanceof i.MsgModel ? e4 : i.MsgStore.get(e4) || new i.MsgModel(e4));
                y.push(...t3), y.sort((e4, t4) => {
                  const r3 = e4.t || e4.timestamp || 0, n2 = t4.t || t4.timestamp || 0;
                  return "before" === d ? n2 - r3 : r3 - n2;
                }), l > 0 && l !== 1 / 0 && (y = y.slice(0, l));
              }
            } catch (e3) {
              console.warn("Could not retrieve call messages:", e3);
            }
            for (const e3 of y) null === (u = e3.id) || void 0 === u || u._serialized;
            return y;
          };
          const n = r(41687), o = r(72927), i = r(14647), a = r(20514), s = r(52757);
        }, 91520(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getNotes = async function(e2) {
            const t2 = (0, n.assertGetChat)(e2);
            if (!(0, o.isBusiness)()) throw new i.WPPError("connected_device_not_is_business", "Connected device not is business account");
            if (t2.id.isGroup()) throw new i.WPPError("can_not_get_notes_for_groups", `You can not get notes for groups. ChatId: ${e2}`);
            return await (0, a.retrieveOnlyNoteForChatJid)(t2.id.toJid());
          };
          const n = r(41687), o = r(5882), i = r(62857), a = r(33505);
        }, 55595(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getPlatformFromMessage = function(e2) {
            e2 instanceof n.MsgModel || "string" == typeof e2 || "function" != typeof e2.toString || (e2 = e2.toString());
            e2 instanceof n.MsgModel && (e2 = e2.id);
            const t2 = n.MsgKey.fromString(e2.toString());
            if (t2.id.length > 21) return "android";
            if (t2.id.startsWith("3A")) return "iphone";
            if (t2.id.startsWith("3EB0")) return "web";
            return "unknown";
          };
          const n = r(14647);
        }, 38636(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getQuotedMsg = async function(e2) {
            const t2 = await (0, o.getMessageById)(e2);
            if (!t2.quotedStanzaID) throw new n.WPPError("message_not_have_a_reply", `Message ${e2} does not have a reply`, { id: e2 });
            const r2 = (0, i.getQuotedMsgKey)(t2);
            return await (0, o.getMessageById)(r2);
          };
          const n = r(62857), o = r(17530), i = r(95885);
        }, 95885(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getQuotedMsgKey = function(e2) {
            var t2;
            if (!e2.quotedStanzaID) throw new o.WPPError("message_not_have_a_reply", `Message ${e2.id} does not have a reply`, { id: e2.id });
            const r2 = e2.quotedRemoteJid ? e2.quotedRemoteJid : e2.id.remote, a = (null === (t2 = (0, n.getMyUserId)()) || void 0 === t2 ? void 0 : t2.equals(e2.quotedParticipant)) || false, s = "function" == typeof i.Wid.isStatusV3 ? i.Wid.isStatusV3(r2) : i.Wid.isStatus(r2);
            return new i.MsgKey({ id: e2.quotedStanzaID, fromMe: a, remote: r2, participant: i.Wid.isGroup(e2.from) || i.Wid.isGroup(e2.to) || s ? e2.quotedParticipant : void 0 });
          };
          const n = r(72927), o = r(62857), i = r(14647);
        }, 20565(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getReactions = async function(e2) {
            const t2 = await (0, o.getReactions)(e2), r2 = [];
            for (const e3 of t2.reactions) {
              const t3 = { aggregateEmoji: e3.aggregateEmoji, hasReactionByMe: e3.hasReactionByMe, senders: [] };
              for (const r3 of e3.senders) t3.senders.push({ id: r3.msgKey, msgId: r3.parentMsgKey, reactionText: r3.reactionText, read: r3.read, sender: (0, n.createWid)(r3.senderUserJid), orphan: r3.orphan, timestamp: r3.timestamp });
              r2.push(t3);
            }
            return { reactionByMe: t2.reactionByMe ? { id: t2.reactionByMe.msgKey, orphan: t2.reactionByMe.orphan, msgId: t2.reactionByMe.parentMsgKey, reactionText: t2.reactionByMe.reactionText, read: t2.reactionByMe.read, senderUserJid: (0, n.createWid)(t2.reactionByMe.senderUserJid), timestamp: t2.reactionByMe.timestamp } : void 0, reactions: r2 };
          };
          const n = r(62857), o = r(52757);
        }, 81755(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getUnreadChats = async function(e2) {
            return e2 ? i : await (0, o.list)({ onlyWithUnreadMessage: true });
          };
          const n = r(13691), o = r(88241);
          let i = [];
          (0, n.on)("chat.unread_count_changed", (e2) => {
            e2.unreadCount > 0 ? i.find((t2) => {
              var r2;
              return t2.id === (null === (r2 = e2.chat) || void 0 === r2 ? void 0 : r2.id);
            }) || i.push(e2.chat) : i = i.filter((t2) => {
              var r2;
              return t2.id != (null === (r2 = e2.chat) || void 0 === r2 ? void 0 : r2.id);
            });
          });
        }, 39128(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getVotes = async function(e2) {
            const t2 = o.MsgKey.fromString(e2.toString()), r2 = await (0, a.getMessageById)(t2);
            if ("poll_creation" != r2.type) throw new n.WPPError("msg_not_found", `Message ${t2.toString()} not a poll`, { id: t2.toString() });
            const s = await (0, i.getVotes)([t2]), u = { msgId: t2, chatId: t2.remote, votes: [] };
            for (const e3 of s) {
              const t3 = { selectedOptions: [], timestamp: e3.senderTimestampMs, sender: e3.sender };
              for (const n2 of e3.selectedOptionLocalIds) t3.selectedOptions[n2] = r2.pollOptions.filter((e4) => e4.localId == n2)[0];
              u.votes.push(t3);
            }
            return u;
          };
          const n = r(62857), o = r(14647), i = r(52757), a = r(17530);
        }, 97829(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendCatalogMessage = t.requestPhoneNumber = t.replyToButtonMessage = t.prepareRawMessage = t.prepareMessageButtons = t.prepareLinkPreview = t.unpinMsg = t.pinMsg = t.unpin = t.pin = t.openChatFromUnread = t.openChatBottom = t.openChatAt = t.mute = t.markPlayed = t.markIsUnread = t.markIsRecording = t.markIsRead = t.markIsPaused = t.markIsComposing = t.list = t.keepMessage = t.getVotes = t.getUnreadChats = t.getReactions = t.getQuotedMsgKey = t.getQuotedMsg = t.getPlatformFromMessage = t.getNotes = t.getMessages = t.getMessageById = t.getMessageACK = t.getLastSeen = t.getActiveChat = t.get = t.generateMessageID = t.forwardMessages = t.forwardMessage = t.find = t.editMessage = t.downloadMedia = t.deleteMessage = t.delete = t.closeChat = t.clear = t.canReply = t.canMute = t.canMarkPlayed = t.unarchive = t.archive = void 0, t.unmute = t.starMessage = t.setNotes = t.setInputText = t.setChatList = t.sendVCardContactMessage = t.sendTextMessage = t.sendScheduledCallMessage = t.sendReactionToMessage = t.sendRawMessage = t.sendPixKeyMessage = t.sendLocationMessage = t.sendListMessage = t.sendGroupInviteMessage = t.sendFileMessage = t.sendEventMessage = t.sendCreatePollMessage = t.sendChargeMessage = void 0;
          var n = r(95071);
          Object.defineProperty(t, "archive", { enumerable: true, get: function() {
            return n.archive;
          } }), Object.defineProperty(t, "unarchive", { enumerable: true, get: function() {
            return n.unarchive;
          } });
          var o = r(31777);
          Object.defineProperty(t, "canMarkPlayed", { enumerable: true, get: function() {
            return o.canMarkPlayed;
          } });
          var i = r(10802);
          Object.defineProperty(t, "canMute", { enumerable: true, get: function() {
            return i.canMute;
          } });
          var a = r(50271);
          Object.defineProperty(t, "canReply", { enumerable: true, get: function() {
            return a.canReply;
          } });
          var s = r(1260);
          Object.defineProperty(t, "clear", { enumerable: true, get: function() {
            return s.clear;
          } });
          var u = r(99459);
          Object.defineProperty(t, "closeChat", { enumerable: true, get: function() {
            return u.closeChat;
          } });
          var c = r(84378);
          Object.defineProperty(t, "delete", { enumerable: true, get: function() {
            return c.delete;
          } });
          var l = r(74931);
          Object.defineProperty(t, "deleteMessage", { enumerable: true, get: function() {
            return l.deleteMessage;
          } });
          var d = r(48157);
          Object.defineProperty(t, "downloadMedia", { enumerable: true, get: function() {
            return d.downloadMedia;
          } });
          var f = r(35090);
          Object.defineProperty(t, "editMessage", { enumerable: true, get: function() {
            return f.editMessage;
          } });
          var p = r(36618);
          Object.defineProperty(t, "find", { enumerable: true, get: function() {
            return p.find;
          } });
          var g = r(74997);
          Object.defineProperty(t, "forwardMessage", { enumerable: true, get: function() {
            return g.forwardMessage;
          } });
          var m = r(59580);
          Object.defineProperty(t, "forwardMessages", { enumerable: true, get: function() {
            return m.forwardMessages;
          } });
          var y = r(78626);
          Object.defineProperty(t, "generateMessageID", { enumerable: true, get: function() {
            return y.generateMessageID;
          } });
          var v = r(63829);
          Object.defineProperty(t, "get", { enumerable: true, get: function() {
            return v.get;
          } });
          var b = r(11513);
          Object.defineProperty(t, "getActiveChat", { enumerable: true, get: function() {
            return b.getActiveChat;
          } });
          var h = r(73546);
          Object.defineProperty(t, "getLastSeen", { enumerable: true, get: function() {
            return h.getLastSeen;
          } });
          var _ = r(17181);
          Object.defineProperty(t, "getMessageACK", { enumerable: true, get: function() {
            return _.getMessageACK;
          } });
          var P = r(17530);
          Object.defineProperty(t, "getMessageById", { enumerable: true, get: function() {
            return P.getMessageById;
          } });
          var M = r(48769);
          Object.defineProperty(t, "getMessages", { enumerable: true, get: function() {
            return M.getMessages;
          } });
          var w = r(91520);
          Object.defineProperty(t, "getNotes", { enumerable: true, get: function() {
            return w.getNotes;
          } });
          var O = r(55595);
          Object.defineProperty(t, "getPlatformFromMessage", { enumerable: true, get: function() {
            return O.getPlatformFromMessage;
          } });
          var j = r(38636);
          Object.defineProperty(t, "getQuotedMsg", { enumerable: true, get: function() {
            return j.getQuotedMsg;
          } });
          var S = r(95885);
          Object.defineProperty(t, "getQuotedMsgKey", { enumerable: true, get: function() {
            return S.getQuotedMsgKey;
          } });
          var C = r(20565);
          Object.defineProperty(t, "getReactions", { enumerable: true, get: function() {
            return C.getReactions;
          } });
          var x = r(81755);
          Object.defineProperty(t, "getUnreadChats", { enumerable: true, get: function() {
            return x.getUnreadChats;
          } });
          var I = r(39128);
          Object.defineProperty(t, "getVotes", { enumerable: true, get: function() {
            return I.getVotes;
          } });
          var A = r(33985);
          Object.defineProperty(t, "keepMessage", { enumerable: true, get: function() {
            return A.keepMessage;
          } });
          var E = r(88241);
          Object.defineProperty(t, "list", { enumerable: true, get: function() {
            return E.list;
          } });
          var T = r(28921);
          Object.defineProperty(t, "markIsComposing", { enumerable: true, get: function() {
            return T.markIsComposing;
          } });
          var L = r(11598);
          Object.defineProperty(t, "markIsPaused", { enumerable: true, get: function() {
            return L.markIsPaused;
          } });
          var B = r(59680);
          Object.defineProperty(t, "markIsRead", { enumerable: true, get: function() {
            return B.markIsRead;
          } });
          var k = r(19345);
          Object.defineProperty(t, "markIsRecording", { enumerable: true, get: function() {
            return k.markIsRecording;
          } });
          var R = r(93119);
          Object.defineProperty(t, "markIsUnread", { enumerable: true, get: function() {
            return R.markIsUnread;
          } });
          var N = r(45351);
          Object.defineProperty(t, "markPlayed", { enumerable: true, get: function() {
            return N.markPlayed;
          } });
          var D = r(27112);
          Object.defineProperty(t, "mute", { enumerable: true, get: function() {
            return D.mute;
          } });
          var F = r(91082);
          Object.defineProperty(t, "openChatAt", { enumerable: true, get: function() {
            return F.openChatAt;
          } });
          var W = r(74212);
          Object.defineProperty(t, "openChatBottom", { enumerable: true, get: function() {
            return W.openChatBottom;
          } });
          var U = r(51464);
          Object.defineProperty(t, "openChatFromUnread", { enumerable: true, get: function() {
            return U.openChatFromUnread;
          } });
          var G = r(61278);
          Object.defineProperty(t, "pin", { enumerable: true, get: function() {
            return G.pin;
          } }), Object.defineProperty(t, "unpin", { enumerable: true, get: function() {
            return G.unpin;
          } });
          var q = r(6993);
          Object.defineProperty(t, "pinMsg", { enumerable: true, get: function() {
            return q.pinMsg;
          } }), Object.defineProperty(t, "unpinMsg", { enumerable: true, get: function() {
            return q.unpinMsg;
          } });
          var V = r(15952);
          Object.defineProperty(t, "prepareLinkPreview", { enumerable: true, get: function() {
            return V.prepareLinkPreview;
          } });
          var z = r(43394);
          Object.defineProperty(t, "prepareMessageButtons", { enumerable: true, get: function() {
            return z.prepareMessageButtons;
          } });
          var $ = r(19211);
          Object.defineProperty(t, "prepareRawMessage", { enumerable: true, get: function() {
            return $.prepareRawMessage;
          } });
          var J = r(4009);
          Object.defineProperty(t, "replyToButtonMessage", { enumerable: true, get: function() {
            return J.replyToButtonMessage;
          } });
          var K = r(58267);
          Object.defineProperty(t, "requestPhoneNumber", { enumerable: true, get: function() {
            return K.requestPhoneNumber;
          } });
          var H = r(88413);
          Object.defineProperty(t, "sendCatalogMessage", { enumerable: true, get: function() {
            return H.sendCatalogMessage;
          } });
          var Q = r(82028);
          Object.defineProperty(t, "sendChargeMessage", { enumerable: true, get: function() {
            return Q.sendChargeMessage;
          } });
          var Y = r(68011);
          Object.defineProperty(t, "sendCreatePollMessage", { enumerable: true, get: function() {
            return Y.sendCreatePollMessage;
          } });
          var Z = r(35824);
          Object.defineProperty(t, "sendEventMessage", { enumerable: true, get: function() {
            return Z.sendEventMessage;
          } });
          var X = r(24654);
          Object.defineProperty(t, "sendFileMessage", { enumerable: true, get: function() {
            return X.sendFileMessage;
          } });
          var ee = r(40954);
          Object.defineProperty(t, "sendGroupInviteMessage", { enumerable: true, get: function() {
            return ee.sendGroupInviteMessage;
          } });
          var te = r(35184);
          Object.defineProperty(t, "sendListMessage", { enumerable: true, get: function() {
            return te.sendListMessage;
          } });
          var re = r(39453);
          Object.defineProperty(t, "sendLocationMessage", { enumerable: true, get: function() {
            return re.sendLocationMessage;
          } });
          var ne = r(42992);
          Object.defineProperty(t, "sendPixKeyMessage", { enumerable: true, get: function() {
            return ne.sendPixKeyMessage;
          } });
          var oe = r(44190);
          Object.defineProperty(t, "sendRawMessage", { enumerable: true, get: function() {
            return oe.sendRawMessage;
          } });
          var ie = r(92774);
          Object.defineProperty(t, "sendReactionToMessage", { enumerable: true, get: function() {
            return ie.sendReactionToMessage;
          } });
          var ae = r(59633);
          Object.defineProperty(t, "sendScheduledCallMessage", { enumerable: true, get: function() {
            return ae.sendScheduledCallMessage;
          } });
          var se = r(68533);
          Object.defineProperty(t, "sendTextMessage", { enumerable: true, get: function() {
            return se.sendTextMessage;
          } });
          var ue = r(36356);
          Object.defineProperty(t, "sendVCardContactMessage", { enumerable: true, get: function() {
            return ue.sendVCardContactMessage;
          } });
          var ce = r(43859);
          Object.defineProperty(t, "setChatList", { enumerable: true, get: function() {
            return ce.setChatList;
          } });
          var le = r(18194);
          Object.defineProperty(t, "setInputText", { enumerable: true, get: function() {
            return le.setInputText;
          } });
          var de = r(31116);
          Object.defineProperty(t, "setNotes", { enumerable: true, get: function() {
            return de.setNotes;
          } });
          var fe = r(37126);
          Object.defineProperty(t, "starMessage", { enumerable: true, get: function() {
            return fe.starMessage;
          } });
          var pe = r(35291);
          Object.defineProperty(t, "unmute", { enumerable: true, get: function() {
            return pe.unmute;
          } });
        }, 33985(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.keepMessage = async function(e2, t2 = true) {
            const r2 = await (0, s.getMessageById)(e2);
            if (await (0, n.iAmAdmin)(r2.id.remote)) {
              if (r2.isExpired()) throw new o.WPPError("msg_expired", "This message has expired");
              return t2 ? (await (0, a.keepMessage)(r2, i.KIC_ENTRY_POINT_TYPE.CHAT), await (0, s.getMessageById)(e2)) : (await (0, a.undoKeepMessage)(r2, { deleteExpired: true }, i.KIC_ENTRY_POINT_TYPE.CHAT), await (0, s.getMessageById)(e2));
            }
            throw new o.WPPError("you_not_group_admin", "You is not a group admin");
          };
          const n = r(64456), o = r(62857), i = r(20514), a = r(52757), s = r(17530);
        }, 88241(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.list = async function(e2 = {}) {
            const t2 = null == e2.count ? 1 / 0 : e2.count, r2 = "before" === e2.direction ? "before" : "after";
            let i = e2.onlyNewsletter ? n.NewsletterStore.getModelsArray().slice() : n.ChatStore.getModelsArray().slice();
            e2.onlyUsers && (i = i.filter((e3) => e3.isUser));
            e2.onlyGroups && (i = i.filter((e3) => e3.id.isGroup()));
            e2.onlyCommunities && (i = i.filter((e3) => {
              var t3;
              return e3.id.isGroup() && "COMMUNITY" === (null === (t3 = e3.groupMetadata) || void 0 === t3 ? void 0 : t3.groupType);
            }));
            e2.onlyWithUnreadMessage && (i = i.filter((e3) => e3.hasUnread));
            e2.onlyArchived && (i = i.filter((e3) => e3.archive));
            if (e2.withLabels) {
              const t3 = e2.withLabels.map((e3) => {
                const t4 = n.LabelStore.findFirst((t5) => t5.name === e3);
                return t4 ? t4.id : e3;
              });
              i = i.filter((e3) => {
                var r3;
                return null === (r3 = e3.labels) || void 0 === r3 ? void 0 : r3.some((e4) => t3.includes(e4));
              });
            }
            const a = (null == e2 ? void 0 : e2.id) ? (0, o.get)(e2.id) : null, s = a ? i.indexOf(a) : 0;
            if ("before" === r2) {
              const e3 = s - t2 < 0 ? 0 : s - t2, r3 = e3 + t2 >= s ? s : e3 + t2;
              i = i.slice(e3, r3);
            } else i = i.slice(s, s + t2);
            if (!(null == e2 ? void 0 : e2.ignoreGroupMetadata)) for (const e3 of i) e3.id.isGroup() && await n.GroupMetadataStore.find(e3.id);
            return i;
          };
          const n = r(14647), o = r(63829);
        }, 28921(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.markIsComposing = async function(e2, t2) {
            const r2 = (0, n.assertGetChat)(e2);
            await r2.presence.subscribe(), await o.ChatPresence.markComposing(r2), r2.pausedTimerId && (clearTimeout(r2.pausedTimerId), r2.unset("pausedTimerId"));
            t2 && await new Promise((n2) => {
              r2.pausedTimerId = setTimeout(() => {
                (0, i.markIsPaused)(e2).then(n2, n2);
              }, t2);
            });
          };
          const n = r(41687), o = r(14647), i = r(97829);
        }, 11598(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.markIsPaused = async function(e2) {
            const t2 = (0, n.assertGetChat)(e2);
            await t2.presence.subscribe(), await o.ChatPresence.markPaused(t2);
          };
          const n = r(41687), o = r(14647);
        }, 59680(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.markIsRead = async function(e2) {
            const t2 = (0, o.assertGetChat)(e2), r2 = t2.unreadCount;
            (0, n.compare)(i.SANITIZED_VERSION_STR, "2.3000.1031992593", ">=") ? await (0, a.sendSeen)({ chat: t2, afterAvailable: false }) : await (0, a.sendSeen)(t2, false);
            return { wid: t2.id, unreadCount: r2 };
          };
          const n = r(75828), o = r(41687), i = r(19198), a = r(52757);
        }, 19345(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.markIsRecording = async function(e2, t2) {
            const r2 = (0, n.assertGetChat)(e2);
            await r2.presence.subscribe(), await o.ChatPresence.markRecording(r2), t2 && await new Promise((n2) => {
              r2.pausedTimerId = setTimeout(() => {
                (0, i.markIsPaused)(e2).then(n2, n2);
              }, t2);
            });
          };
          const n = r(41687), o = r(14647), i = r(97829);
        }, 93119(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.markIsUnread = async function(e2) {
            const t2 = (0, n.assertGetChat)(e2);
            return await (0, o.markUnread)(t2, true), { wid: t2.id };
          };
          const n = r(41687), o = r(52757);
        }, 45351(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.markPlayed = async function(e2) {
            e2 instanceof n.MsgModel || "string" == typeof e2 || "function" != typeof e2.toString || (e2 = e2.toString());
            const t2 = e2 instanceof n.MsgModel ? e2 : await (0, i.getMessageById)(e2.toString());
            return await (0, o.markPlayed)(t2), await (0, i.getMessageById)(e2.toString());
          };
          const n = r(14647), o = r(52757), i = r(17530);
        }, 27112(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.mute = async function(e2, t2) {
            const r2 = (0, n.assertWid)(e2), a = (0, n.assertGetChat)(r2);
            let s = 0;
            if ("expiration" in t2) s = "number" == typeof t2.expiration ? t2.expiration : t2.expiration.getTime() / 1e3;
            else {
              if (!("duration" in t2)) throw new o.WPPError("invalid_time_mute", "Invalid time for mute", { time: t2 });
              s = (0, i.unixTime)() + t2.duration;
            }
            if (s < (0, i.unixTime)()) throw new o.WPPError("negative_time_mute", "Negative duration for mute", { time: t2 });
            return await a.mute.mute({ expiration: s, isAutoMuted: false, sendDevice: true }), { wid: r2, expiration: a.mute.expiration, isMuted: 0 !== a.mute.expiration };
          };
          const n = r(41687), o = r(62857), i = r(52757);
        }, 91082(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.openChatAt = async function(e2, t2, r2) {
            const s = (0, n.assertWid)(e2), u = await (0, n.assertFindChat)(s), c = await (0, a.getMessageById)(t2);
            try {
              const e3 = (0, i.callGetSearchContext)(u, c);
              return await o.Cmd.openChatAt(u, e3);
            } catch (e3) {
              const t3 = (0, i.callGetSearchContext)(u, c.id._serialized);
              return await o.Cmd.openChatAt({ chat: u, msgContext: t3, chatEntryPoint: r2 });
            }
          };
          const n = r(41687), o = r(14647), i = r(90722), a = r(97829);
        }, 74212(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.openChatBottom = async function(e2, t2) {
            var r2;
            const s = (0, n.assertWid)(e2), u = await (0, a.findOrCreateLatestChat)(s, "newChatFlow");
            if (!(null === (r2 = null == u ? void 0 : u.chat) || void 0 === r2 ? void 0 : r2.id)) throw new Error(`Failed to find or create chat for ${s.toString()}`);
            const c = i.ChatStore.get(u.chat.id);
            if (!c) throw new Error(`Chat not found in ChatStore for ${s.toString()}`);
            if ((0, o.isWhatsAppVersionLTE)("2.3000.1029960097")) return await i.Cmd.openChatBottom(c, t2);
            return await i.Cmd.openChatBottom({ chat: c, chatEntryPoint: t2 });
          };
          const n = r(41687), o = r(64120), i = r(14647), a = r(52757);
        }, 51464(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.openChatFromUnread = async function(e2, t2) {
            var r2;
            const s = (0, n.assertWid)(e2), u = await (0, a.findOrCreateLatestChat)(s, "newChatFlow");
            if (!(null === (r2 = null == u ? void 0 : u.chat) || void 0 === r2 ? void 0 : r2.id)) throw new Error(`Failed to find or create chat for ${s.toString()}`);
            const c = i.ChatStore.get(u.chat.id);
            if (!c) throw new Error(`Chat not found in ChatStore for ${s.toString()}`);
            if ((0, o.isWhatsAppVersionLTE)("2.3000.1029960097")) return await i.Cmd.openChatFromUnread(c);
            return await i.Cmd.openChatFromUnread({ chat: c, chatEntryPoint: t2 });
          };
          const n = r(41687), o = r(64120), i = r(14647), a = r(52757);
        }, 61278(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.pin = a, t.unpin = async function(e2) {
            return a(e2, false);
          };
          const n = r(41687), o = r(62857), i = r(52757);
          async function a(e2, t2 = true) {
            const r2 = (0, n.assertWid)(e2), a2 = (0, n.assertGetChat)(r2);
            if (a2.pin === t2) throw new o.WPPError((t2 ? "pin" : "unpin") + "_error", `The chat ${r2.toString()} is already ${t2 ? "pinned" : "unpinned"}`, { wid: r2, pin: t2 });
            return await (0, i.setPin)(a2, t2), { wid: r2, pin: t2 };
          }
        }, 6993(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.pinMsg = c, t.unpinMsg = async function(e2) {
            return c(e2, false);
          };
          const n = r(41687), o = r(62857), i = r(14647), a = r(20514), s = r(52757), u = r(17530);
          async function c(e2, t2 = true, r2 = a.PinExpiryDurationOption.SevenDays) {
            var c2, l, d, f, p;
            let g = a.PinExpiryDurationOption.SevenDays;
            if ("number" == typeof r2) console.warn(`[WPP.chat.pinMsg] DEPRECATION WARNING: Passing numbers as duration is deprecated. The value ${r2} will be ignored and default to 7 days. Please use PinExpiryDurationOption enum instead (e.g., PinExpiryDurationOption.SevenDays).`), g = a.PinExpiryDurationOption.SevenDays;
            else {
              const e3 = Object.values(a.PinExpiryDurationOption);
              e3.includes(r2) ? g = r2 : (console.warn(`[WPP.chat.pinMsg] Invalid PinExpiryDurationOption: ${r2}. Falling back to SevenDays. Valid options: ${e3.join(", ")}`), g = a.PinExpiryDurationOption.SevenDays);
            }
            if ("boolean" != typeof t2) throw new o.WPPError("invalid_pin_parameter", "The 'pin' parameter must be a boolean. Received: " + typeof t2, { msgId: e2, pin: t2, duration: r2 });
            const m = await (0, u.getMessageById)(e2), y = (0, n.assertGetChat)(m.id.remote), v = i.PinInChatStore.getByParentMsgKey(m.id);
            if (y.id.isNewsletter()) throw new o.WPPError((t2 ? "pin" : "unpin") + "_error", `The msg ${e2.toString()} was not pinned. Not can pin in Newsletter`, { msgId: e2, pin: t2 });
            if (y.id.isGroup() && !(null === (l = null === (c2 = y.groupMetadata) || void 0 === c2 ? void 0 : c2.participants) || void 0 === l ? void 0 : l.iAmMember())) throw new o.WPPError((t2 ? "pin" : "unpin") + "_error", `You not a member of group, to pin msg ${e2.toString()}`, { msgId: e2, pin: t2 });
            if (y.id.isGroup() && ((null === (d = y.groupMetadata) || void 0 === d ? void 0 : d.restrict) || (null === (f = y.groupMetadata) || void 0 === f ? void 0 : f.announce)) && !(null === (p = y.groupMetadata) || void 0 === p ? void 0 : p.participants.iAmAdmin())) throw new o.WPPError((t2 ? "pin" : "unpin") + "_error", `You not have permission to pin msg ${e2.toString()}`, { msgId: e2, pin: t2 });
            if (m.isNotification || m.isViewOnce || m.type === a.MSG_TYPE.REVOKED || ((null == m ? void 0 : m.ack) || 0) < a.ACK.SENT) throw new o.WPPError((t2 ? "pin" : "unpin") + "_error", `The msg ${e2.toString()} not can be pinned`, { msgId: e2, pin: t2 });
            if (v && v.pinType === (t2 ? a.PIN_STATE.PIN : a.PIN_STATE.UNPIN)) throw new o.WPPError((t2 ? "pin" : "unpin") + "_error", `The msg ${e2.toString()} is already ${t2 ? "pinned" : "unpinned"}`, { msgId: e2, pin: t2 });
            const b = t2 ? g : void 0, h = await (0, s.sendPinInChatMsg)(m, true === t2 ? a.PIN_STATE.PIN : a.PIN_STATE.UNPIN, b);
            if (!h) throw new o.WPPError("pin_send_error", `Failed to ${t2 ? "pin" : "unpin"} message ${e2.toString()}`, { msgId: e2, pin: t2 });
            return { message: m, pinned: h.messageSendResult === a.SendMsgResult.OK ? t2 : !t2, result: h.messageSendResult };
          }
        }, 72185(e, t, r) {
          "use strict";
          var n = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.prepareAudioWaveform = async function(e2, t2) {
            if (!e2.isPtt || !e2.waveform) return;
            try {
              const e3 = await t2.arrayBuffer(), r2 = new AudioContext(), n2 = await r2.decodeAudioData(e3), o2 = n2.getChannelData(0), i = 64, a = Math.floor(o2.length / i), s = [];
              for (let e4 = 0; e4 < i; e4++) {
                const t3 = a * e4;
                let r3 = 0;
                for (let e5 = 0; e5 < a; e5++) r3 += Math.abs(o2[t3 + e5]);
                s.push(r3 / a);
              }
              const u = Math.pow(Math.max(...s), -1), c = s.map((e4) => e4 * u), l = new Uint8Array(c.map((e4) => Math.floor(100 * e4)));
              return { duration: Math.floor(n2.duration), waveform: l };
            } catch (e3) {
              o("Failed to generate waveform", e3);
            }
          };
          const o = (0, n(r(17833)).default)("WA-JS:chat:sendFileMessage");
        }, 15952(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          }), s = this && this.__rest || function(e2, t2) {
            var r2 = {};
            for (var n2 in e2) Object.prototype.hasOwnProperty.call(e2, n2) && t2.indexOf(n2) < 0 && (r2[n2] = e2[n2]);
            if (null != e2 && "function" == typeof Object.getOwnPropertySymbols) {
              var o2 = 0;
              for (n2 = Object.getOwnPropertySymbols(e2); o2 < n2.length; o2++) t2.indexOf(n2[o2]) < 0 && Object.prototype.propertyIsEnumerable.call(e2, n2[o2]) && (r2[n2[o2]] = e2[n2[o2]]);
            }
            return r2;
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.prepareLinkPreview = async function(e2, t2) {
            if (!t2.linkPreview) return e2;
            if (t2.linkPreview) {
              const r2 = "object" == typeof t2.linkPreview ? t2.linkPreview : {}, n2 = "chat" === e2.type ? e2.body : "";
              if (n2) try {
                const e3 = (0, d.findFirstWebLink)(n2);
                if (e3) {
                  const n3 = await (0, d.fetchLinkPreview)(e3);
                  (null == n3 ? void 0 : n3.data) && (t2.linkPreview = Object.assign(Object.assign({}, n3.data), r2));
                }
              } catch (e3) {
              }
            }
            "object" == typeof t2.linkPreview && (e2.subtype = "url", e2 = Object.assign(Object.assign({}, e2), t2.linkPreview));
            return e2;
          };
          const u = a(r(7222)), c = r(73113), l = r(54993), d = r(52757);
          u.onFullReady(() => {
            (0, l.wrapModuleFunction)(d.getABPropConfigValue, (e2, ...t2) => {
              const [r2] = t2;
              return "link_preview_wait_time" === r2 ? 7 : e2(...t2);
            }), (0, l.wrapModuleFunction)(d.genMinimalLinkPreview, async (e2, ...t2) => {
              const [r2] = t2, n2 = "string" == typeof r2 ? r2 : r2.url;
              return new Promise(async (r3) => {
                try {
                  const e3 = await (0, c.fetchRemoteLinkPreviewData)(n2);
                  if (!e3) throw new Error(`preview not found for ${n2}`);
                  const { imageUrl: t3 } = e3, o2 = s(e3, ["imageUrl"]);
                  let i2 = {};
                  t3 && (i2 = await (0, c.generateThumbnailLinkPreviewData)(t3).catch(() => null));
                  r3({ url: n2, data: Object.assign(Object.assign({}, o2), i2) });
                } catch (n3) {
                  r3(await e2(...t2));
                }
              });
            });
          });
        }, 43394(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.prepareMessageButtons = function(e2, t2) {
            if (!t2.buttons) return e2;
            if (!Array.isArray(t2.buttons)) throw new u.WPPError("buttons_not_a_array", "Buttons options is not a array");
            if ("chat" !== e2.type && t2.buttons.length > 2) throw new u.WPPError("not_alowed_more_then_three_buttons", "Not allowed more then three buttons in file messages");
            if (0 === t2.buttons.length || t2.buttons.length > 3) throw new u.WPPError("buttons_must_between_1_and_3_options", "Buttons options must have between 1 and 3 options");
            if (t2.buttons.find((e3) => e3.phoneNumber || e3.url) && t2.buttons.find((e3) => e3.id && e3.text)) throw new u.WPPError("reply_and_cta_btn_not_allowed", "It is not possible to send reply buttons and action buttons togetherButtons options must have between 1 and 3 options");
            return e2.title = t2.title, e2.footer = t2.footer, e2.interactiveMessage = { header: { title: t2.title || " ", hasMediaAttachment: false }, body: { text: e2.body || e2.caption || " " }, footer: { text: t2.footer || " " }, nativeFlowMessage: { buttons: t2.buttons.map((e3, t3) => "phoneNumber" in e3 ? { name: "cta_call", buttonParamsJson: JSON.stringify({ display_text: e3.text, phone_number: e3.phoneNumber }) } : "url" in e3 ? { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: e3.text, url: e3.url, merchant_url: e3.url }) } : "code" in e3 ? { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: e3.text, copy_code: e3.code }) } : "raw" in e3 ? e3.raw : { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: e3.text, id: e3.id || `${t3}` }) }) } }, e2.isFromTemplate = true, e2.buttons = new c.TemplateButtonCollection(), e2.hydratedButtons = t2.buttons.map((e3, t3) => "phoneNumber" in e3 ? { index: t3, callButton: { displayText: e3.text, phoneNumber: e3.phoneNumber } } : "url" in e3 ? { index: t3, urlButton: { displayText: e3.text, url: e3.url } } : "code" in e3 ? { index: t3, urlButton: { displayText: e3.text, url: `https://www.whatsapp.com/otp/code/?otp_type=COPY_CODE&code=otp${e3.code}` } } : { index: t3, quickReplyButton: { displayText: e3.text, id: e3.id || `${t3}` } }), e2.buttons.add(e2.hydratedButtons.map((e3, t3) => {
              var r2, n2, o2, i2;
              const a2 = `${null != e3.index ? e3.index : t3}`;
              return e3.urlButton ? new c.TemplateButtonModel({ id: a2, displayText: null === (r2 = e3.urlButton) || void 0 === r2 ? void 0 : r2.displayText, url: null === (n2 = e3.urlButton) || void 0 === n2 ? void 0 : n2.url, subtype: "url" }) : e3.callButton ? new c.TemplateButtonModel({ id: a2, displayText: e3.callButton.displayText, phoneNumber: e3.callButton.phoneNumber, subtype: "call" }) : new c.TemplateButtonModel({ id: a2, displayText: null === (o2 = e3.quickReplyButton) || void 0 === o2 ? void 0 : o2.displayText, selectionId: null === (i2 = e3.quickReplyButton) || void 0 === i2 ? void 0 : i2.id, subtype: "quick_reply" });
            })), e2;
          };
          const s = a(r(7222)), u = r(62857), c = r(14647), l = r(19198), d = r(54993), f = r(52757), p = r(15035);
          s.onFullReady(() => {
            (0, d.wrapModuleFunction)(f.createMsgProtobuf, (e2, ...t2) => {
              var r2, n2, o2, i2;
              const [a2] = t2, s2 = e2(...t2);
              if (void 0 !== (null === (n2 = null === (r2 = a2.interactiveMessage) || void 0 === r2 ? void 0 : r2.nativeFlowMessage) || void 0 === n2 ? void 0 : n2.buttons)) {
                const e3 = ["documentMessage", "documentWithCaptionMessage", "imageMessage", "locationMessage", "videoMessage"];
                for (let t3 of e3) if (t3 in s2) {
                  const e4 = t3;
                  "documentWithCaptionMessage" === t3 && (t3 = "documentMessage"), a2.interactiveMessage.header = Object.assign(Object.assign({}, a2.interactiveMessage.header), { [`${t3}`]: (null === (i2 = null === (o2 = s2[e4]) || void 0 === o2 ? void 0 : o2.message) || void 0 === i2 ? void 0 : i2.documentMessage) || s2[e4], hasMediaAttachment: true }), delete s2[e4];
                  break;
                }
                void 0 !== s2.extendedTextMessage && delete s2.extendedTextMessage, void 0 !== s2.conversation && delete s2.conversation, s2.viewOnceMessage = { message: { interactiveMessage: a2.interactiveMessage } };
              }
              return s2;
            }), (0, d.wrapModuleFunction)(f.encodeMaybeMediaType, (e2, ...t2) => {
              const [r2] = t2;
              return "button" === r2 ? l.DROP_ATTR : e2(...t2);
            }), (0, d.wrapModuleFunction)(f.mediaTypeFromProtobuf, (e2, ...t2) => {
              var r2, n2, o2, i2, a2, s2;
              const [u2] = t2;
              return (null === (o2 = null === (n2 = null === (r2 = u2.documentWithCaptionMessage) || void 0 === r2 ? void 0 : r2.message) || void 0 === n2 ? void 0 : n2.templateMessage) || void 0 === o2 ? void 0 : o2.hydratedTemplate) ? e2(null === (s2 = null === (a2 = null === (i2 = u2.documentWithCaptionMessage) || void 0 === i2 ? void 0 : i2.message) || void 0 === a2 ? void 0 : a2.templateMessage) || void 0 === s2 ? void 0 : s2.hydratedTemplate) : e2(...t2);
            }), (0, d.wrapModuleFunction)(f.typeAttributeFromProtobuf, (e2, ...t2) => {
              var r2, n2, o2, i2, a2, s2, u2, c2, l2, d2;
              const [f2] = t2;
              if (null === (r2 = null == f2 ? void 0 : f2.viewOnceMessage) || void 0 === r2 ? void 0 : r2.interactiveMessage) {
                const e3 = Object.keys(null === (n2 = null == f2 ? void 0 : f2.viewOnceMessage) || void 0 === n2 ? void 0 : n2.interactiveMessage);
                return ["documentMessage", "documentWithCaptionMessage", "imageMessage", "locationMessage", "videoMessage"].some((t3) => e3.includes(t3)) ? "media" : "text";
              }
              if (null === (a2 = null === (i2 = null === (o2 = null == f2 ? void 0 : f2.documentWithCaptionMessage) || void 0 === o2 ? void 0 : o2.message) || void 0 === i2 ? void 0 : i2.templateMessage) || void 0 === a2 ? void 0 : a2.hydratedTemplate) {
                const e3 = Object.keys(null === (c2 = null === (u2 = null === (s2 = null == f2 ? void 0 : f2.documentWithCaptionMessage) || void 0 === s2 ? void 0 : s2.message) || void 0 === u2 ? void 0 : u2.templateMessage) || void 0 === c2 ? void 0 : c2.hydratedTemplate);
                return ["documentMessage", "imageMessage", "locationMessage", "videoMessage"].some((t3) => e3.includes(t3)) ? "media" : "text";
              }
              return 1 === (null === (l2 = null == f2 ? void 0 : f2.buttonsMessage) || void 0 === l2 ? void 0 : l2.headerType) || 2 === (null === (d2 = null == f2 ? void 0 : f2.buttonsMessage) || void 0 === d2 ? void 0 : d2.headerType) ? "text" : e2(...t2);
            }), (0, d.wrapModuleFunction)(f.createFanoutMsgStanza, async (e2, ...t2) => {
              var r2, n2, o2;
              let i2 = null;
              const a2 = t2, s2 = 1 === a2.length && void 0 !== (null === (r2 = a2[0]) || void 0 === r2 ? void 0 : r2.msgProtobuf) ? a2[0] : null, u2 = s2 ? s2.msgProtobuf : a2[1].id ? a2[2] : a2[1];
              if (u2.buttonsMessage) i2 = c.websocket.smax("buttons");
              else if (u2.listMessage) {
                const e3 = 2, t3 = ["unknown", "single_select", "product_list"];
                i2 = c.websocket.smax("list", { v: "2", type: t3[e3] });
              }
              let l2 = await e2(...a2);
              if (null === (o2 = null === (n2 = null == u2 ? void 0 : u2.viewOnceMessage) || void 0 === n2 ? void 0 : n2.message) || void 0 === o2 ? void 0 : o2.interactiveMessage) if (s2) {
                const t3 = (t4, r3, n3, o3, i3, a3) => e2(Object.assign(Object.assign({}, s2), { msgRecord: t4, msgProtobuf: r3, deviceList: n3, option: o3, metricReporter: i3, groupData: a3 }));
                l2 = await (0, p.encryptAndParserMsgButtons)(s2.msgRecord, s2.msgProtobuf, s2.deviceList, s2.option, s2.metricReporter, s2.groupData, t3);
              } else l2 = await p.encryptAndParserMsgButtons(...a2, e2);
              if (!i2) return l2;
              const d2 = l2.content || l2.stanza.content;
              let f2 = d2.find((e3) => "biz" === e3.tag);
              f2 || (f2 = c.websocket.smax("biz", {}, null), d2.push(f2));
              let g = false;
              return Array.isArray(f2.content) ? g = !!f2.content.find((e3) => e3.tag === (null == i2 ? void 0 : i2.tag)) : f2.content = [], g || f2.content.push(i2), l2;
            }), (0, d.wrapModuleFunction)(f.getABPropConfigValue, (e2, ...t2) => {
              const [r2] = t2;
              return "web_unwrap_message_for_stanza_attributes" !== r2 && e2(...t2);
            });
          });
        }, 19211(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.prepareRawMessage = async function(e2, t2, r2 = {}) {
            var g, m, y;
            let v;
            r2 = Object.assign(Object.assign({}, l.defaultSendMessageOptions), r2), v = e2.id.isGroup() || e2.id.isLid() ? (0, o.getMyUserLid)() : (0, o.getMyUserWid)();
            t2 = Object.assign({ t: (0, c.unixTime)(), from: v, to: e2.id, self: "out", isNewMsg: true, local: true, ack: u.ACK.CLOCK }, t2), r2.delay && ("chat" == t2.type ? await (0, f.markIsComposing)(e2.id) : (null == r2 ? void 0 : r2.isPtt) && await (0, f.markIsRecording)(e2.id), await new Promise((e3) => setTimeout(() => e3(true), r2.delay)), await (0, f.markIsPaused)(e2.id));
            if ("protocol" !== t2.type) {
              const r3 = (0, c.getEphemeralFields)(e2);
              t2 = Object.assign(Object.assign({}, r3), t2);
            }
            (null === (g = e2.id) || void 0 === g ? void 0 : g.isBot()) && (t2 = Object.assign(Object.assign({}, t2), { messageSecret: await (0, c.genBotMsgSecretFromMsgSecret)(crypto.getRandomValues(new Uint8Array(32))), botPersonaId: s.BotProfileStore.get(null === (m = e2.id) || void 0 === m ? void 0 : m.toString()).personaId }));
            if (r2.messageId) {
              if ("string" == typeof r2.messageId && (r2.messageId = s.MsgKey.fromString(r2.messageId)), !r2.messageId.fromMe) throw new a.WPPError("message_key_is_not_from_me", "Message key is not from me", { messageId: r2.messageId.toString() });
              if (!r2.messageId.remote.equals(e2.id)) throw new a.WPPError("message_key_remote_id_is_not_same_of_chat", "Message key remote ID is not same of chat", { messageId: r2.messageId.toString() });
              t2.id = r2.messageId;
            }
            t2.id || (t2.id = await (0, f.generateMessageID)(e2));
            if (r2.mentionedList && !Array.isArray(r2.mentionedList)) throw new a.WPPError("mentioned_list_is_not_array", "The option mentionedList is not an array", { mentionedList: r2.mentionedList });
            if (r2.detectMentioned && e2.id.isGroup()) {
              const n2 = "chat" === t2.type ? t2.body : t2.caption;
              if (n2 && p.test(n2) && (t2.nonJidMentions = (t2.nonJidMentions || 0) | u.WAWebNonJidMentionType.MENTION_ALL), !r2.mentionedList || !r2.mentionedList.length) {
                r2.mentionedList = r2.mentionedList || [];
                const t3 = (null == n2 ? void 0 : n2.match(/(?<=@)(\d+)\b/g)) || [];
                if (t3.length > 0) {
                  const n3 = (await (0, i.getParticipants)(e2.id)).map((e3) => e3.id.toString());
                  for (const e3 of t3) {
                    const t4 = `${e3}@lid`, o2 = `${e3}@c.us`;
                    n3.includes(t4) ? r2.mentionedList.push(t4) : n3.includes(o2) && r2.mentionedList.push(o2);
                  }
                }
              }
            }
            if (r2.mentionedList) {
              const e3 = r2.mentionedList.map((e4) => e4 instanceof s.Wid ? e4 : (0, n.assertWid)(e4));
              for (const t3 of e3) if (!t3.isUser()) throw new a.WPPError("mentioned_is_not_user", "Mentioned is not an user", { mentionedId: t3.toString() });
              t2.mentionedJidList = e3;
            }
            let b = false;
            r2.quotedMsgPayload && (r2.quotedMsg = (0, d.rehydrateMessage)(r2.quotedMsgPayload), b = true);
            if (r2.quotedMsg) {
              if ("string" == typeof r2.quotedMsg && (r2.quotedMsg = s.MsgKey.fromString(r2.quotedMsg)), r2.quotedMsg instanceof s.MsgKey && (r2.quotedMsg = await (0, f.getMessageById)(r2.quotedMsg)), !(r2.quotedMsg instanceof s.MsgModel)) throw new a.WPPError("invalid_quoted_msg", "Invalid quotedMsg", { quotedMsg: r2.quotedMsg });
              if (!(null === (y = r2.quotedMsg) || void 0 === y ? void 0 : y.isStatusV3) && !(0, c.canReplyMsg)(r2.quotedMsg) && !b) throw new a.WPPError("quoted_msg_can_not_reply", "QuotedMsg can not reply", { quotedMsg: r2.quotedMsg });
              t2 = Object.assign(Object.assign({}, t2), r2.quotedMsg.msgContextInfo(e2.id));
            }
            return t2;
          };
          const n = r(41687), o = r(72927), i = r(64456), a = r(62857), s = r(14647), u = r(20514), c = r(52757), l = r(74023), d = r(8e3), f = r(97829), p = /(?<![\w@.+-])@all\b/;
        }, 4009(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.replyToButtonMessage = async function(e2, t2, r2) {
            const { buttonIndex: a } = r2, s = (0, i.get)(e2);
            if (!s) throw new n.WPPError("chat_not_found", `Chat ${e2} not found`);
            const u = s.msgs.get(t2);
            if (!u) throw new n.WPPError("message_not_found", `Message ${t2} not found`);
            if (!u.hydratedButtons || !Array.isArray(u.hydratedButtons)) throw new n.WPPError("no_buttons_in_message", "This message does not have buttons");
            if (a < 0 || a >= u.hydratedButtons.length) throw new n.WPPError("invalid_button_index", `Button index ${a} is out of range. Valid range: 0-${u.hydratedButtons.length - 1}`);
            const c = u.hydratedButtons[a];
            let l, d, f;
            if (c.quickReplyButton) l = c.quickReplyButton.id, d = c.quickReplyButton.displayText, f = "quick_reply";
            else if (c.urlButton) l = `${c.index}`, d = c.urlButton.displayText, f = "url";
            else {
              if (!c.callButton) throw new n.WPPError("unsupported_button_type", "This button type is not supported");
              l = `${c.index}`, d = c.callButton.displayText, f = "call";
            }
            if ("quick_reply" !== f) throw new n.WPPError("button_not_replyable", "Only quick reply buttons can be replied to. URL and Call buttons cannot be replied to programmatically.");
            const p = { quotedMsg: u, selectedIndex: c.index, selectedId: l };
            return await (0, o.sendTextMsgToChat)(s, d, p);
          };
          const n = r(62857), o = r(52757), i = r(63829);
        }, 58267(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.requestPhoneNumber = async function(e2, t2 = {}) {
            t2 = Object.assign(Object.assign({}, i.defaultSendMessageOptions), t2);
            const r2 = (0, n.assertWid)(e2);
            if (!r2.isLid()) throw new o.WPPError("not_a_lid_chat", `requestPhoneNumber should not be called for non lid chat ${r2.toString()}`);
            return await (0, a.sendRawMessage)(e2, { type: "request_phone_number" }, t2);
          };
          const n = r(41687), o = r(62857), i = r(74023), a = r(97829);
        }, 88413(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendCatalogMessage = async function(e2, t2, r2) {
            var u, c, l, d;
            const f = Object.assign(Object.assign({}, a.defaultSendMessageOptions), r2);
            e2 = (0, n.assertWid)(e2), t2 = (0, n.assertWid)(t2);
            const p = i.CatalogStore.get(t2);
            if (!f.jpegThumbnail) {
              const e3 = null === (c = null === (u = null == p ? void 0 : p.productCollection) || void 0 === u ? void 0 : u._models[0]) || void 0 === c ? void 0 : c.imageCdnUrl;
              if (e3) try {
                const t3 = await (0, o.downloadImage)(e3);
                f.jpegThumbnail = t3.data.split(",", 2)[1];
              } catch (e4) {
              }
            }
            const g = `https://wa.me/c/${t2.toString().split("@")[0]}`;
            let m = {};
            return m = { type: "chat", description: null !== (l = null == f ? void 0 : f.description) && void 0 !== l ? l : "Learn more about this catalog", matchedText: g, subtype: "url", thumbnail: f.jpegThumbnail, thumbnailHeight: f.jpegThumbnail ? 100 : void 0, thumbnailWidth: f.jpegThumbnail ? 100 : void 0, title: null !== (d = null == f ? void 0 : f.title) && void 0 !== d ? d : "View catalog on WhatsApp", body: f.textMessage ? `${f.textMessage}
${g}` : g, richPreviewType: 0 }, await (0, s.sendRawMessage)(e2, m, f);
          };
          const n = r(41687), o = r(62857), i = r(14647), a = r(74023), s = r(97829);
        }, 82028(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendChargeMessage = async function(e2, t2, r2) {
            if (!t2 || !e2) throw new o.WPPError("parameter_not_fount", "Please, send all the required parameters");
            r2 = Object.assign(Object.assign({}, s.defaultSendMessageOptions), r2);
            const c = [];
            let l = 0, d = null;
            const f = (0, n.getMyUserWid)(), p = i.CatalogStore.get(f);
            for (const e3 of t2) if ("product" == e3.type) {
              const { data: t3 } = await (0, a.queryProduct)(f, e3.id, 100, 100, void 0, true);
              if (void 0 === t3) throw new o.WPPError("product_not_found", `The product id ${e3.id} not found`);
              const n2 = (null == p ? void 0 : p.productCollection).get(e3.id);
              if (!d) {
                d = n2.getProductImageCollectionHead().mediaData.preview.getBase64();
              }
              const i2 = { retailer_id: t3.id, name: t3.name, amount: { value: Number(t3.price), offset: Number(r2.offset) || 1e3 }, quantity: Number(e3.qnt || 1), isCustomItem: false, isQuantitySet: true };
              l += Number(t3.price) * Number(e3.qnt || 1), c.push(i2);
            } else {
              const t3 = { retailer_id: `custom-item-${(0, o.generateOrderUniqueId)()}`, name: e3.name, amount: { value: Number(e3.price), offset: Number(r2.offset) || 1e3 }, quantity: Number(e3.qnt || 1), isCustomItem: true, isQuantitySet: true };
              l += Number(e3.price) * Number(e3.qnt || 1), c.push(t3);
            }
            const g = l + Number((null == r2 ? void 0 : r2.tax) || 0) + Number((null == r2 ? void 0 : r2.shipping) || 0) - Number((null == r2 ? void 0 : r2.discount) || 0), m = { reference_id: (0, o.generateOrderUniqueId)(), type: "physical-goods", payment_configuration: "merchant_categorization_code", currency: await (0, a.currencyForCountryShortcode)(await (0, a.getCountryShortcodeByPhone)(i.UserPrefs.getMaybeMePnUser().user)), total_amount: { value: g, offset: Number(r2.offset) || 1e3 }, order_type: "ORDER", order: { status: "pending", items: c, subtotal: { value: Number(l), offset: Number(r2.offset) || 1e3 }, tax: (null == r2 ? void 0 : r2.tax) ? { value: null == r2 ? void 0 : r2.tax, offset: Number(r2.offset) || 1e3 } : null, shipping: (null == r2 ? void 0 : r2.shipping) ? { value: null == r2 ? void 0 : r2.shipping, offset: Number(r2.offset) || 1e3 } : null, discount: (null == r2 ? void 0 : r2.discount) ? { value: null == r2 ? void 0 : r2.discount, offset: Number(r2.offset) || 1e3 } : null }, payment_settings: void 0 !== r2.pix ? [{ pix_static_code: { key: r2.pix.key, key_type: r2.pix.keyType, merchant_name: r2.pix.name }, type: "pix_static_code" }, { cards: { enabled: true }, type: "cards" }] : void 0, external_payment_configurations: r2.payment_instruction ? [{ type: "payment_instruction", payment_instruction: r2.payment_instruction }] : void 0 }, y = { type: "interactive", caption: null == r2 ? void 0 : r2.notes, nativeFlowName: "order_details", interactiveType: "native_flow", interactiveHeader: { hasmediaAttachment: false, mediaType: void 0, subtitle: void 0, thumbnail: d, title: null }, interactivePayload: { buttons: [{ buttonParamsJson: JSON.stringify(m), name: "review_and_pay" }], messageVersion: 1 } };
            return await (0, u.sendRawMessage)(e2, y, r2);
          };
          const n = r(21942), o = r(62857), i = r(14647), a = r(52757), s = r(74023), u = r(97829);
        }, 68011(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendCreatePollMessage = async function(e2, t2, r2, i = {}) {
            i = Object.assign(Object.assign({}, n.defaultSendMessageOptions), i);
            const a = { type: "poll_creation", pollName: t2, pollOptions: r2.map((e3, t3) => ({ name: e3, localId: t3 })), pollEncKey: self.crypto.getRandomValues(new Uint8Array(32)), pollSelectableOptionsCount: i.selectableCount || 0, messageSecret: self.crypto.getRandomValues(new Uint8Array(32)) };
            return await (0, o.sendRawMessage)(e2, a, i);
          };
          const n = r(74023), o = r(97829);
        }, 35824(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendEventMessage = async function(e2, t2) {
            if ("string" == typeof (t2 = Object.assign(Object.assign({}, i.defaultSendMessageOptions), t2)).callType && "voice" != t2.callType && "video" != t2.callType) throw new n.WPPError("callType_is_invalid", `Param callType: ${t2.callType} is not a valid type call. Use voice or video`);
            const r2 = new Date(1e3 * t2.startTime);
            r2.setHours(r2.getHours() + 2);
            const s = Math.floor(r2.getTime() / 1e3), u = { type: "event_creation", eventName: t2.name || " ", eventLocation: null == t2 ? void 0 : t2.location, eventDescription: (null == t2 ? void 0 : t2.description) || " ", eventStartTime: t2.startTime, eventEndTime: (null == t2 ? void 0 : t2.endTime) || s, isEventCanceled: false, callType: t2.callType || 0, kind: "eventCreation", messageSecret: crypto.getRandomValues(new Uint8Array(32)), viewMode: "VISIBLE", eventJoinLink: "string" == typeof (null == t2 ? void 0 : t2.callType) ? await (0, o.createEventCallLink)(t2.startTime, t2.callType) : void 0 };
            return await (0, a.sendRawMessage)(e2, u, t2);
          };
          const n = r(62857), o = r(52757), i = r(74023), a = r(97829);
        }, 24654(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          }), s = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.sendFileMessage = async function(e2, t2, r2) {
            var n2, o2, i2;
            let a2;
            r2 = Object.assign(Object.assign(Object.assign({}, b.defaultSendMessageOptions), { type: "auto-detect", waveform: true }), r2), a2 = "status@broadcast" == (null == e2 ? void 0 : e2.toString()) ? new g.ChatModel({ id: (0, d.createWid)(v.STATUS_JID) }) : await (0, c.assertFindChat)(e2);
            const s2 = await (0, d.convertToFile)(t2, r2.mimetype, r2.filename), u2 = s2.name, l2 = (0, f.getMediaTypeForValidation)(r2.type, s2.type), y2 = "status@broadcast" === (null == e2 ? void 0 : e2.toString());
            try {
              const e3 = y2 ? "STATUS_TAB_CAMERA_PHOTO_LIBRARY" : null, t3 = p.MediaGatingUtils.getUploadLimit(l2, e3);
              if (P(`Validating file size: ${s2.size} bytes, limit for ${l2}: ${t3} bytes`), s2.size > t3) throw new d.WPPError("file_too_large", `File size ${(0, f.formatFileSize)(s2.size)} exceeds the upload limit of ${(0, f.formatFileSize)(t3)} for ${l2} files`, { fileSize: s2.size, limit: t3, mediaType: l2 });
            } catch (e3) {
              if (e3 instanceof d.WPPError) throw e3;
            }
            const M = await g.OpaqueData.createFromData(s2, s2.type), w = {};
            let O, j;
            "audio" === r2.type ? (w.isPtt = r2.isPtt, r2.isPtt && (O = r2.isViewOnce), w.precomputedFields = await (0, _.prepareAudioWaveform)(r2, s2)) : "image" === r2.type ? (O = r2.isViewOnce, j = (null == r2 ? void 0 : r2.isHD) ? 2560 : 1600) : "video" === r2.type ? (O = r2.isViewOnce, w.asGif = r2.isGif) : "document" === r2.type ? w.asDocument = true : "sticker" === r2.type && (w.asSticker = true);
            const S = g.MediaPrep.prepRawMedia(M, Object.assign(Object.assign({}, w), { maxDimension: j }));
            let C = await (0, h.prepareRawMessage)(a2, { caption: r2.caption || u2, filename: u2, footer: r2.footer, isCaptionByUser: null != r2.caption }, r2);
            C = (0, h.prepareMessageButtons)(C, r2), r2.markIsRead && (P("marking chat is read before send file"), await (0, h.markIsRead)(a2.id).catch(() => null));
            await S.waitForPrep();
            const x = S._mediaData || S.mediaData;
            (null == r2 ? void 0 : r2.isPtv) && (x.type = "ptv", x.fullHeight = 1128, x.fullWidth = 1128);
            P(`sending message (${r2.type}) with id ${C.id}`);
            const I = { caption: r2.caption, footer: r2.footer, isViewOnce: O, productMsgOptions: "status@broadcast" === e2 ? void 0 : C, addEvenWhilePreparing: false, type: C.type };
            let A;
            A = 1 === S.sendToChat.length ? S.sendToChat({ chat: a2, options: I }) : S.sendToChat(a2, I);
            let E = null;
            E = "status@broadcast" == (null === (n2 = C.to) || void 0 === n2 ? void 0 : n2.toString()) ? await function(e3) {
              var t3, r3;
              const n3 = /* @__PURE__ */ new Set(), o3 = e3.from;
              if (o3) {
                n3.add(o3.toString());
                const e4 = o3.isLid() ? null === (t3 = null === g.lidPnCache || void 0 === g.lidPnCache ? void 0 : g.lidPnCache.getPhoneNumber) || void 0 === t3 ? void 0 : t3.call(g.lidPnCache, o3) : null === (r3 = null === g.lidPnCache || void 0 === g.lidPnCache ? void 0 : g.lidPnCache.getCurrentLid) || void 0 === r3 ? void 0 : r3.call(g.lidPnCache, o3);
                e4 && n3.add(e4.toString());
              }
              return new Promise((e4, t4) => {
                const r4 = setTimeout(() => {
                  g.StatusV3Store.off("change:lastReceivedKey", i3), t4(new d.WPPError("timeout_on_register_status", "Timeout waiting for WhatsApp to register the status message", { from: null == o3 ? void 0 : o3.toString() }));
                }, 3e4);
                async function i3(t5, o4) {
                  n3.has(t5.id.toString()) && (g.StatusV3Store.off("change:lastReceivedKey", i3), clearTimeout(r4), e4(await (0, h.getMessageById)(o4)));
                }
                g.StatusV3Store.on("change:lastReceivedKey", i3);
              });
            }(C) : await new Promise((e3) => {
              a2.msgs.on("add", function t3(r3) {
                r3.id === C.id && (a2.msgs.off("add", t3), e3(r3));
              });
            });
            function T(e3, t3) {
              P(`message file ${E.id} is ${t3}`);
            }
            if (P(`message file ${E.id} queued`), E.on("change:mediaData.mediaStage", T), A.finally(() => {
              E.off("change:mediaData.mediaStage", T);
            }), "status@broadcast" !== e2) {
              let e3 = null;
              return r2.waitForAck && (P(`waiting ack for ${E.id}`), e3 = await A, P(`ack received for ${E.id} (ACK: ${E.ack}, SendResult: ${JSON.stringify(e3)})`)), { id: null === (o2 = E.id) || void 0 === o2 ? void 0 : o2.toString(), ack: E.ack, sendMsgResult: e3 };
            }
            {
              const e3 = await new Promise((e4, t3) => {
                const r3 = setTimeout(() => {
                  t3(new d.WPPError("timeout_on_send_status", "Timeout for wait response of send media status"));
                }, 3e4), n3 = setInterval(async () => {
                  const t4 = await (0, h.getMessageById)(E.id);
                  t4.ack > 0 && (clearInterval(n3), clearTimeout(r3), e4(t4));
                }, 1500);
              });
              return { id: null === (i2 = e3.id) || void 0 === i2 ? void 0 : i2.toString(), ack: e3.ack, sendMsgResult: { messageSendResult: m.SendMsgResult.OK } };
            }
          };
          const u = s(r(17833)), c = r(41687), l = a(r(7222)), d = r(62857), f = r(21294), p = a(r(14647)), g = r(14647), m = r(20514), y = r(54993), v = r(52757), b = r(74023), h = r(97829), _ = r(72185), P = (0, u.default)("WA-JS:message");
          l.onFullReady(() => {
            (0, y.wrapModuleFunction)(v.generateVideoThumbsAndDuration, async (e2, ...t2) => {
              const [r2] = t2;
              try {
                return await e2(...t2);
              } catch (e3) {
                if ("string" == typeof e3.message && e3.message.includes("MEDIA_ERR_SRC_NOT_SUPPORTED")) try {
                  const e4 = await r2.file.arrayBuffer(), t3 = (0, d.getVideoInfoFromBuffer)(e4);
                  return { duration: t3.duration, thumbs: r2.maxDimensions.map((e5) => function(e6, t4, r3) {
                    let n2 = null != t4 ? t4 : r3, o2 = null != e6 ? e6 : r3;
                    n2 > o2 ? n2 > r3 && (o2 *= r3 / n2, n2 = r3) : o2 > r3 && (n2 *= r3 / o2, o2 = r3);
                    const i2 = { width: Math.max(n2, 1), height: Math.max(o2, 1) }, a2 = document.createElement("canvas"), s2 = a2.getContext("2d");
                    return a2.width = i2.width, a2.height = i2.height, s2.fillStyle = "white", s2.fillRect(0, 0, a2.width, a2.height), { url: a2.toDataURL("image/jpeg"), width: i2.width, height: i2.height, fullWidth: e6, fullHeight: t4 };
                  }(t3.width, t3.height, e5)) };
                } catch (e4) {
                  console.error(e4);
                }
                throw e3;
              }
            }), (0, y.wrapModuleFunction)(v.processRawSticker, async (e2, ...t2) => {
              const [r2] = t2, n2 = await e2(...t2);
              if ("image/webp" === r2.type()) {
                const e3 = r2.forceToBlob(), t3 = await (0, d.blobToArrayBuffer)(e3);
                (0, v.isAnimatedWebp)(t3) && (n2.mediaBlob = await g.OpaqueData.createFromData(e3, r2.type()));
              }
              return n2;
            }), (0, y.wrapModuleFunction)(v.uploadMedia, async (e2, ...t2) => {
              const [r2] = t2;
              return "ptv" == r2.mediaType ? (r2.mediaType = "video", await e2(r2)) : await e2(...t2);
            });
          });
        }, 40954(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendGroupInviteMessage = async function(e2, t2) {
            if (!(t2 = Object.assign(Object.assign({}, a.defaultSendMessageOptions), t2)).groupName) {
              const e3 = await (0, o.ensureGroup)(t2.groupId);
              t2.groupName = e3.name;
            }
            if (!t2.jpegThumbnail) {
              const e3 = await (0, n.getProfilePictureUrl)(t2.groupId, false);
              if (e3) try {
                const r3 = await (0, i.downloadImage)(e3);
                t2.jpegThumbnail = r3.data.split(",", 2)[1];
              } catch (e4) {
              }
            }
            const r2 = `https://chat.whatsapp.com/${t2.inviteCode}`;
            let u = {};
            u = t2.inviteCodeExpiration ? { type: "groups_v4_invite", inviteGrpJpegThum: t2.jpegThumbnail, inviteCode: t2.inviteCode, inviteCodeExp: t2.inviteCodeExpiration || "", inviteGrp: t2.groupId, inviteGrpName: t2.groupName, comment: t2.caption } : { type: "chat", subtype: "url", thumbnail: t2.jpegThumbnail, thumbnailHeight: t2.jpegThumbnail ? 100 : void 0, thumbnailWidth: t2.jpegThumbnail ? 100 : void 0, title: t2.groupName, inviteGrpType: "DEFAULT", canonicalUrl: `https://chat.whatsapp.com/${t2.inviteCode}`, description: t2.caption ? `${t2.caption}
${r2}` : r2, body: t2.caption ? `${t2.caption}
${r2}` : r2, matchedText: `https://chat.whatsapp.com/${t2.inviteCode}`, richPreviewType: 0 };
            return await (0, s.sendRawMessage)(e2, u, t2);
          };
          const n = r(56191), o = r(64456), i = r(62857), a = r(74023), s = r(97829);
        }, 35184(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.sendListMessage = async function(e2, t2) {
            const r2 = (t2 = Object.assign(Object.assign({}, d.defaultSendMessageOptions), t2)).sections;
            if (!Array.isArray(r2)) throw new u.WPPError("invalid_list_type", "Sections must be an array");
            if (0 === r2.length || r2.length > 10) throw new u.WPPError("invalid_list_size", "Sections options must have between 1 and 10 options");
            const n2 = { type: "list", list: { buttonText: t2.buttonText, description: t2.description || " ", title: t2.title, footerText: t2.footer, listType: 1, sections: r2 }, footer: t2.footer };
            return await (0, f.sendRawMessage)(e2, n2, t2);
          };
          const s = a(r(7222)), u = r(62857), c = r(54993), l = r(52757), d = r(74023), f = r(97829);
          s.onFullReady(() => {
            (0, c.wrapModuleFunction)(l.typeAttributeFromProtobuf, (e2, ...t2) => {
              const [r2] = t2;
              return r2.listMessage ? "text" : e2(...t2);
            });
          });
        }, 39453(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.sendLocationMessage = async function(e2, t2) {
            const r2 = (t2 = Object.assign(Object.assign({}, l.defaultSendMessageOptions), t2)).name && t2.address ? `${t2.name}
${t2.address}` : t2.name || t2.address || "";
            "string" == typeof t2.lat && (t2.lat = parseFloat(t2.lat));
            "string" == typeof t2.lng && (t2.lng = parseFloat(t2.lng));
            let n2 = { type: "location", lat: t2.lat, lng: t2.lng, loc: r2, clientUrl: t2.url };
            return n2 = (0, f.prepareMessageButtons)(n2, t2), await (0, d.sendRawMessage)(e2, n2, t2);
          };
          const s = a(r(7222)), u = r(54993), c = r(52757), l = r(74023), d = r(97829), f = r(43394);
          s.onFullReady(() => {
            (0, u.wrapModuleFunction)(c.mediaTypeFromProtobuf, (e2, ...t2) => {
              const [r2] = t2;
              return r2.locationMessage ? null : e2(...t2);
            }), (0, u.wrapModuleFunction)(c.typeAttributeFromProtobuf, (e2, ...t2) => {
              const [r2] = t2;
              return r2.locationMessage ? "text" : e2(...t2);
            });
          });
        }, 42992(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendPixKeyMessage = async function(e2, t2, r2) {
            if (!(e2 && t2.keyType && t2.name && t2.key)) throw new n.WPPError("parameter_not_fount", "Please, send all the required parameters");
            r2 = Object.assign(Object.assign({}, o.defaultSendMessageOptions), r2);
            const a = { order: { items: [{ name: "", retailer_id: `custom-item-${(0, n.generateOrderUniqueId)()}`, amount: { offset: 1, value: 0 }, quantity: 0 }], order_type: "ORDER_WITHOUT_AMOUNT", status: "payment_requested", subtotal: { value: 0, offset: 1 } }, total_amount: { value: 0, offset: 1 }, reference_id: (0, n.generateOrderUniqueId)(), payment_settings: [{ type: "pix_static_code", pix_static_code: { key_type: t2.keyType, merchant_name: t2.name, key: t2.key } }, { type: "cards", cards: { enabled: false } }], external_payment_configurations: [{ payment_instruction: t2.instructions || "", type: "payment_instruction" }], additional_note: "", currency: "BRL", type: "physical-goods" }, s = { type: "interactive", caption: "", nativeFlowName: "payment_info", interactiveType: "native_flow", interactivePayload: { buttons: [{ buttonParamsJson: JSON.stringify(a), name: "payment_info" }], messageVersion: 1 }, messageSecret: self.crypto.getRandomValues(new Uint8Array(32)) };
            return await (0, i.sendRawMessage)(e2, s, r2);
          };
          const n = r(62857), o = r(74023), i = r(97829);
        }, 44190(e, t, r) {
          "use strict";
          var n = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.sendRawMessage = async function(e2, t2, r2 = {}) {
            var n2;
            r2 = Object.assign(Object.assign({}, d.defaultSendMessageOptions), r2);
            const o2 = await (0, i.assertFindChat)(e2);
            if (o2.id.isGroup() && o2.isParentGroup) {
              const e3 = u.GroupMetadataStore.get(null === (n2 = o2.id) || void 0 === n2 ? void 0 : n2.toString());
              if ("COMMUNITY" == (null == e3 ? void 0 : e3.groupType)) {
                const t3 = (0, a.getAnnouncementGroup)(e3.id);
                throw new s.WPPError("can_not_send_message_to_this_groupType", `You can not send message to this groupType 'COMMUNITY', send for Announcement Group. Correct announcement groupId: ${null == t3 ? void 0 : t3.toString()}`);
              }
            }
            t2 = await (0, f.prepareRawMessage)(o2, t2, r2), r2.markIsRead && (p("marking chat is read before send message"), await (0, f.markIsRead)(o2.id).catch(() => null));
            p(`sending message (${t2.type}) with id ${t2.id}`);
            let g = null;
            if ((null == o2 ? void 0 : o2.isNewsletter) && t2.type) {
              if (!["chat", "image", "video", "poll_creation"].includes(t2.type)) throw new s.WPPError("type_not_valid_for_newsletter", 'Please, send a valid type for send message to newsletter. Valid types: "chat", "image", "video", "poll_creation"');
              const e3 = new u.MsgModel(t2);
              await (0, l.addNewsletterMsgsRecords)([await (0, l.msgDataFromMsgModel)(e3)]);
              const r3 = await (0, l.sendNewsletterMessageJob)({ type: "chat" != t2.type || t2.editMsgType ? "poll_creation" == t2.type ? "pollCreation" : "media" : "text", msgData: t2, msg: new u.MsgModel(t2), newsletterJid: o2.id.toString() });
              o2.msgs.add(e3), r3.success && (e3.t = r3.ack.t, e3.serverId = r3.serverId), e3.updateAck(c.ACK.SENT, true), await (0, l.updateNewsletterMsgRecord)(e3), g = [e3, "OK"];
            } else if ("protocol" === t2.type && "message_edit" === t2.subtype) {
              const e3 = await (0, f.getMessageById)(t2.protocolMessageKey);
              await (0, l.addAndSendMessageEdit)(e3, t2), g = [await (0, f.getMessageById)(t2.protocolMessageKey), null];
            } else g = await (0, l.addAndSendMsgToChat)(o2, t2);
            p(`message ${t2.id} queued`);
            const m = await g[0];
            let y = null;
            r2.waitForAck && (p(`waiting ack for ${t2.id}`), g[1] && (y = await g[1]), p(`ack received for ${t2.id} (ACK: ${m.ack}, SendResult: ${null == y ? void 0 : y.messageSendResult})`));
            return Object.assign(Object.assign(Object.assign(Object.assign({ id: m.id.toString(), ack: m.ack }, m.latestEditMsgKey && { latestEditMsgKey: m.latestEditMsgKey }), m.from && { from: m.from.toString() }), o2 && { to: o2.id.toString() }), { sendMsgResult: y });
          };
          const o = n(r(17833)), i = r(41687), a = r(83874), s = r(62857), u = r(14647), c = r(20514), l = r(52757), d = r(74023), f = r(97829), p = (0, o.default)("WA-JS:message");
        }, 92774(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendReactionToMessage = async function(e2, t2) {
            e2 instanceof n.MsgModel || "string" == typeof e2 || "function" != typeof e2.toString || (e2 = e2.toString());
            const r2 = e2 instanceof n.MsgModel ? e2 : await (0, i.getMessageById)(e2.toString());
            t2 || (t2 = "");
            return { sendMsgResult: await (0, o.sendReactionToMsg)(r2, t2) };
          };
          const n = r(14647), o = r(52757), i = r(17530);
        }, 59633(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendScheduledCallMessage = async function(e2, t2) {
            var r2;
            return t2 = Object.assign(Object.assign({ callType: "voice" }, n.defaultSendMessageOptions), t2), await (0, o.sendEventMessage)(e2, Object.assign(Object.assign({}, t2), { name: t2.title, description: null == t2 ? void 0 : t2.description, callType: t2.callType, startTime: parseInt(null === (r2 = t2.scheduledTimestampMs) || void 0 === r2 ? void 0 : r2.toString()) / 1e3 }));
          };
          const n = r(74023), o = r(97829);
        }, 68533(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendTextMessage = async function(e2, t2, r2 = {}) {
            r2 = Object.assign(Object.assign({}, n.defaultSendMessageOptions), r2);
            let i = { body: t2, type: "chat", subtype: null, urlText: null, urlNumber: null };
            return i = (0, o.prepareMessageButtons)(i, r2), i = await (0, o.prepareLinkPreview)(i, r2), await (0, o.sendRawMessage)(e2, i, r2);
          };
          const n = r(74023), o = r(97829);
        }, 36356(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendVCardContactMessage = async function(e2, t2, r2 = {}) {
            r2 = Object.assign(Object.assign({}, a.defaultSendMessageOptions), r2), Array.isArray(t2) || (t2 = [t2]);
            const u = [];
            for (const e3 of t2) {
              let t3 = "", r3 = "";
              "object" == typeof e3 && "name" in e3 ? (t3 = e3.id.toString(), r3 = e3.name) : t3 = e3.toString();
              let a2 = i.ContactStore.get(t3);
              a2 || (a2 = new i.ContactModel({ id: (0, n.assertWid)(t3), name: r3 }));
              const s2 = (0, o.getMyUserWid)();
              !r3 && a2.id.equals(s2) && (r3 = a2.displayName), r3 && (a2 = new i.ContactModel(a2.attributes), a2.name = r3, Object.defineProperty(a2, "formattedName", { value: r3 }), Object.defineProperty(a2, "displayName", { value: r3 })), u.push(i.VCard.vcardFromContactModel(a2));
            }
            const c = {};
            1 === u.length ? (c.type = "vcard", c.body = u[0].vcard, c.vcardFormattedName = u[0].displayName) : (c.type = "multi_vcard", c.vcardList = u);
            return (0, s.sendRawMessage)(e2, c, r2);
          };
          const n = r(41687), o = r(21942), i = r(14647), a = r(74023), s = r(97829);
        }, 43859(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.FilterChatListTypes = void 0, t.setChatList = async function(e2, t2) {
            if (p = e2, !e2) throw new u.WPPError("send_type_filter", "Please send a valid type filter");
            if (e2 == g.LABELS && !t2) throw new u.WPPError("send_labelId", "Please send a valid label id");
            if (e2 == g.CUSTOM && !t2) throw new u.WPPError("send_ids", "Please send a valid ids");
            "string" == typeof t2 && (t2 = [t2]);
            return e2 == g.CUSTOM && t2 ? (f = new Set(t2), c.Cmd.setActiveFilter(), m(), { type: e2, list: t2 }) : e2 == g.ALL ? (c.Cmd.setActiveFilter(), m(), { type: e2 }) : e2 == g.LABELS ? (c.Cmd.setActiveFilter(g.LABELS, t2[0]), { type: e2 }) : (c.Cmd.setActiveFilter(e2), { type: e2 });
          }, t.wrapShouldAppearFunction = function(e2, t2) {
            const r2 = (...r3) => t2(e2, ...r3);
            return Object.defineProperties(r2, Object.getOwnPropertyDescriptors(d.getShouldAppearInList)), r2;
          };
          const s = a(r(7222)), u = r(62857), c = r(14647), l = r(54993), d = r(52757);
          let f = /* @__PURE__ */ new Set(), p = "all";
          var g;
          function m() {
            var e2;
            null === (e2 = null === c.ChatStore || void 0 === c.ChatStore ? void 0 : c.ChatStore.trigger) || void 0 === e2 || e2.call(c.ChatStore, "sort");
          }
          !function(e2) {
            e2.ALL = "all", e2.CUSTOM = "custom", e2.UNREAD = "unread", e2.PERSONAL = "personal", e2.NON_CONTACT = "non_contact", e2.GROUP = "group", e2.FAVORITES = "favorites", e2.CONTACT = "contact", e2.BUSINESS = "business", e2.BROADCAST = "broadcast", e2.LABELS = "labels", e2.ASSIGNED_TO_YOU = "assigned_to_you";
          }(g || (t.FilterChatListTypes = g = {})), s.onFullReady(function() {
            (0, l.wrapModuleFunction)(d.getShouldAppearInList, (e2, ...t2) => {
              const [r2] = t2;
              return p === g.CUSTOM ? function(e3) {
                var t3, r3;
                const n2 = e3.id;
                if (!n2) return false;
                if (f.has(n2.toString())) return true;
                if ("function" != typeof n2.isLid) return false;
                const o2 = n2.isLid() ? null === (t3 = null === c.lidPnCache || void 0 === c.lidPnCache ? void 0 : c.lidPnCache.getPhoneNumber) || void 0 === t3 ? void 0 : t3.call(c.lidPnCache, n2) : "c.us" === n2.server ? null === (r3 = null === c.lidPnCache || void 0 === c.lidPnCache ? void 0 : c.lidPnCache.getCurrentLid) || void 0 === r3 ? void 0 : r3.call(c.lidPnCache, n2) : void 0;
                return !!o2 && f.has(o2.toString());
              }(r2) : e2(...t2);
            }), (0, l.wrapModuleFunction)(d.isFilterExcludedFromSearchTreatmentInInboxFlow, (e2, ...t2) => {
              const [r2] = t2;
              return p === g.CUSTOM && void 0 !== r2 && (p = g.ALL), e2(...t2);
            });
          }, 1e3);
        }, 18194(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setInputText = async function(e2, t2) {
            const r2 = void 0 !== t2 ? await (0, n.assertFindChat)(t2) : (0, o.getActiveChat)();
            if (r2) return (null == r2 ? void 0 : r2.active) ? (r2.setComposeContents({ text: e2, timestamp: (0, s.unixTime)() }), a.ComposeBoxActions.setTextContent(r2, e2), r2.getComposeContents()) : (null == r2 || r2.setComposeContents({ text: e2, timestamp: (0, s.unixTime)() }), r2.getComposeContents());
            throw new i.WPPError("not_in_chat", "Not active chat or invalid wid value");
          };
          const n = r(41687), o = r(74023), i = r(62857), a = r(14647), s = r(52757);
        }, 31116(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setNotes = async function(e2, t2) {
            const r2 = (0, n.assertGetChat)(e2);
            if (!(0, o.isBusiness)()) throw new i.WPPError("connected_device_not_is_business", "Connected device not is business account");
            if (!t2) throw new i.WPPError("missing_content_for_notes", "Missing content for notes");
            if (r2.id.isGroup()) throw new i.WPPError("can_not_set_notes_for_groups", `You can not set notes for groups. ChatId: ${e2}`);
            const s = await (0, a.retrieveOnlyNoteForChatJid)(r2.id.toJid());
            return await (0, a.addOrEditNoteAction)({ actionType: s ? "edit" : "add", chatJid: r2.id.toJid(), content: t2, createdAt: Math.floor(Date.now() / 1e3), id: null == s ? void 0 : s.id, noteType: "unstructured" }, true), await (0, a.retrieveOnlyNoteForChatJid)(r2.id.toJid());
          };
          const n = r(41687), o = r(5882), i = r(62857), a = r(33505);
        }, 37126(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.starMessage = async function(e2, t2 = true) {
            let r2 = false;
            Array.isArray(e2) || (r2 = true, e2 = [e2]);
            const a = await (0, i.getMessageById)(e2), s = a.reduce((e3, t3) => {
              const r3 = t3.id.remote.toString();
              return e3[r3] = e3[r3] || [], e3[r3].push(t3), e3;
            }, {}), u = a.map((e3) => ({ id: e3.id.toString(), star: e3.star || false }));
            for (const e3 in s) {
              const r3 = (0, n.assertGetChat)(e3), i2 = s[e3];
              t2 ? o.Cmd.sendStarMsgs(r3, i2) : o.Cmd.sendUnstarMsgs(r3, i2), r3.promises.sendStarMsgs && await r3.promises.sendStarMsgs;
            }
            if (r2) return u[0];
            return u;
          };
          const n = r(41687), o = r(14647), i = r(97829);
        }, 35291(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.unmute = async function(e2) {
            const t2 = (0, n.assertWid)(e2);
            return (0, n.assertGetChat)(t2).mute.unmute({ sendDevice: true });
          };
          const n = r(41687);
        }, 74023(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), r(31853), r(72465), o(r(50175), t), o(r(97829), t), o(r(73298), t), o(r(8e3), t);
        }, 72465(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = a(r(7222)), u = r(14647), c = r(54993), l = r(52757);
          s.onFullReady(function() {
            (0, c.wrapModuleFunction)(l.mediaTypeFromProtobuf, (e2, ...t2) => {
              const [r2] = t2;
              if (r2.deviceSentMessage) {
                const { message: e3 } = r2.deviceSentMessage;
                return e3 ? (0, l.mediaTypeFromProtobuf)(e3) : null;
              }
              if (r2.ephemeralMessage) {
                const { message: e3 } = r2.ephemeralMessage;
                return e3 ? (0, l.mediaTypeFromProtobuf)(e3) : null;
              }
              if (r2.viewOnceMessage) {
                const { message: e3 } = r2.viewOnceMessage;
                return e3 ? (0, l.mediaTypeFromProtobuf)(e3) : null;
              }
              return e2(...t2);
            }), (0, c.wrapModuleFunction)(l.typeAttributeFromProtobuf, (e2, ...t2) => {
              const [r2] = t2;
              if (r2.ephemeralMessage) {
                const { message: e3 } = r2.ephemeralMessage;
                return e3 ? (0, l.typeAttributeFromProtobuf)(e3) : "text";
              }
              if (r2.deviceSentMessage) {
                const { message: e3 } = r2.deviceSentMessage;
                return e3 ? (0, l.typeAttributeFromProtobuf)(e3) : "text";
              }
              if (r2.viewOnceMessage) {
                const { message: e3 } = r2.viewOnceMessage;
                return e3 ? (0, l.typeAttributeFromProtobuf)(e3) : "text";
              }
              return e2(...t2);
            }), (0, c.wrapModuleFunction)(l.isUnreadTypeMsg, (e2, ...t2) => {
              const [r2] = t2;
              switch (r2.type) {
                case "buttons_response":
                case "hsm":
                case "list":
                case "list_response":
                case "template_button_reply":
                  return true;
              }
              return e2(...t2);
            }), (0, c.wrapModuleFunction)(l.createChatRecord, async (e2, ...t2) => {
              let r2 = 1e3;
              for (let n2 = 1; n2 <= 5; n2++) try {
                return await e2(...t2);
              } catch (e3) {
                if (5 === n2) throw e3;
                await new Promise((e4) => setTimeout(e4, r2)), r2 *= 2;
              }
            }), (0, c.wrapModuleFunction)(l.isLidMigrated, (e2, ...t2) => {
              try {
                return e2(...t2);
              } catch (e3) {
                return false;
              }
            });
          }, 1e3), s.onFullReady(function() {
            const e2 = { shouldAppearInList: u.functions.getShouldAppearInList, isUser: (e3) => e3.id.isUser(), isPSA: (e3) => e3.id.isPSA(), isGroup: (e3) => e3.id.isGroup(), isNewsletter: (e3) => e3.id.isNewsletter(), previewMessage: u.functions.getPreviewMessage, showChangeNumberNotification: u.functions.getShowChangeNumberNotification, hasUnread: u.functions.getHasUnread };
            for (const t2 in e2) {
              const r2 = e2[t2];
              void 0 === u.ChatModel.prototype[t2] && Object.defineProperty(u.ChatModel.prototype, t2, { get: function() {
                return r2(this);
              }, configurable: true });
            }
          });
        }, 73298(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
        }, 8e3(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(7345), t);
        }, 7345(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.rehydrateMessage = function(e2) {
            var t2;
            if (!e2) return;
            if (e2 instanceof n.MsgModel) return e2;
            const r2 = JSON.parse(e2);
            r2.quotedMsg && delete r2.quotedMsg;
            "string" == typeof r2.id ? r2.id = n.MsgKey.fromString(r2.id) : "object" == typeof r2.id && null !== r2.id && (r2.id = new n.MsgKey({ fromMe: r2.id.fromMe, remote: n.WidFactory.createWid(r2.id.remote), id: r2.id.id, participant: r2.id.participant ? n.WidFactory.createWid(r2.id.participant) : void 0 }));
            r2.from && (r2.from = n.WidFactory.createWid(r2.from));
            r2.to && (r2.to = n.WidFactory.createWid(r2.to));
            r2.author && (r2.author = n.WidFactory.createWid(r2.author));
            r2.messageSecret && "object" == typeof r2.messageSecret && (r2.messageSecret = new Uint8Array(Object.values(r2.messageSecret)));
            delete r2.rowId, delete r2.labels, delete r2.groupMentions, delete r2.nonJidMentions, delete r2.mentionedJidList;
            const o = new n.MsgModel(r2), i = null === (t2 = o.msgContextInfo) || void 0 === t2 ? void 0 : t2.bind(o);
            i && (o.msgContextInfo = function(e3) {
              const t3 = i(e3);
              return (null == t3 ? void 0 : t3.quotedMsg) && (delete t3.quotedMsg.messageSecret, delete t3.quotedMsg.streamingSidecar, delete t3.quotedMsg.mediaKey, delete t3.quotedMsg.mediaKeyTimestamp, delete t3.quotedMsg.directPath, delete t3.quotedMsg.filehash, delete t3.quotedMsg.encFilehash), t3;
            });
            return o;
          };
          const n = r(14647);
        }, 94605(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.addSubgroups = async function(e2, t2) {
            Array.isArray(t2) || (t2 = [t2]);
            const r2 = (0, n.assertWid)(e2), i = t2.map(n.assertWid);
            return await (0, o.sendLinkSubgroups)({ parentGroupId: r2, subgroupIds: i });
          };
          const n = r(41687), o = r(52757);
        }, 70378(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.create = async function(e2, t2, r2) {
            Array.isArray(r2) || (r2 = [r2]);
            const i = r2.map(n.assertWid), a = await (0, o.sendCreateCommunity)({ name: e2, desc: t2, closed: false }), s = await (0, o.sendLinkSubgroups)({ parentGroupId: a.wid, subgroupIds: i });
            return { wid: a.wid, subGroups: s };
          };
          const n = r(41687), o = r(52757);
        }, 64920(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.deactivate = async function(e2) {
            const t2 = (0, n.assertWid)(e2);
            return (0, o.sendDeactivateCommunity)({ parentGroupId: t2 });
          };
          const n = r(41687), o = r(52757);
        }, 58092(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.demoteParticipants = async function(e2, t2) {
            const { groupChat: r2, participants: n2 } = await (0, s.ensureGroupAndParticipants)(e2, t2);
            try {
              return await u.demoteCommunityParticipants(r2, n2), { participants: t2, success: true };
            } catch (e3) {
              return { participants: t2, success: false, error: e3 };
            }
          };
          const s = r(64456), u = a(r(52757));
        }, 9820(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getAnnouncementGroup = function(e2) {
            const t2 = (0, o.getSubgroups)(e2);
            for (const e3 of t2) {
              const t3 = n.GroupMetadataStore.get(e3.toString());
              if ("LINKED_ANNOUNCEMENT_GROUP" == (null == t3 ? void 0 : t3.groupType)) return t3.id;
            }
            return;
          };
          const n = r(14647), o = r(84460);
        }, 33110(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getParticipants = async function(e2) {
            const t2 = (0, n.assertWid)(e2);
            return (0, o.getCommunityParticipants)(t2);
          };
          const n = r(41687), o = r(52757);
        }, 84460(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getSubgroups = function(e2) {
            var t2, r2;
            const i = o.GroupMetadataStore.get(e2.toString());
            if (!i) throw new n.WPPError("group_not_exist", `GroupId ${null == e2 ? void 0 : e2.toString()} not exists`);
            if ((null === (t2 = i.joinedSubgroups) || void 0 === t2 ? void 0 : t2.length) > 0) return i.joinedSubgroups;
            return o.GroupMetadataStore.get(null === (r2 = i.parentGroup) || void 0 === r2 ? void 0 : r2.toString()).joinedSubgroups;
          };
          const n = r(62857), o = r(14647);
        }, 5728(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.removeSubgroups = t.promoteParticipants = t.getSubgroups = t.getParticipants = t.getAnnouncementGroup = t.demoteParticipants = t.deactivate = t.create = t.addSubgroups = void 0;
          var n = r(94605);
          Object.defineProperty(t, "addSubgroups", { enumerable: true, get: function() {
            return n.addSubgroups;
          } });
          var o = r(70378);
          Object.defineProperty(t, "create", { enumerable: true, get: function() {
            return o.create;
          } });
          var i = r(64920);
          Object.defineProperty(t, "deactivate", { enumerable: true, get: function() {
            return i.deactivate;
          } });
          var a = r(58092);
          Object.defineProperty(t, "demoteParticipants", { enumerable: true, get: function() {
            return a.demoteParticipants;
          } });
          var s = r(9820);
          Object.defineProperty(t, "getAnnouncementGroup", { enumerable: true, get: function() {
            return s.getAnnouncementGroup;
          } });
          var u = r(33110);
          Object.defineProperty(t, "getParticipants", { enumerable: true, get: function() {
            return u.getParticipants;
          } });
          var c = r(84460);
          Object.defineProperty(t, "getSubgroups", { enumerable: true, get: function() {
            return c.getSubgroups;
          } });
          var l = r(84498);
          Object.defineProperty(t, "promoteParticipants", { enumerable: true, get: function() {
            return l.promoteParticipants;
          } });
          var d = r(53650);
          Object.defineProperty(t, "removeSubgroups", { enumerable: true, get: function() {
            return d.removeSubgroups;
          } });
        }, 84498(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.promoteParticipants = async function(e2, t2) {
            const { groupChat: r2, participants: n2 } = await (0, s.ensureGroupAndParticipants)(e2, t2);
            return u.promoteCommunityParticipants(r2, n2);
          };
          const s = r(64456), u = a(r(52757));
        }, 53650(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.removeSubgroups = async function(e2, t2) {
            Array.isArray(t2) || (t2 = [t2]);
            const r2 = (0, n.assertWid)(e2), i = t2.map(n.assertWid);
            return await (0, o.sendUnlinkSubgroups)({ parentGroupId: r2, subgroupIds: i });
          };
          const n = r(41687), o = r(52757);
        }, 83874(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(5728), t);
        }, 10896(e, t) {
          "use strict";
          t.defaultConfig = void 0, t.defaultConfig = { deviceName: false, liveLocationLimit: 10, disableGoogleAnalytics: false, googleAnalyticsId: null, googleAnalyticsUserProperty: {}, linkPreviewApiServers: null, poweredBy: "WA-JS", sendStatusToDevice: false, syncAllStatus: true };
        }, 91491(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.config = void 0;
          const n = r(13691), o = r(10896), i = window.WPPConfig || {}, a = Object.assign(Object.assign({}, o.defaultConfig), i), s = (e2 = []) => ({ get: (t2, r2) => "isProxy" == r2 || ("object" == typeof t2[r2] && null != t2[r2] ? new Proxy(t2[r2], s([...e2, r2])) : t2[r2]), set: (r2, o2, i2) => {
            r2[o2] = i2;
            try {
              n.internalEv.emitAsync("config.update", { config: t.config, key: o2, path: [...e2, o2], target: r2, value: i2 });
            } catch (e3) {
            }
            return true;
          } });
          t.config = new Proxy(a, s()), window.WPPConfig = t.config;
        }, 58293(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), r(21899), r(87589), r(81549), r(75676), r(83400), r(77679), r(26), r(28952), r(19516), r(80739), r(96498), r(17459), r(53706);
        }, 21899(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647), l = r(72927);
          u.onInjected(function() {
            const e2 = async () => {
              const e3 = await (0, l.getAuthCode)().catch(() => null);
              s.internalEv.emit("conn.auth_code_change", e3);
            };
            e2(), c.Conn.on("change:ref", e2);
          });
        }, 87589(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647), l = r(72927);
          u.onInjected(function() {
            let e2 = (0, l.isAuthenticated)();
            const t2 = async () => {
              e2 || (s.internalEv.emit("conn.authenticated"), e2 = false);
            };
            c.Cmd.isMainLoaded ? t2() : c.Cmd.on("main_loaded", t2);
            c.Cmd.on("logout", () => {
              e2 = false;
            });
          });
        }, 81549(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(function() {
            const e2 = c.BackendEventBus.trigger.bind(c.BackendEventBus);
            c.BackendEventBus.trigger = function(t2, ...r2) {
              return s.internalEv.emit("conn.backend_event", t2, ...r2), e2(t2, ...r2);
            };
          });
        }, 75676(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(function() {
            c.Cmd.on("logout", () => s.internalEv.emit("conn.logout"));
          });
        }, 83400(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(54993), l = r(52757);
          u.onInjected(function() {
            (0, c.wrapModuleFunction)(l.getErrorCodeFromLogoutReason, (e2, ...t2) => {
              const [r2] = t2;
              return s.internalEv.emit("conn.logout_reason", r2), e2(...t2);
            });
          });
        }, 77679(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(60397);
          u.onInjected(function() {
            const e2 = setInterval(() => {
              (0, c.isMainInit)() && (clearInterval(e2), s.internalEv.emit("conn.main_init"));
            }, 100);
          });
        }, 26(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(function() {
            const e2 = async () => {
              s.internalEv.emit("conn.main_loaded");
            };
            c.Cmd.isMainLoaded ? e2() : c.Cmd.on("main_loaded", e2);
          });
        }, 28952(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          }), s = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true });
          const u = s(r(17833)), c = r(13691), l = a(r(7222)), d = r(20514), f = (0, u.default)("WA-JS:conn:main_ready");
          l.onInjected(function() {
            const e2 = (t2) => {
              ((e3) => e3 === d.StreamMode.MAIN || e3 === d.StreamMode.QR)(t2) && (f("emitting conn.main_ready"), c.internalEv.emit("conn.main_ready"), c.internalEv.off("conn.stream_mode_changed", e2));
            };
            c.internalEv.on("conn.stream_mode_changed", e2);
          });
        }, 19516(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(function() {
            const e2 = async () => {
              s.internalEv.emit("conn.needs_update");
            };
            c.Stream.needsUpdate ? e2() : c.Stream.on("change:needsUpdate", e2);
          });
        }, 80739(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(function() {
            c.NetworkStatus.on("change:online", (e2, t2) => {
              s.internalEv.emit("conn.online", t2);
            });
          });
        }, 96498(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647), l = r(72927);
          u.onInjected(function() {
            const e2 = async () => {
              (0, l.isIdle)() && s.internalEv.emit("conn.qrcode_idle");
            };
            e2(), c.Socket.on("change:state", e2);
          });
        }, 17459(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647), l = r(89763), d = r(72927);
          u.onInjected(function() {
            let e2 = false;
            const t2 = async () => {
              (0, d.isAuthenticated)() ? e2 = false : e2 || c.Socket.state !== l.SOCKET_STATE.UNPAIRED && c.Socket.state !== l.SOCKET_STATE.UNPAIRED_IDLE || (e2 = true, s.internalEv.emit("conn.require_auth"));
            };
            t2(), c.Socket.on("change:state", t2);
          });
        }, 53706(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(function() {
            c.Stream.mode && s.internalEv.emit("conn.stream_mode_changed", c.Stream.mode);
            c.Stream.info && s.internalEv.emit("conn.stream_info_changed", c.Stream.info);
            c.Stream.on("change:mode", (e2, t2) => {
              s.internalEv.emit("conn.stream_mode_changed", t2);
            }), c.Stream.on("change:info", (e2, t2) => {
              s.internalEv.emit("conn.stream_info_changed", t2);
            });
          });
        }, 79330(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.changeEnviromentDevice = function() {
            n.Enviroment.default.isWeb = !n.Enviroment.default.isWeb, n.Enviroment.default.isWindows = !n.Enviroment.default.isWindows;
          };
          const n = r(14647);
        }, 28904(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.genLinkDeviceCodeForPhoneNumber = async function(e2, t2 = true) {
            if (!e2 || "string" != typeof e2) throw new n.WPPError("send_the_phone_number_to_connect", "Can't get code for without phone number param");
            if ((0, i.isAuthenticated)()) throw new n.WPPError("cannot_get_code_for_already_authenticated", "Can't get code for already authenticated user");
            return await o.functions.initializeAltDeviceLinking(), await o.functions.genLinkDeviceCodeForPhoneNumber(e2, t2);
          };
          const n = r(62857), o = r(14647), i = r(60397);
        }, 34618(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.getABProps = function() {
            const e2 = s.getAllABPropConfigs();
            if (!e2) return [];
            return e2.map((e3) => Object.assign(Object.assign({}, e3), { name: u(String(e3.configCode)) }));
          }, t.getABPropsMap = function() {
            const e2 = s.getAllABPropsMap();
            if (!e2) return /* @__PURE__ */ new Map();
            const t2 = /* @__PURE__ */ new Map();
            return e2.forEach((e3, r2) => {
              t2.set(r2, Object.assign(Object.assign({}, e3), { name: u(String(e3.configCode)) }));
            }), t2;
          }, t.getABPropName = u;
          const s = a(r(35674));
          function u(e2) {
            return s.getABPropConfigNameFromCode(e2) || null;
          }
        }, 11102(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getAuthCode = async function() {
            if (!n.Conn.ref || n.Conn.connected || (0, i.isAuthenticated)() || (0, i.isRegistered)()) return null;
            const e2 = n.Conn.ref;
            if ((0, i.isMultiDevice)()) {
              const t2 = await o.waSignalStore.getRegistrationInfo(), r2 = await o.waNoiseInfo.get(), i2 = n.Base64.encodeB64(r2.staticKeyPair.pubKey), a = n.Base64.encodeB64(t2.identityKeyPair.pubKey), s = await Promise.resolve(o.adv.getADVSecretKey()), u = [e2, i2, a, s].join(",");
              return { type: "multidevice", ref: e2, staticKeyPair: i2, identityKeyPair: a, secretKey: s, fullCode: u };
            }
            return null;
          };
          const n = r(14647), o = r(83703), i = r(60397);
        }, 20027(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getAutoDownloadSettings = function() {
            return { photos: (0, n.getAutoDownloadPhotos)(), audio: (0, n.getAutoDownloadAudio)(), videos: (0, n.getAutoDownloadVideos)(), documents: (0, n.getAutoDownloadDocuments)() };
          };
          const n = r(90167);
        }, 64120(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.getBuildConstants = c, t.isWhatsAppVersionGTE = function(e2) {
            const t2 = c(), r2 = (null == t2 ? void 0 : t2.VERSION_STR) || "0.0.0";
            return (0, s.compare)(r2, e2, ">=");
          }, t.isWhatsAppVersionLTE = function(e2) {
            const t2 = c(), r2 = (null == t2 ? void 0 : t2.VERSION_STR) || "0.0.0";
            return (0, s.compare)(r2, e2, "<=");
          };
          const s = r(75828), u = a(r(7222));
          function c() {
            const e2 = u.search((e3) => e3.VERSION_STR);
            return e2 ? Object.assign(Object.assign({}, e2), { PARSED: { PRIMARY: parseInt(e2.VERSION_PRIMARY, 10), SECONDARY: parseInt(e2.VERSION_SECONDARY, 10), TERTIARY: parseInt(e2.VERSION_TERTIARY, 10) } }) : null;
          }
        }, 11057(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.getHistorySyncProgress = function() {
            const e2 = s.getHistorySyncProgress();
            return { progress: e2.realProgress || 0, paused: ((null == e2 ? void 0 : e2.remainingPausedSeconds) || 0) > 0, inProgress: ((null == e2 ? void 0 : e2.realProgress) || 0) < 100 };
          };
          const s = a(r(52757));
        }, 41900(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMigrationState = function() {
            const e2 = { isLidMigrated: false, isSyncdSessionMigrated: false, shouldApplyNonMigratedMessagingRules: false };
            try {
              e2.isLidMigrated = (0, n.isLidMigrated)();
            } catch (e3) {
              console.warn("isLidMigrated function is not available");
            }
            try {
              e2.isSyncdSessionMigrated = o.Lid1X1MigrationUtils.isSyncdSessionMigrated();
            } catch (e3) {
              console.warn("isSyncdSessionMigrated function is not available");
            }
            try {
              e2.shouldApplyNonMigratedMessagingRules = o.Lid1X1MigrationUtils.shouldApplyNonMigratedMessagingRules();
            } catch (e3) {
              console.warn("shouldApplyNonMigratedMessagingRules function is not available");
            }
            try {
              e2.currentLid = o.UserPrefs.getMaybeMeLidUser();
            } catch (e3) {
              console.warn("getMaybeMeLidUser function is not available");
            }
            try {
              e2.currentPn = o.UserPrefs.getMaybeMePnUser();
            } catch (e3) {
              console.warn("getMaybeMePnUser function is not available");
            }
            return e2;
          };
          const n = r(52757), o = r(45588);
        }, 94452(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMyDeviceId = function() {
            const e2 = (0, o.getMyUserWid)();
            return e2 || n.UserPrefs.getMe();
          };
          const n = r(14647), o = r(21942);
        }, 64149(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMyUserId = function() {
            return (0, n.getMyUserWid)();
          };
          const n = r(21942);
        }, 7379(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMyUserLid = function() {
            return n.UserPrefs.getMeLidUserOrThrow();
          };
          const n = r(14647);
        }, 21942(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMyUserWid = function() {
            return "function" == typeof n.UserPrefs.getMaybeMeUser ? n.UserPrefs.getMaybeMeUser() : n.UserPrefs.getMaybeMePnUser();
          };
          const n = r(14647);
        }, 13158(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getPlatform = function() {
            return n.Conn.platform;
          };
          const n = r(14647);
        }, 79229(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getStreamData = function() {
            return { mode: n.Stream.mode, info: n.Stream.info };
          };
          const n = r(14647);
        }, 37200(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.Theme = void 0, t.getTheme = function() {
            const e2 = (0, n.getTheme)();
            return "light" === e2 ? o.LIGHT : "dark" === e2 ? o.DARK : o.LIGHT;
          };
          const n = r(90167);
          var o;
          !function(e2) {
            e2.LIGHT = "light", e2.DARK = "dark", e2.SYSTEM = "system";
          }(o || (t.Theme = o = {}));
        }, 60397(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setTheme = t.setMultiDevice = t.setLimit = t.setKeepAlive = t.setAutoDownloadSettings = t.refreshQR = t.needsUpdate = t.markUnavailable = t.markAvailable = t.logout = t.joinWebBeta = t.isRegistered = t.isOnline = t.isMultiDevice = t.isMainReady = t.isMainLoaded = t.isMainInit = t.isIdle = t.isAuthenticated = t.Theme = t.getTheme = t.getStreamData = t.getPlatform = t.getMyUserWid = t.getMyUserLid = t.getMyUserId = t.getMyDeviceId = t.getMigrationState = t.getHistorySyncProgress = t.isWhatsAppVersionGTE = t.getBuildConstants = t.getAutoDownloadSettings = t.getAuthCode = t.getABPropsMap = t.getABProps = t.getABPropName = t.genLinkDeviceCodeForPhoneNumber = t.changeEnviromentDevice = void 0;
          var n = r(79330);
          Object.defineProperty(t, "changeEnviromentDevice", { enumerable: true, get: function() {
            return n.changeEnviromentDevice;
          } });
          var o = r(28904);
          Object.defineProperty(t, "genLinkDeviceCodeForPhoneNumber", { enumerable: true, get: function() {
            return o.genLinkDeviceCodeForPhoneNumber;
          } });
          var i = r(34618);
          Object.defineProperty(t, "getABPropName", { enumerable: true, get: function() {
            return i.getABPropName;
          } }), Object.defineProperty(t, "getABProps", { enumerable: true, get: function() {
            return i.getABProps;
          } }), Object.defineProperty(t, "getABPropsMap", { enumerable: true, get: function() {
            return i.getABPropsMap;
          } });
          var a = r(11102);
          Object.defineProperty(t, "getAuthCode", { enumerable: true, get: function() {
            return a.getAuthCode;
          } });
          var s = r(20027);
          Object.defineProperty(t, "getAutoDownloadSettings", { enumerable: true, get: function() {
            return s.getAutoDownloadSettings;
          } });
          var u = r(64120);
          Object.defineProperty(t, "getBuildConstants", { enumerable: true, get: function() {
            return u.getBuildConstants;
          } }), Object.defineProperty(t, "isWhatsAppVersionGTE", { enumerable: true, get: function() {
            return u.isWhatsAppVersionGTE;
          } });
          var c = r(11057);
          Object.defineProperty(t, "getHistorySyncProgress", { enumerable: true, get: function() {
            return c.getHistorySyncProgress;
          } });
          var l = r(41900);
          Object.defineProperty(t, "getMigrationState", { enumerable: true, get: function() {
            return l.getMigrationState;
          } });
          var d = r(94452);
          Object.defineProperty(t, "getMyDeviceId", { enumerable: true, get: function() {
            return d.getMyDeviceId;
          } });
          var f = r(64149);
          Object.defineProperty(t, "getMyUserId", { enumerable: true, get: function() {
            return f.getMyUserId;
          } });
          var p = r(7379);
          Object.defineProperty(t, "getMyUserLid", { enumerable: true, get: function() {
            return p.getMyUserLid;
          } });
          var g = r(21942);
          Object.defineProperty(t, "getMyUserWid", { enumerable: true, get: function() {
            return g.getMyUserWid;
          } });
          var m = r(13158);
          Object.defineProperty(t, "getPlatform", { enumerable: true, get: function() {
            return m.getPlatform;
          } });
          var y = r(79229);
          Object.defineProperty(t, "getStreamData", { enumerable: true, get: function() {
            return y.getStreamData;
          } });
          var v = r(37200);
          Object.defineProperty(t, "getTheme", { enumerable: true, get: function() {
            return v.getTheme;
          } }), Object.defineProperty(t, "Theme", { enumerable: true, get: function() {
            return v.Theme;
          } });
          var b = r(41818);
          Object.defineProperty(t, "isAuthenticated", { enumerable: true, get: function() {
            return b.isAuthenticated;
          } });
          var h = r(76243);
          Object.defineProperty(t, "isIdle", { enumerable: true, get: function() {
            return h.isIdle;
          } });
          var _ = r(89786);
          Object.defineProperty(t, "isMainInit", { enumerable: true, get: function() {
            return _.isMainInit;
          } });
          var P = r(50849);
          Object.defineProperty(t, "isMainLoaded", { enumerable: true, get: function() {
            return P.isMainLoaded;
          } });
          var M = r(65877);
          Object.defineProperty(t, "isMainReady", { enumerable: true, get: function() {
            return M.isMainReady;
          } });
          var w = r(63282);
          Object.defineProperty(t, "isMultiDevice", { enumerable: true, get: function() {
            return w.isMultiDevice;
          } });
          var O = r(51170);
          Object.defineProperty(t, "isOnline", { enumerable: true, get: function() {
            return O.isOnline;
          } });
          var j = r(35177);
          Object.defineProperty(t, "isRegistered", { enumerable: true, get: function() {
            return j.isRegistered;
          } });
          var S = r(75365);
          Object.defineProperty(t, "joinWebBeta", { enumerable: true, get: function() {
            return S.joinWebBeta;
          } });
          var C = r(9135);
          Object.defineProperty(t, "logout", { enumerable: true, get: function() {
            return C.logout;
          } });
          var x = r(62749);
          Object.defineProperty(t, "markAvailable", { enumerable: true, get: function() {
            return x.markAvailable;
          } }), Object.defineProperty(t, "markUnavailable", { enumerable: true, get: function() {
            return x.markUnavailable;
          } });
          var I = r(12709);
          Object.defineProperty(t, "needsUpdate", { enumerable: true, get: function() {
            return I.needsUpdate;
          } });
          var A = r(27573);
          Object.defineProperty(t, "refreshQR", { enumerable: true, get: function() {
            return A.refreshQR;
          } });
          var E = r(38871);
          Object.defineProperty(t, "setAutoDownloadSettings", { enumerable: true, get: function() {
            return E.setAutoDownloadSettings;
          } });
          var T = r(22987);
          Object.defineProperty(t, "setKeepAlive", { enumerable: true, get: function() {
            return T.setKeepAlive;
          } });
          var L = r(52122);
          Object.defineProperty(t, "setLimit", { enumerable: true, get: function() {
            return L.setLimit;
          } });
          var B = r(15610);
          Object.defineProperty(t, "setMultiDevice", { enumerable: true, get: function() {
            return B.setMultiDevice;
          } });
          var k = r(52460);
          Object.defineProperty(t, "setTheme", { enumerable: true, get: function() {
            return k.setTheme;
          } });
        }, 41818(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.isAuthenticated = function() {
            return s.isAuthenticated();
          };
          const s = a(r(52757));
        }, 76243(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.isIdle = function() {
            return n.Socket.state === o.SOCKET_STATE.UNPAIRED_IDLE;
          };
          const n = r(14647), o = r(89763);
        }, 89786(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.isMainInit = function() {
            var e2;
            return Boolean(null === (e2 = window.Debug) || void 0 === e2 ? void 0 : e2.VERSION);
          };
        }, 50849(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.isMainLoaded = function() {
            return n.Cmd.isMainLoaded;
          };
          const n = r(14647);
        }, 65877(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.isMainReady = function() {
            return o;
          };
          const n = r(13691);
          let o = false;
          n.internalEv.once("conn.main_ready", () => {
            o = true;
          });
        }, 63282(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.isMultiDevice = function() {
            return true;
          };
        }, 51170(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.isOnline = function() {
            return n.NetworkStatus.online;
          };
          const n = r(14647);
        }, 35177(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.isRegistered = function() {
            return s.isRegistered();
          };
          const s = a(r(52757));
        }, 75365(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.joinWebBeta = async function(e2) {
            const t2 = await (0, o.getWhatsAppWebExternalBetaJoinedIdb)();
            if (t2 === e2) return t2;
            if ("boolean" != typeof e2) throw new n.WPPError("value_not_a_boolean", `Value ${e2 || "<empty>"} is not a boolean`, { value: e2 });
            return await (0, o.changeOptInStatusForExternalWebBeta)(e2), await (0, o.getWhatsAppWebExternalBetaJoinedIdb)();
          };
          const n = r(62857), o = r(52757);
        }, 9135(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.logout = async function() {
            return n.Socket.logout(), await new Promise((e2) => {
              n.Cmd.once("logout", e2);
            }), true;
          };
          const n = r(14647);
        }, 62749(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.markAvailable = o, t.markUnavailable = async function() {
            return o(false);
          };
          const n = r(14647);
          async function o(e2 = true) {
            return Object.defineProperty(n.Stream, "available", { get: () => e2, set: (t2) => {
              t2 == e2 && n.Stream.trigger("change:available");
            }, configurable: true }), e2 ? n.Stream.markAvailable() : n.Stream.markUnavailable(), true;
          }
        }, 12709(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.needsUpdate = function() {
            return n.Stream.needsUpdate;
          };
          const n = r(14647);
        }, 27573(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.refreshQR = async function() {
            if ((0, i.isAuthenticated)()) return null;
            (0, i.isMultiDevice)() ? o.Cmd.refreshQR() : o.Socket.poke();
            return await n.internalEv.waitFor("conn.auth_code_change").then((e2) => e2[0]);
          };
          const n = r(13691), o = r(14647), i = r(60397);
        }, 38871(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.setAutoDownloadSettings = async function(e2) {
            void 0 !== e2.photos && s.setAutoDownloadPhotos(e2.photos);
            void 0 !== e2.audio && s.setAutoDownloadAudio(e2.audio);
            void 0 !== e2.videos && s.setAutoDownloadVideos(e2.videos);
            void 0 !== e2.documents && s.setAutoDownloadDocuments(e2.documents);
            window.location.reload();
          };
          const s = a(r(90167));
        }, 22987(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setKeepAlive = function(e2 = true) {
            e2 ? (document.hasFocus = () => true, n = setInterval(() => document.dispatchEvent(new Event("scroll")), 15e3)) : (document.hasFocus = r, n && (clearInterval(n), n = null));
            return !!n;
          };
          const r = document.hasFocus;
          let n;
        }, 52122(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.setLimit = function(e2, t2) {
            switch (e2) {
              case "maxMediaSize":
                if ("number" != typeof t2 || t2 > 73400320) throw new u.WPPError("maxMediaSize_error", "number" != typeof t2 ? "Value type invalid!" : "Maximum value is 70MB");
                return null;
              case "maxFileSize":
                if ("number" != typeof t2 || t2 > 1073741824) throw new u.WPPError("maxFileSize_error", "number" != typeof t2 ? "Value type invalid!" : "Maximum value is 1GB");
                return c.ServerPropsConstants.MAX_FILE_SIZE_BYTES = t2, c.ServerPropsConstants.MAX_FILE_SIZE_BYTES;
              case "maxShare":
                if ("number" != typeof t2) throw new u.WPPError("maxShare_error", "Value type invalid!");
                return c.ServerPropsConstants.MULTICAST_LIMIT_GLOBAL = t2, c.ServerPropsConstants.MULTICAST_LIMIT_GLOBAL;
              case "statusVideoMaxDuration":
                if ("number" != typeof t2) throw new u.WPPError("statusVideoMaxDuration_error", "Value type invalid!");
                return null;
              case "unlimitedPin":
                if ("boolean" != typeof t2) throw new u.WPPError("unlimitedPin_error", "Value type invalid!");
                return f = !!t2 || void 0, t2;
              default:
                throw new u.WPPError("setLimit_error", "Key type invalid!");
            }
          };
          const s = a(r(7222)), u = r(62857), c = r(14647), l = r(54993), d = r(52757);
          let f;
          s.onFullReady(() => {
            (0, l.wrapModuleFunction)(d.getNumChatsPinned, (e2, ...t2) => {
              const r2 = e2(...t2);
              return f ? 1 : r2;
            });
          });
        }, 15610(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setMultiDevice = function(e2 = true) {
            e2 ? n.Cmd.upgradeToMDProd() : n.Cmd.downgradeWebclient();
            return true;
          };
          const n = r(14647);
        }, 52460(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setTheme = async function(e2) {
            if (!Object.values(o.Theme).includes(e2)) throw new Error("Invalid theme value. Use Theme.LIGHT, Theme.DARK, or Theme.SYSTEM.");
            (0, n.setTheme)(e2), setTimeout(() => {
              window.location.reload();
            }, 500);
          };
          const n = r(90167), o = r(37200);
        }, 72927(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), r(58293), r(51369), o(r(60397), t), o(r(14282), t);
        }, 51369(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = a(r(7222)), u = r(14647), c = r(19198);
          s.onInjected(() => {
            var e2;
            u.IsOfficialClient.isOfficialClient = true;
            const t2 = self;
            !(null === (e2 = t2.Debug) || void 0 === e2 ? void 0 : e2.VERSION) && c.SANITIZED_VERSION_STR && (t2.Debug = Object.assign(Object.assign({}, t2.Debug), { VERSION: c.SANITIZED_VERSION_STR }));
          });
        }, 14282(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
        }, 93037(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.get = async function(e2) {
            const t2 = (0, n.assertWid)(e2);
            return o.ContactStore.get(t2);
          };
          const n = r(41687), o = r(14647);
        }, 49738(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getBusinessProfile = async function(e2) {
            const t2 = (0, n.assertWid)(e2);
            return await o.BusinessProfileStore.fetchBizProfile(t2);
          };
          const n = r(41687), o = r(14647);
        }, 81676(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getCommonGroups = async function(e2) {
            const t2 = n.ContactStore.get(e2);
            if (!t2) return [];
            return (await n.functions.findCommonGroups(t2)).getModelsArray().map((e3) => e3.id);
          };
          const n = r(14647);
        }, 22316(e, t, r) {
          "use strict";
          var n = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.InvalidWidForGetPnLidEntry = void 0, t.getPnLidEntry = async function(e2) {
            const t2 = (0, i.assertWid)(e2);
            let r2, n2, o2;
            if ("c.us" !== t2.server && "lid" !== t2.server) throw new l(t2);
            if (t2.isLid()) r2 = t2, n2 = s.lidPnCache.getPhoneNumber(t2) || void 0;
            else if ("c.us" === t2.server) if (n2 = t2, r2 = s.lidPnCache.getCurrentLid(t2) || void 0, r2) c(`LID found in cache: ${r2.toString()}`);
            else {
              c(`LID not found in cache for ${t2.toString()}, querying server...`);
              const e3 = await (0, u.queryExists)(t2);
              (null == e3 ? void 0 : e3.lid) ? (r2 = e3.lid, c(`LID retrieved from server: ${r2.toString()}`)) : c(`No LID returned from server for ${t2.toString()}`);
            }
            const a2 = s.ContactStore.get(r2 || n2 || t2);
            a2 && (o2 = { name: a2.name, shortName: a2.shortName, pushname: a2.pushname, type: a2.type, verifiedName: a2.verifiedName, isBusiness: a2.isBusiness, isEnterprise: a2.isEnterprise, syncToAddressbook: a2.syncToAddressbook, isContactSyncCompleted: a2.isContactSyncCompleted });
            const d = { lid: r2 ? { id: r2.user, server: r2.server, _serialized: r2.toString() } : void 0, phoneNumber: n2 ? { id: n2.user, server: n2.server, _serialized: n2.toString() } : void 0, contact: o2 };
            return c(`getPnLidEntry result for ${t2.toString()}`, d), d;
          };
          const o = n(r(17833)), i = r(41687), a = r(62857), s = r(14647), u = r(53141), c = (0, o.default)("WA-JS:contact:getPnLidEntry");
          class l extends a.WPPError {
            constructor(e2) {
              super("invalid_wid", `Invalid WID value for ${e2} - getPnLidEntry only supports @c.us and @lid.`), this.id = e2;
            }
          }
          t.InvalidWidForGetPnLidEntry = l;
        }, 73871(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getProfilePictureUrl = async function(e2, t2 = true) {
            const r2 = (0, n.assertWid)(e2), i = await o.ProfilePicThumbStore.find(r2);
            if (!i) return;
            if (t2) return i.imgFull;
            return i.img;
          };
          const n = r(41687), o = r(14647);
        }, 23199(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getStatus = async function(e2) {
            const t2 = (0, n.assertWid)(e2);
            if (!await (0, i.queryExists)(t2)) return null;
            return (await o.StatusStore.find(t2)).status || null;
          };
          const n = r(41687), o = r(14647), i = r(53141);
        }, 20941(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.unsubscribePresence = t.subscribePresence = t.save = t.reportContact = t.remove = t.queryWidExists = t.queryUsernameExists = t.queryExists = t.list = t.getStatus = t.getProfilePictureUrl = t.InvalidWidForGetPnLidEntry = t.getPnLidEntry = t.getCommonGroups = t.getBusinessProfile = t.get = void 0;
          var n = r(93037);
          Object.defineProperty(t, "get", { enumerable: true, get: function() {
            return n.get;
          } });
          var o = r(49738);
          Object.defineProperty(t, "getBusinessProfile", { enumerable: true, get: function() {
            return o.getBusinessProfile;
          } });
          var i = r(81676);
          Object.defineProperty(t, "getCommonGroups", { enumerable: true, get: function() {
            return i.getCommonGroups;
          } });
          var a = r(22316);
          Object.defineProperty(t, "getPnLidEntry", { enumerable: true, get: function() {
            return a.getPnLidEntry;
          } }), Object.defineProperty(t, "InvalidWidForGetPnLidEntry", { enumerable: true, get: function() {
            return a.InvalidWidForGetPnLidEntry;
          } });
          var s = r(73871);
          Object.defineProperty(t, "getProfilePictureUrl", { enumerable: true, get: function() {
            return s.getProfilePictureUrl;
          } });
          var u = r(23199);
          Object.defineProperty(t, "getStatus", { enumerable: true, get: function() {
            return u.getStatus;
          } });
          var c = r(62041);
          Object.defineProperty(t, "list", { enumerable: true, get: function() {
            return c.list;
          } });
          var l = r(53141);
          Object.defineProperty(t, "queryExists", { enumerable: true, get: function() {
            return l.queryExists;
          } });
          var d = r(42357);
          Object.defineProperty(t, "queryUsernameExists", { enumerable: true, get: function() {
            return d.queryUsernameExists;
          } });
          var f = r(94349);
          Object.defineProperty(t, "queryWidExists", { enumerable: true, get: function() {
            return f.queryWidExists;
          } });
          var p = r(75513);
          Object.defineProperty(t, "remove", { enumerable: true, get: function() {
            return p.remove;
          } });
          var g = r(46683);
          Object.defineProperty(t, "reportContact", { enumerable: true, get: function() {
            return g.reportContact;
          } });
          var m = r(88900);
          Object.defineProperty(t, "save", { enumerable: true, get: function() {
            return m.save;
          } });
          var y = r(316);
          Object.defineProperty(t, "subscribePresence", { enumerable: true, get: function() {
            return y.subscribePresence;
          } });
          var v = r(17485);
          Object.defineProperty(t, "unsubscribePresence", { enumerable: true, get: function() {
            return v.unsubscribePresence;
          } });
        }, 62041(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.list = async function(e2 = {}) {
            let t2 = n.ContactStore.getModelsArray().slice();
            e2.onlyMyContacts && (t2 = t2.filter((e3) => e3.isMyContact));
            if (e2.withLabels) {
              const r2 = e2.withLabels.map((e3) => {
                const t3 = n.LabelStore.findFirst((t4) => t4.name === e3);
                return t3 ? t3.id : e3;
              });
              t2 = t2.filter((e3) => {
                var t3;
                return null === (t3 = e3.labels) || void 0 === t3 ? void 0 : t3.some((e4) => r2.includes(e4));
              });
            }
            return t2;
          };
          const n = r(14647);
        }, 53141(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.queryExists = void 0;
          var n = r(94349);
          Object.defineProperty(t, "queryExists", { enumerable: true, get: function() {
            return n.queryWidExists;
          } });
        }, 42357(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.queryUsernameExists = async function(e2, t2) {
            return (0, n.queryUsernameExists)(e2, t2);
          };
          const n = r(23583);
        }, 94349(e, t, r) {
          "use strict";
          var n = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.queryWidExists = async function(e2) {
            const t2 = (0, i.assertWid)(e2);
            u("queryWidExists: %s", t2.toString());
            const r2 = t2.isLid() ? a.lidPnCache.getPhoneNumber(t2) : a.lidPnCache.getCurrentLid(t2), n2 = a.ContactStore.get(t2), o2 = r2 ? a.ContactStore.get(r2) : null;
            if (null != n2 || null != o2) {
              const e3 = n2 || o2;
              return u("contactStore hit for %s", t2.toString()), function(e4, t3) {
                const r3 = a.ApiContact.getCurrentLid(t3) || void 0;
                return { wid: t3, biz: e4.isBusiness, bizInfo: e4.isBusiness && null != e4.verifiedName ? { verifiedName: { isApi: !!e4.isEnterprise, level: e4.verifiedLevel, name: e4.verifiedName, privacyMode: e4.privacyMode, serial: void 0 } } : void 0, disappearingMode: null != e4.disappearingModeDuration && null != e4.disappearingModeSettingTimestamp ? { duration: e4.disappearingModeDuration, settingTimestamp: e4.disappearingModeSettingTimestamp } : void 0, lid: r3, username: e4.username };
              }(e3, t2);
            }
            u("contactStore miss for %s", t2.toString());
            const l = `+${t2.toString()}`;
            if (c.has(l)) return u("promise cache hit for %s", t2.toString()), c.get(l);
            u("promise cache miss for %s, fetching from server", t2.toString());
            const d = async function(e3) {
              u("fetchFromServer: requesting %s", e3.toString());
              try {
                const t3 = await (0, s.queryWidExists)(e3);
                if (!t3) return u("fetchFromServer: no result for %s", e3.toString()), null;
                const r3 = a.ApiContact.getCurrentLid(e3) || void 0, n3 = { wid: t3.wid, biz: t3.biz, bizInfo: t3.bizInfo, disappearingMode: t3.disappearingMode, lid: r3, username: t3.username };
                return u("fetchFromServer: result for %s %o", e3.toString(), n3), n3;
              } catch (t3) {
                return u("fetchFromServer: error for %s: %o", e3.toString(), t3), null;
              }
            }(t2).then((e3) => {
              const r3 = e3 ? 3e5 : 15e3;
              return u("caching result for %s, ttl=%dms", t2.toString(), r3), setTimeout(() => c.delete(l), r3), e3;
            }).catch(() => (setTimeout(() => c.delete(l), 15e3), null));
            return c.set(l, d), d;
          };
          const o = n(r(17833)), i = r(41687), a = r(14647), s = r(2571), u = (0, o.default)("WA-JS:contact:queryWidExists"), c = /* @__PURE__ */ new Map();
        }, 75513(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.remove = async function(e2) {
            e2 = (0, n.assertWid)(e2);
            const t2 = await (0, s.get)(e2);
            if (!t2) throw new i.WPPError("contact_not_found", "Contact not found");
            if (!(0, a.getIsMyContact)(t2)) throw new i.WPPError("number_is_not_your_contact", `The number ${e2._serialized} is not your contact`);
            if ((0, o.isWhatsAppVersionGTE)("2.3000.1030110621")) if (e2.isLid()) {
              const r2 = t2.username;
              await (0, a.deleteContactActionV2)({ lid: e2.toString(), username: r2 });
            } else await (0, a.deleteContactActionV2)({ phoneNumber: e2 });
            else await (0, a.deleteContactAction)(e2.user);
            return await (0, s.get)(e2);
          };
          const n = r(41687), o = r(60397), i = r(62857), a = r(52757), s = r(93037);
        }, 46683(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.reportContact = async function(e2, t2 = "ChatInfoReport", r2) {
            var n2;
            const o2 = (0, s.assertWid)(e2), i2 = u.ChatStore.get(o2) || new u.ChatModel({ id: o2 }), a2 = await c.reportSpam(i2, t2, r2);
            return { wid: o2, reportId: null === (n2 = a2.reportIdMixin) || void 0 === n2 ? void 0 : n2.reportId, errorCode: a2.errorCode, errorText: a2.errorText };
          };
          const s = r(41687), u = r(14647), c = a(r(52757));
        }, 88900(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.save = async function(e2, t2, r2) {
            var c, l, d, f;
            if (!e2 || !t2) throw new i.WPPError("send_the_required_fields", "Please, send the contact id like <number@c.us> and the name for your contact");
            void 0 !== (null == r2 ? void 0 : r2.syncAdressBook) && console.warn('[WPPConnect Warning] The "syncAdressBook" option is deprecated due to a typo. Please use "syncAddressBook" instead.');
            const p = (0, n.assertWid)(e2), g = a.ApiContact.getAlternateUserWid(p), m = p.isLid() ? p.user : (null == g ? void 0 : g.isLid()) ? g.user : null, y = "c.us" === p.server ? p.user : "c.us" === g.server ? g.user : null, v = null === (l = null !== (c = null == r2 ? void 0 : r2.syncAddressBook) && void 0 !== c ? c : null == r2 ? void 0 : r2.syncAdressBook) || void 0 === l || l, b = null !== (f = null !== (d = null == r2 ? void 0 : r2.lastName) && void 0 !== d ? d : null == r2 ? void 0 : r2.surname) && void 0 !== f ? f : "";
            if ((0, o.isWhatsAppVersionGTE)("2.3000.1030209354")) await (0, s.saveContactActionV2)({ phoneNumber: y, prevPhoneNumber: null, lid: m, username: null, firstName: t2, lastName: b, syncToAddressbook: v });
            else {
              if (!y) throw new i.WPPError("invalid_contact_id_for_legacy_version", "For WhatsApp versions below 2.3000.1030209354, only phone number contacts are supported");
              await (0, s.saveContactAction)(y, null, null, null, t2, b, v);
            }
            return await (0, u.get)(e2);
          };
          const n = r(41687), o = r(60397), i = r(62857), a = r(14647), s = r(52757), u = r(93037);
        }, 316(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.subscribePresence = async function(e2) {
            Array.isArray(e2) || (e2 = [e2]);
            const t2 = [];
            for (const r2 of e2) try {
              const e3 = n.WidFactory.createWid(r2);
              if (o.subscribeGroupPresence && e3.isGroup() ? (0, o.subscribeGroupPresence)(e3) : await (0, o.subscribePresence)(e3), n.PresenceStore.get(e3)) {
                t2.push(e3);
                continue;
              }
              await n.PresenceStore.find(e3), t2.push(e3);
            } catch (e3) {
            }
            return t2;
          };
          const n = r(14647), o = r(52757);
        }, 17485(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.unsubscribePresence = async function(e2) {
            Array.isArray(e2) || (e2 = [e2]);
            const t2 = [];
            for (const r2 of e2) {
              const e3 = n.WidFactory.createWid(r2), o = n.PresenceStore.get(e3);
              o ? (o.delete(), t2.push(e3)) : t2.push(e3);
            }
            return t2;
          };
          const n = r(14647);
        }, 56191(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), r(54409), o(r(20941), t);
        }, 54409(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = a(r(7222)), u = r(14647);
          s.onInjected(function() {
            var e2;
            const t2 = { isMyContact: u.functions.getIsMyContact, mentionName: u.functions.getMentionName, notifyName: u.functions.getNotifyName, pnForLid: u.functions.getPnForLid, displayNameOrPnForLid: u.functions.getDisplayNameOrPnForLid, formattedPhone: u.functions.getFormattedPhone, userid: u.functions.getUserid, userhash: null !== (e2 = u.functions.getUserhash) && void 0 !== e2 ? e2 : (e3) => e3.id.isUser() ? u.functions.md5((e3.id.user || "") + "WA_ADD_NOTIF") : null, searchName: u.functions.getSearchName, searchVerifiedName: u.functions.getSearchVerifiedName, header: u.functions.getHeader, isMe: u.functions.getIsMe, isUser: (e3) => () => e3.id.isUser(), isGroup: (e3) => () => e3.id.isGroup(), isBroadcast: (e3) => () => e3.id.isBroadcast(), isPSA: (e3) => () => e3.id.isPSA(), isIAS: u.functions.getIsIAS, isSupportAccount: u.functions.getIsSupportAccount, formattedShortNameWithNonBreakingSpaces: u.functions.getFormattedShortNameWithNonBreakingSpaces, formattedShortName: u.functions.getFormattedShortName, formattedName: u.functions.getFormattedName, formattedUser: u.functions.getFormattedUser, isWAContact: u.functions.getIsWAContact, canRequestPhoneNumber: u.functions.getCanRequestPhoneNumber, showBusinessCheckmarkAsPrimary: u.functions.getShowBusinessCheckmarkAsPrimary, showBusinessCheckmarkAsSecondary: u.functions.getShowBusinessCheckmarkAsSecondary, showBusinessCheckmarkInChatlist: u.functions.getShowBusinessCheckmarkInChatlist, isDisplayNameApproved: u.functions.getIsDisplayNameApproved, shouldForceBusinessUpdate: u.functions.getShouldForceBusinessUpdate };
            for (const e3 in t2) {
              const r2 = t2[e3];
              void 0 === u.ContactModel.prototype[e3] && Object.defineProperty(u.ContactModel.prototype, e3, { get: function() {
                return r2(this);
              }, configurable: true });
            }
          });
        }, 80687(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(91491), u = a(r(7222));
          u.onInjected(() => {
            if (!s.config.deviceName) return;
            const e2 = u.search((e3) => e3.default.info && e3.default.hardRefresh);
            if (e2) {
              const t2 = e2.default.info();
              t2.os = s.config.deviceName, t2.version = void 0, t2.name = void 0, t2.ua = void 0, e2.default.info = () => t2;
            }
          });
        }, 83734(e, t) {
          "use strict";
          var r, n;
          t.PrivacyDisallowedListType = void 0, function(e2) {
            e2[e2.SANS_SERIF = 0] = "SANS_SERIF", e2[e2.SERIF = 1] = "SERIF", e2[e2.NORICAN_REGULAR = 2] = "NORICAN_REGULAR", e2[e2.BRYNDAN_WRITE = 3] = "BRYNDAN_WRITE", e2[e2.BEBASNEUE_REGULAR = 4] = "BEBASNEUE_REGULAR", e2[e2.OSWALD_HEAVY = 5] = "OSWALD_HEAVY";
          }(r || (r = {})), function(e2) {
            e2.About = "status", e2.GroupAdd = "groupadd", e2.LastSeen = "last", e2.ProfilePicture = "profile";
          }(n || (t.PrivacyDisallowedListType = n = {}));
        }, 78601(e, t, r) {
          "use strict";
          const n = r(53011);
          t.EventEmitter = n.EventEmitter2;
        }, 11426(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
        }, 13691(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          }, i = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.waitFor = t.stopListeningTo = t.setMaxListeners = t.removeListener = t.removeAllListeners = t.prependOnceListener = t.prependMany = t.prependListener = t.prependAny = t.once = t.onAny = t.on = t.offAny = t.off = t.many = t.listenersAny = t.listeners = t.listenerCount = t.listenTo = t.hasListeners = t.getMaxListeners = t.eventNames = t.emitAsync = t.emit = t.addListener = t.EventEmitter = t.ev = t.internalEv = void 0;
          const a = i(r(17833)), s = r(78601);
          Object.defineProperty(t, "EventEmitter", { enumerable: true, get: function() {
            return s.EventEmitter;
          } }), o(r(11426), t);
          const u = (0, a.default)("WA-JS:event");
          t.internalEv = new s.EventEmitter({ maxListeners: 1 / 0 }), t.ev = new s.EventEmitter({ maxListeners: 1 / 0 }), t.internalEv.onAny((e2, ...r2) => {
            t.ev.emit(e2, ...r2), u.enabled && u(e2, ...r2);
          }), t.addListener = t.ev.addListener.bind(t.ev), t.emit = t.ev.emit.bind(t.ev), t.emitAsync = t.ev.emitAsync.bind(t.ev), t.eventNames = t.ev.eventNames.bind(t.ev), t.getMaxListeners = t.ev.getMaxListeners.bind(t.ev), t.hasListeners = t.ev.hasListeners.bind(t.ev), t.listenTo = t.ev.listenTo.bind(t.ev), t.listenerCount = t.ev.listenerCount.bind(t.ev), t.listeners = t.ev.listeners.bind(t.ev), t.listenersAny = t.ev.listenersAny.bind(t.ev), t.many = t.ev.many.bind(t.ev), t.off = t.ev.off.bind(t.ev), t.offAny = t.ev.offAny.bind(t.ev), t.on = t.ev.on.bind(t.ev), t.onAny = t.ev.onAny.bind(t.ev), t.once = t.ev.once.bind(t.ev), t.prependAny = t.ev.prependAny.bind(t.ev), t.prependListener = t.ev.prependListener.bind(t.ev), t.prependMany = t.ev.prependMany.bind(t.ev), t.prependOnceListener = t.ev.prependOnceListener.bind(t.ev), t.removeAllListeners = t.ev.removeAllListeners.bind(t.ev), t.removeListener = t.ev.removeListener.bind(t.ev), t.setMaxListeners = t.ev.setMaxListeners.bind(t.ev), t.stopListeningTo = t.ev.stopListeningTo.bind(t.ev), t.waitFor = t.ev.waitFor.bind(t.ev);
        }, 86288(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), r(39893);
        }, 39893(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(54993), l = r(52757);
          u.onFullReady(function() {
            const e2 = ["add", "remove", "demote", "promote"];
            (0, c.wrapModuleFunction)(l.updateDBForGroupAction, (t2, ...r2) => {
              const [n2, o2] = r2;
              let i2 = o2.actionType || o2.action;
              return e2.includes(i2) && queueMicrotask(() => {
                var e3;
                const t3 = o2.participants.map((e4) => "id" in e4 ? e4.id : e4);
                "add" !== i2 || !o2.isInvite && "invite" !== o2.reason ? "remove" === i2 && t3.some((e4) => e4.equals(n2.author)) && (i2 = "leave") : i2 = "join", s.internalEv.emit("group.participant_changed", { author: null === (e3 = n2.author) || void 0 === e3 ? void 0 : e3.toString(), authorPushName: n2.pushname, groupId: n2.chatId.toString(), action: i2, operation: o2.actionType || o2.action, participants: t3.map((e4) => e4.toString()) });
              }), t2(...r2);
            });
          });
        }, 7103(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.addParticipants = async function(e2, t2) {
            const { groupChat: r2, participants: s } = await (0, i.ensureGroupAndParticipants)(e2, t2, true), u = (e3) => {
              var t3;
              return e3.id.isLid() && (null === (t3 = o.functions.getPhoneNumber) || void 0 === t3 ? void 0 : t3.call(o.functions, e3.id)) || e3.id;
            }, c = (e3) => {
              var t3;
              return e3.id.isLid() ? e3.id : null === (t3 = o.functions.getCurrentLid) || void 0 === t3 ? void 0 : t3.call(o.functions, e3.id);
            }, l = s.map((e3) => {
              var t3;
              return (null === (t3 = r2.groupMetadata) || void 0 === t3 ? void 0 : t3.isLidAddressingMode) ? { phoneNumber: u(e3), lid: c(e3) } : { phoneNumber: u(e3) };
            }), d = await o.functions.sendAddParticipants(r2.id, l);
            if (d.status >= 400) throw new n.WPPError("group_add_participant_error", "Failed to add participants to the group", { groupId: e2, participantsIds: t2 });
            const f = {};
            for (const e3 of d.participants || []) {
              let t3 = null, r3 = null, i2 = null, s2 = null;
              if ("userWid" in e3) t3 = e3.userWid.toString(), r3 = e3.code, i2 = e3.invite_code, s2 = e3.invite_code_exp;
              else {
                t3 = Object.keys(e3)[0];
                const n2 = e3[t3];
                r3 = n2.code, i2 = n2.invite_code, s2 = n2.invite_code_exp;
              }
              if ("403" !== r3) try {
                o.ContactStore.gadd((0, n.createWid)(t3), { silent: true });
              } catch (e4) {
              }
              f[t3] = { wid: t3, code: Number(r3), message: a[Number(r3)] || "Can't Join., unknown error", invite_code: i2, invite_code_exp: Number(s2) || null };
            }
            return f;
          };
          const n = r(62857), o = r(14647), i = r(97944), a = { 200: "OK", 403: "Can't join this group because the number was restricted it.", 409: "Can't join this group because the number is already a member of it.", 421: "Member not added, awaiting approval!" };
        }, 57139(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.approve = async function(e2, t2) {
            e2 = (0, n.assertWid)(e2), Array.isArray(t2) || (t2 = [t2]);
            const r2 = t2.map(n.assertWid);
            try {
              return await (0, i.membershipApprovalRequestAction)(e2, r2, "Approve");
            } catch (t3) {
              throw new o.WPPError("error_on_accept_membership_request", `Error on accept member on group ${e2.toString()}`);
            }
          };
          const n = r(41687), o = r(62857), i = r(52757);
        }, 71637(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.canAdd = async function(e2) {
            return (await (0, n.ensureGroup)(e2)).groupMetadata.participants.canAdd();
          };
          const n = r(2818);
        }, 976(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.canDemote = async function(e2, t2) {
            const { groupChat: r2, participants: o } = await (0, n.ensureGroupAndParticipants)(e2, t2);
            return o.every((e3) => r2.groupMetadata.participants.canDemote(e3));
          };
          const n = r(2818);
        }, 88818(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.canPromote = async function(e2, t2) {
            const { groupChat: r2, participants: o } = await (0, n.ensureGroupAndParticipants)(e2, t2);
            return o.every((e3) => r2.groupMetadata.participants.canPromote(e3));
          };
          const n = r(2818);
        }, 8932(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.canRemove = async function(e2, t2) {
            const { groupChat: r2, participants: o } = await (0, n.ensureGroupAndParticipants)(e2, t2);
            return o.every((e3) => r2.groupMetadata.participants.canRemove(e3));
          };
          const n = r(2818);
        }, 20292(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.create = async function(e2, t2, r2) {
            var n2;
            Array.isArray(t2) || (t2 = [t2]);
            const o2 = t2.map(s.assertWid), i2 = (0, c.getMyUserWid)(), a2 = [];
            for (const e3 of o2) {
              if (i2.equals(e3)) continue;
              const t3 = f.ContactStore.get(e3);
              if (t3) {
                a2.push(t3.id);
                continue;
              }
              const r3 = await l.queryExists(e3);
              if (!r3) throw new d.WPPError("participant_not_exists", "Participant not exists", { id: e3 });
              i2.equals(r3.wid) || a2.push(r3.wid);
            }
            const g = r2 ? (0, s.assertWid)(r2) : void 0, m = await p.sendCreateGroup(e2, a2, void 0, g);
            if (m.gid) {
              const e3 = await u.find(m.gid);
              false !== (null === (n2 = e3.groupMetadata) || void 0 === n2 ? void 0 : n2.stale) && await new Promise((t3) => {
                e3.on("change:groupMetadata.stale", function r3() {
                  var n3;
                  false === (null === (n3 = e3.groupMetadata) || void 0 === n3 ? void 0 : n3.stale) && (t3(), e3.off("change:groupMetadata.stale", r3));
                });
              });
            }
            const y = {};
            for (const e3 of m.participants || []) {
              let t3 = null, r3 = null, n3 = null, o3 = null;
              if ("userWid" in e3) t3 = e3.userWid.toString(), r3 = e3.code, n3 = e3.invite_code, o3 = e3.invite_code_exp;
              else {
                t3 = Object.keys(e3)[0];
                const i3 = e3[t3];
                r3 = i3.code, n3 = i3.invite_code, o3 = i3.invite_code_exp;
              }
              y[t3] = { wid: t3, code: Number(r3), invite_code: n3, invite_code_exp: Number(o3) || null };
            }
            return { gid: m.gid, participants: y };
          };
          const s = r(41687), u = a(r(74023)), c = r(21942), l = a(r(56191)), d = r(62857), f = r(14647), p = a(r(52757));
        }, 42490(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.demoteParticipants = async function(e2, t2) {
            const { groupChat: r2, participants: n2 } = await (0, c.ensureGroupAndParticipants)(e2, t2);
            if (n2.some((e3) => {
              var t3;
              return !(null === (t3 = r2.groupMetadata) || void 0 === t3 ? void 0 : t3.participants.canDemote(e3));
            })) throw new s.WPPError("group_participant_is_already_not_a_group_admin", `Group ${r2.id._serialized}: Group participant is already not a group admin`);
            return u.demoteParticipants(r2, n2);
          };
          const s = r(62857), u = a(r(52757)), c = r(97944);
        }, 23527(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.ensureGroup = async function(e2, t2 = false) {
            const r2 = (0, n.assertGetChat)(e2);
            if (!r2.id.isGroup()) throw new o.WPPError("not_a_group", `Chat ${r2.id._serialized} is not a group`);
            const a = await i.GroupMetadataStore.find(r2.id);
            if (t2 && !a.participants.iAmAdmin() && "all_member_add" !== a.memberAddMode) throw new o.WPPError("group_you_are_not_admin", `You are not admin in ${r2.id._serialized}`);
            return r2;
          };
          const n = r(41687), o = r(62857), i = r(14647);
        }, 97944(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.findGroupParticipant = f, t.ensureGroupAndParticipants = async function(e2, t2, r2 = false) {
            const n2 = await (0, d.ensureGroup)(e2, true);
            Array.isArray(t2) || (t2 = [t2]);
            const o2 = t2.map(s.assertWid).map((e3) => {
              let t3 = f(n2, e3);
              if (!t3 && r2 && (t3 = new c.ParticipantModel({ id: e3 })), !t3) throw new u.WPPError("group_participant_not_found", `Group ${n2.id._serialized}: Participant '${e3._serialized}' not found`);
              return t3;
            });
            return { groupChat: n2, participants: o2 };
          };
          const s = r(41687), u = r(62857), c = r(14647), l = a(r(52757)), d = r(2818);
          function f(e2, t2) {
            var r2, n2, o2;
            const i2 = null === (r2 = e2.groupMetadata) || void 0 === r2 ? void 0 : r2.participants;
            if (!i2) return;
            const a2 = [t2];
            try {
              a2.push(t2.isLid() ? null === (n2 = l.getPhoneNumber) || void 0 === n2 ? void 0 : n2.call(l, t2) : null === (o2 = l.getCurrentLid) || void 0 === o2 ? void 0 : o2.call(l, t2));
            } catch (e3) {
            }
            for (const e3 of a2) {
              if (!e3) continue;
              const t3 = i2.get(e3);
              if (t3) return t3;
            }
          }
        }, 26219(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getAllGroups = async function() {
            const e2 = [], t2 = await (0, o.queryAllGroups)();
            for (const r2 of t2) e2.push((0, n.get)(r2.id));
            return e2;
          };
          const n = r(74023), o = r(52757);
        }, 45195(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getGroupInfoFromInviteCode = async function(e2) {
            var t2, r2, i, a;
            e2 = (e2 = (e2 = (e2 = e2.replace("chat.whatsapp.com/", "")).replace("invite/", "")).replace("https://", "")).replace("http://", "");
            const s = null === (t2 = await (0, o.sendQueryGroupInvite)(e2).catch(() => null)) || void 0 === t2 ? void 0 : t2.groupInfo;
            if (!s) throw new n.WPPError("invalid_invite_code", "Invalid Invite Code", { inviteCode: e2 });
            return Object.assign(Object.assign({}, s), { descOwner: null === (r2 = s.descOwner) || void 0 === r2 ? void 0 : r2.toString(), id: s.id.toString(), owner: null === (i = s.owner) || void 0 === i ? void 0 : i.toString(), participants: s.participants.map((e3) => Object.assign(Object.assign({}, e3), { id: e3.id.toString() })), subjectOwner: null === (a = s.subjectOwner) || void 0 === a ? void 0 : a.toString() });
          };
          const n = r(62857), o = r(52757);
        }, 98083(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getGroupSizeLimit = async function() {
            return n.functions.getGroupSizeLimit();
          };
          const n = r(14647);
        }, 55062(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getInviteCode = async function(e2) {
            const t2 = await (0, o.ensureGroup)(e2, true);
            return await (0, n.sendQueryGroupInviteCode)(t2.id);
          };
          const n = r(52757), o = r(2818);
        }, 4752(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMembershipRequests = async function(e2) {
            return e2 = (0, n.assertWid)(e2), await o.GroupMetadataStore.find(e2), await (0, i.getMembershipApprovalRequests)(e2);
          };
          const n = r(41687), o = r(14647), i = r(52757);
        }, 35528(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getParticipants = async function(e2) {
            return (await (0, n.ensureGroup)(e2)).groupMetadata.participants.getModelsArray();
          };
          const n = r(2818);
        }, 21268(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getPastParticipants = async function(e2) {
            return (await (0, n.ensureGroup)(e2)).groupMetadata.pastParticipants.getModelsArray();
          };
          const n = r(2818);
        }, 68780(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.iAmAdmin = async function(e2) {
            return (await (0, n.ensureGroup)(e2)).groupMetadata.participants.iAmAdmin();
          };
          const n = r(2818);
        }, 60641(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.iAmMember = async function(e2) {
            return (await (0, n.ensureGroup)(e2)).groupMetadata.participants.iAmMember();
          };
          const n = r(2818);
        }, 81484(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.iAmRestrictedMember = async function(e2) {
            return (await (0, n.ensureGroup)(e2)).groupMetadata.participants.iAmRestrictedMember();
          };
          const n = r(2818);
        }, 94173(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.iAmSuperAdmin = async function(e2) {
            return (await (0, n.ensureGroup)(e2)).groupMetadata.participants.iAmMember();
          };
          const n = r(2818);
        }, 2818(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setSubject = t.setProperty = t.GroupProperty = t.setIcon = t.setDescription = t.revokeInviteCode = t.removeParticipants = t.removeIcon = t.reject = t.promoteParticipants = t.leave = t.join = t.iAmSuperAdmin = t.iAmRestrictedMember = t.iAmMember = t.iAmAdmin = t.getPastParticipants = t.getParticipants = t.getMembershipRequests = t.getInviteCode = t.getGroupSizeLimit = t.getGroupInfoFromInviteCode = t.getAllGroups = t.ensureGroupAndParticipants = t.ensureGroup = t.demoteParticipants = t.create = t.canRemove = t.canPromote = t.canDemote = t.canAdd = t.approve = t.addParticipants = void 0;
          var n = r(7103);
          Object.defineProperty(t, "addParticipants", { enumerable: true, get: function() {
            return n.addParticipants;
          } });
          var o = r(57139);
          Object.defineProperty(t, "approve", { enumerable: true, get: function() {
            return o.approve;
          } });
          var i = r(71637);
          Object.defineProperty(t, "canAdd", { enumerable: true, get: function() {
            return i.canAdd;
          } });
          var a = r(976);
          Object.defineProperty(t, "canDemote", { enumerable: true, get: function() {
            return a.canDemote;
          } });
          var s = r(88818);
          Object.defineProperty(t, "canPromote", { enumerable: true, get: function() {
            return s.canPromote;
          } });
          var u = r(8932);
          Object.defineProperty(t, "canRemove", { enumerable: true, get: function() {
            return u.canRemove;
          } });
          var c = r(20292);
          Object.defineProperty(t, "create", { enumerable: true, get: function() {
            return c.create;
          } });
          var l = r(42490);
          Object.defineProperty(t, "demoteParticipants", { enumerable: true, get: function() {
            return l.demoteParticipants;
          } });
          var d = r(23527);
          Object.defineProperty(t, "ensureGroup", { enumerable: true, get: function() {
            return d.ensureGroup;
          } });
          var f = r(97944);
          Object.defineProperty(t, "ensureGroupAndParticipants", { enumerable: true, get: function() {
            return f.ensureGroupAndParticipants;
          } });
          var p = r(26219);
          Object.defineProperty(t, "getAllGroups", { enumerable: true, get: function() {
            return p.getAllGroups;
          } });
          var g = r(45195);
          Object.defineProperty(t, "getGroupInfoFromInviteCode", { enumerable: true, get: function() {
            return g.getGroupInfoFromInviteCode;
          } });
          var m = r(98083);
          Object.defineProperty(t, "getGroupSizeLimit", { enumerable: true, get: function() {
            return m.getGroupSizeLimit;
          } });
          var y = r(55062);
          Object.defineProperty(t, "getInviteCode", { enumerable: true, get: function() {
            return y.getInviteCode;
          } });
          var v = r(4752);
          Object.defineProperty(t, "getMembershipRequests", { enumerable: true, get: function() {
            return v.getMembershipRequests;
          } });
          var b = r(35528);
          Object.defineProperty(t, "getParticipants", { enumerable: true, get: function() {
            return b.getParticipants;
          } });
          var h = r(21268);
          Object.defineProperty(t, "getPastParticipants", { enumerable: true, get: function() {
            return h.getPastParticipants;
          } });
          var _ = r(68780);
          Object.defineProperty(t, "iAmAdmin", { enumerable: true, get: function() {
            return _.iAmAdmin;
          } });
          var P = r(60641);
          Object.defineProperty(t, "iAmMember", { enumerable: true, get: function() {
            return P.iAmMember;
          } });
          var M = r(81484);
          Object.defineProperty(t, "iAmRestrictedMember", { enumerable: true, get: function() {
            return M.iAmRestrictedMember;
          } });
          var w = r(94173);
          Object.defineProperty(t, "iAmSuperAdmin", { enumerable: true, get: function() {
            return w.iAmSuperAdmin;
          } });
          var O = r(84784);
          Object.defineProperty(t, "join", { enumerable: true, get: function() {
            return O.join;
          } });
          var j = r(3329);
          Object.defineProperty(t, "leave", { enumerable: true, get: function() {
            return j.leave;
          } });
          var S = r(10964);
          Object.defineProperty(t, "promoteParticipants", { enumerable: true, get: function() {
            return S.promoteParticipants;
          } });
          var C = r(28703);
          Object.defineProperty(t, "reject", { enumerable: true, get: function() {
            return C.reject;
          } });
          var x = r(34697);
          Object.defineProperty(t, "removeIcon", { enumerable: true, get: function() {
            return x.removeIcon;
          } });
          var I = r(84054);
          Object.defineProperty(t, "removeParticipants", { enumerable: true, get: function() {
            return I.removeParticipants;
          } });
          var A = r(43930);
          Object.defineProperty(t, "revokeInviteCode", { enumerable: true, get: function() {
            return A.revokeInviteCode;
          } });
          var E = r(29166);
          Object.defineProperty(t, "setDescription", { enumerable: true, get: function() {
            return E.setDescription;
          } });
          var T = r(99403);
          Object.defineProperty(t, "setIcon", { enumerable: true, get: function() {
            return T.setIcon;
          } });
          var L = r(76131);
          Object.defineProperty(t, "GroupProperty", { enumerable: true, get: function() {
            return L.GroupProperty;
          } }), Object.defineProperty(t, "setProperty", { enumerable: true, get: function() {
            return L.setProperty;
          } });
          var B = r(36520);
          Object.defineProperty(t, "setSubject", { enumerable: true, get: function() {
            return B.setSubject;
          } });
        }, 84784(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.join = async function(e2) {
            e2 = (e2 = (e2 = (e2 = e2.replace("chat.whatsapp.com/", "")).replace("invite/", "")).replace("https://", "")).replace("http://", "");
            try {
              const t2 = await (0, n.sendJoinGroupViaInvite)(e2);
              return { id: t2.gid.toString(), pendingApproval: t2.membershipApprovalMode };
            } catch (e3) {
              if (e3 instanceof Error && function(e4) {
                return "UnexpectedJoinGroupViaInviteResponse" === e4.name && "gid" in e4 && "membershipApprovalMode" in e4;
              }(e3)) return { id: e3.gid.toString(), pendingApproval: e3.membershipApprovalMode };
              throw e3;
            }
          };
          const n = r(52757);
        }, 3329(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.leave = async function(e2) {
            const t2 = await (0, o.ensureGroup)(e2);
            return await (0, n.sendExitGroup)(t2);
          };
          const n = r(52757), o = r(2818);
        }, 10964(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.promoteParticipants = async function(e2, t2) {
            const { groupChat: r2, participants: n2 } = await (0, c.ensureGroupAndParticipants)(e2, t2);
            if (n2.some((e3) => {
              var t3;
              return !(null === (t3 = r2.groupMetadata) || void 0 === t3 ? void 0 : t3.participants.canPromote(e3));
            })) throw new s.WPPError("group_participant_is_already_a_group_admin", `Group ${r2.id._serialized}: Group participant is already a group admin`);
            return u.promoteParticipants(r2, n2);
          };
          const s = r(62857), u = a(r(52757)), c = r(97944);
        }, 28703(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.reject = async function(e2, t2) {
            e2 = (0, n.assertWid)(e2), Array.isArray(t2) || (t2 = [t2]);
            const r2 = t2.map(n.assertWid);
            try {
              return await (0, i.membershipApprovalRequestAction)(e2, r2, "Reject");
            } catch (t3) {
              throw new o.WPPError("error_on_reject_membership_request", `Error on reject member on group ${e2.toString()}`);
            }
          };
          const n = r(41687), o = r(62857), i = r(52757);
        }, 34697(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.removeIcon = async function(e2) {
            const t2 = await (0, o.ensureGroup)(e2);
            return 200 === (await n.functions.requestDeletePicture(t2.id)).status;
          };
          const n = r(14647), o = r(2818);
        }, 84054(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.removeParticipants = async function(e2, t2) {
            Array.isArray(t2) || (t2 = [t2]);
            const r2 = await (0, l.ensureGroup)(e2, true), n2 = [], o2 = t2.map(s.assertWid);
            for (const e3 of o2) (0, d.findGroupParticipant)(r2, e3) && n2.push(e3);
            if (0 === n2.length) throw new u.WPPError("not_valid_group_participants", `No valid participants found for the group ${e2}`);
            const { participants: i2 } = await (0, d.ensureGroupAndParticipants)(e2, n2);
            if (i2.some((e3) => {
              var t3;
              return !(null === (t3 = r2.groupMetadata) || void 0 === t3 ? void 0 : t3.participants.canRemove(e3));
            })) throw new u.WPPError("group_participant_is_not_a_group_member", `Group ${r2.id._serialized}: Group participant is not a group member`);
            return c.removeParticipants(r2, i2);
          };
          const s = r(41687), u = r(62857), c = a(r(52757)), l = r(23527), d = r(97944);
        }, 43930(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.revokeInviteCode = async function(e2) {
            const t2 = await (0, o.ensureGroup)(e2, true);
            return await (0, n.sendRevokeGroupInviteCode)(t2.id);
          };
          const n = r(52757), o = r(2818);
        }, 29166(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setDescription = async function(e2, t2) {
            var r2, a;
            const s = await (0, i.ensureGroup)(e2);
            if (!(null === (r2 = s.groupMetadata) || void 0 === r2 ? void 0 : r2.canSetDescription())) throw new n.WPPError("you_are_not_allowed_set_group_description", `You are not allowed to set group description in ${s.id._serialized}`, { groupId: s.id.toString() });
            const u = await Promise.resolve((0, o.randomMessageId)());
            return await (0, o.sendSetGroupDescription)(s.id, t2, u, null === (a = s.groupMetadata) || void 0 === a ? void 0 : a.descId), s.groupMetadata.descId = u, s.groupMetadata.desc = t2, true;
          };
          const n = r(62857), o = r(52757), i = r(2818);
        }, 99403(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setIcon = async function(e2, t2) {
            const r2 = await (0, i.ensureGroup)(e2);
            if (await (0, i.iAmRestrictedMember)(e2)) throw new n.WPPError("group_you_are_restricted_member", `You are a restricted member in ${r2.id._serialized}`);
            const a = await (0, n.convertToFile)(t2), s = await (0, n.resizeImage)(a, { width: 96, height: 96, mimeType: "image/jpeg", resize: "cover" }), u = await (0, n.resizeImage)(a, { width: 640, height: 640, mimeType: "image/jpeg", resize: "cover" }), c = await (0, n.blobToBase64)(s), l = await (0, n.blobToBase64)(u);
            return (0, o.sendSetPicture)(r2.id, c, l);
          };
          const n = r(62857), o = r(52757), i = r(2818);
        }, 76131(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.GroupProperty = void 0, t.setProperty = async function(e2, t2, r2) {
            var s, u;
            const c = await (0, i.ensureGroup)(e2);
            if (t2 !== a.ANNOUNCEMENT && !(null === (s = c.groupMetadata) || void 0 === s ? void 0 : s.canSetGroupProperty())) throw new n.WPPError("you_are_not_allowed_set_group_property", `You are not allowed to set property in ${c.id._serialized}`, { groupId: c.id.toString() });
            if (t2 == a.ANNOUNCEMENT && !(null === (u = c.groupMetadata) || void 0 === u ? void 0 : u.canSetEphemeralSetting())) throw new n.WPPError("you_are_not_allowed_set_ephemeral_setting", `You are not allowed to set ephemeral setting in ${c.id._serialized}`, { groupId: c.id.toString() });
            if (t2 === a.EPHEMERAL) {
              if ("boolean" != typeof r2 && 1 !== r2 || (r2 = 604800), ![0, 86400, 604800, 7776e3].includes(r2)) throw new n.WPPError("invalid_ephemeral_duration", "Invalid ephemeral duration", { value: r2 });
            } else r2 = r2 ? 1 : 0;
            return await (0, o.sendSetGroupProperty)(c.id, t2, r2), true;
          };
          const n = r(62857), o = r(52757), i = r(2818);
          var a;
          !function(e2) {
            e2.ANNOUNCEMENT = "announcement", e2.EPHEMERAL = "ephemeral", e2.RESTRICT = "restrict";
          }(a || (t.GroupProperty = a = {}));
        }, 36520(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setSubject = async function(e2, t2) {
            var r2;
            const a = await (0, i.ensureGroup)(e2);
            if (!(null === (r2 = a.groupMetadata) || void 0 === r2 ? void 0 : r2.canSetSubject())) throw new n.WPPError("you_are_not_allowed_set_group_subject", `You are not allowed to set group subject in ${a.id._serialized}`, { groupId: a.id.toString() });
            return await (0, o.sendSetGroupSubject)(a.id, t2), a.name = t2, a.formattedTitle = t2, true;
          };
          const n = r(62857), o = r(52757), i = r(2818);
        }, 64456(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), r(86288), o(r(2818), t);
        }, 26738(e, t, r) {
          "use strict";
          var n = this && this.__decorate || function(e2, t2, r2, n2) {
            var o2, i2 = arguments.length, a2 = i2 < 3 ? t2 : null === n2 ? n2 = Object.getOwnPropertyDescriptor(t2, r2) : n2;
            if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a2 = Reflect.decorate(e2, t2, r2, n2);
            else for (var s = e2.length - 1; s >= 0; s--) (o2 = e2[s]) && (a2 = (i2 < 3 ? o2(a2) : i2 > 3 ? o2(t2, r2, a2) : o2(t2, r2)) || a2);
            return i2 > 3 && a2 && Object.defineProperty(t2, r2, a2), a2;
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.Tracker = void 0;
          const o = r(20748);
          function i(e2 = 0, t2 = 2147483647) {
            return Math.floor(Math.random() * (t2 - e2 + 1) + e2);
          }
          class a {
            static get clientState() {
              const e2 = !localStorage.cid, t2 = localStorage.cid || sessionStorage.cid || i(1e9) + "." + Math.floor(Date.now() / 1e3);
              return localStorage.cid = sessionStorage.cid = t2, { firstVisit: e2, cid: t2 };
            }
            constructor(e2) {
              this.trackingId = e2, this.events = [], this.userProperties = {}, this.lastTime = Date.now(), this.hitsCount = 1, this.documentTitle = "";
            }
            get sid() {
              const e2 = `${this.trackingId}_sid`, t2 = sessionStorage[e2] || Math.floor(Date.now() / 1e3);
              return sessionStorage[e2] = t2, t2;
            }
            get sct() {
              const e2 = `${this.trackingId}_sct`;
              let t2 = parseInt(localStorage[e2]);
              return isNaN(t2) && (t2 = 0), localStorage[e2] = t2 + 1, localStorage[e2];
            }
            getHeader() {
              const { cid: e2, firstVisit: t2 } = a.clientState;
              return { v: 2, tid: this.trackingId, _p: a.pageLoadHash, cid: e2, _fv: t2 ? 1 : void 0, ul: (navigator.language || "").toLowerCase() || void 0, sr: `${screen.width}x${screen.height}`, _s: this.hitsCount++, sid: this.sid, sct: this.sct, seg: 1, dl: location.href, dr: document.referrer, dt: this.documentTitle || document.title };
            }
            getUserProperties() {
              const e2 = this.userProperties;
              this.userProperties = {};
              return Object.entries(e2).filter(([, e3]) => void 0 !== e3).map(([e3, t2]) => "number" == typeof t2 ? [`upn.${e3}`, String(t2)] : [`up.${e3}`, String(t2)]);
            }
            processEvents() {
              const e2 = this.events;
              if (this.events = [], !e2.length) return;
              const t2 = e2.map(([e3, t3, r3]) => {
                const n3 = [];
                if (n3.push(["en", e3]), n3.push(["_ee", "1"]), t3) for (const e4 in t3) {
                  const r4 = t3[e4];
                  void 0 !== r4 && ("number" == typeof r4 ? n3.push([`epn.${e4}`, String(r4)]) : n3.push([`ep.${e4}`, String(r4)]));
                }
                return n3.push(["_et", String(r3)]), n3;
              }), r2 = Object.entries(this.getHeader()).filter(([, e3]) => void 0 !== e3).map(([e3, t3]) => [e3, String(t3)]);
              r2.push(...this.getUserProperties());
              const n2 = new URLSearchParams(r2);
              if (1 === t2.length) {
                for (const [e3, r3] of t2[0]) n2.append(e3, r3);
                navigator.sendBeacon(`${a.collectURL}?${n2.toString()}`);
              } else {
                const e3 = t2.map((e4) => new URLSearchParams(e4).toString());
                navigator.sendBeacon(`${a.collectURL}?${n2.toString()}`, e3.join("\n"));
              }
            }
            processUserEngagement() {
              this.trackEvent("user_engagement");
            }
            trackEvent(e2, t2) {
              const r2 = Date.now(), n2 = r2 - this.lastTime;
              this.lastTime = r2, this.events.push([e2, t2, n2]), this.processEvents(), this.processUserEngagement();
            }
            setUserProperty(e2, t2) {
              this.userProperties[e2] = t2, this.trackEvent("user_engagement");
            }
          }
          t.Tracker = a, a.collectURL = "https://analytics.google.com/g/collect", a.pageLoadHash = i(), n([(0, o.debounce)(1e3)], a.prototype, "processEvents", null), n([(0, o.debounce)(3e5)], a.prototype, "processUserEngagement", null);
        }, 22418(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          }), s = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || o(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.waVersion = void 0, t.trackException = function(e2, t2 = false) {
            if (u.config.disableGoogleAnalytics) return;
            p.trackEvent("exception", { description: e2, fatal: t2 }), g && g.trackEvent("exception", { description: e2, fatal: t2 });
          };
          const u = r(91491), c = a(r(72927)), l = r(13691), d = r(26738);
          s(r(26738), t), t.waVersion = "4.5.0";
          const f = ["W: ", "-", ", WA-JS: ", t.waVersion], p = new d.Tracker("G-MTQ4KY110F"), g = u.config.googleAnalyticsId ? new d.Tracker(u.config.googleAnalyticsId) : null;
          l.internalEv.on("loader.injected", () => {
            const e2 = c.isAuthenticated(), r2 = c.isMultiDevice() ? "multidevice" : "legacy";
            if (u.config.disableGoogleAnalytics || (p.documentTitle = f.join(""), p.setUserProperty("method", r2), p.setUserProperty("wa_js", t.waVersion), p.setUserProperty("powered_by", u.config.poweredBy || "-")), l.internalEv.on("conn.main_init", () => {
              var e3;
              f[1] = (null === (e3 = window.Debug) || void 0 === e3 ? void 0 : e3.VERSION) || "-", u.config.disableGoogleAnalytics || (p.documentTitle = f.join(""), p.setUserProperty("whatsapp", f[1]));
            }), g && !u.config.disableGoogleAnalytics) {
              if (p.trackEvent("page_view", { authenticated: e2, method: r2 }), g.documentTitle = f.join("-"), g.setUserProperty("method", r2), g.setUserProperty("wa_js", t.waVersion), g.setUserProperty("powered_by", u.config.poweredBy || "-"), l.internalEv.on("conn.main_init", () => {
                var e3;
                f[1] = (null === (e3 = window.Debug) || void 0 === e3 ? void 0 : e3.VERSION) || "-", g.documentTitle = f.join(""), g.setUserProperty("whatsapp", f[1]);
              }), "object" == typeof u.config.googleAnalyticsUserProperty) for (const e3 in u.config.googleAnalyticsUserProperty) {
                const t2 = u.config.googleAnalyticsUserProperty[e3];
                g.setUserProperty(e3, t2);
              }
              g.trackEvent("page_view", { authenticated: e2, method: r2 });
            }
            l.internalEv.on("config.update", (e3) => {
              if (!u.config.disableGoogleAnalytics) {
                if ("poweredBy" === e3.path[0]) p.setUserProperty("powered_by", e3.value || "-"), g && g.setUserProperty("powered_by", e3.value || "-");
                else if ("googleAnalyticsUserProperty" === e3.path[0] && g && "object" == typeof u.config.googleAnalyticsUserProperty) for (const e4 in u.config.googleAnalyticsUserProperty) {
                  const t2 = u.config.googleAnalyticsUserProperty[e4];
                  g.setUserProperty(e4, t2);
                }
              }
            });
          }), u.config.disableGoogleAnalytics || (l.internalEv.on("conn.authenticated", () => {
            const e2 = c.isMultiDevice() ? "multidevice" : "legacy";
            p.trackEvent("login", { method: e2 }), g && p.trackEvent("login", { method: e2 });
          }), l.internalEv.on("conn.logout", () => {
            const e2 = c.isMultiDevice() ? "multidevice" : "legacy";
            p.trackEvent("logout", { method: e2 }), g && g.trackEvent("logout", { method: e2 });
          }));
        }, 28156(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.version = t.waitFor = t.stopListeningTo = t.setMaxListeners = t.removeListener = t.removeAllListeners = t.prependOnceListener = t.prependMany = t.prependListener = t.prependAny = t.once = t.onAny = t.on = t.offAny = t.off = t.many = t.listenTo = t.listenersAny = t.listeners = t.listenerCount = t.hasListeners = t.getMaxListeners = t.eventNames = t.emitAsync = t.emit = t.whatsapp = t.util = t.status = t.profile = t.privacy = t.order = t.newsletter = t.labels = t.indexdb = t.group = t.ev = t.contact = t.conn = t.community = t.chat = t.catalog = t.cart = t.call = t.lists = t.blocklist = t.config = t.loader = t.isReady = t.isInjected = t.isFullReady = void 0, t.dev = t.license = t.supportedWhatsappWeb = void 0, r(91491), r(80687), r(22418);
          const s = a(r(7222));
          t.loader = s;
          var u = r(7222);
          Object.defineProperty(t, "isFullReady", { enumerable: true, get: function() {
            return u.isFullReady;
          } }), Object.defineProperty(t, "isInjected", { enumerable: true, get: function() {
            return u.isInjected;
          } }), Object.defineProperty(t, "isReady", { enumerable: true, get: function() {
            return u.isReady;
          } });
          var c = r(91491);
          Object.defineProperty(t, "config", { enumerable: true, get: function() {
            return c.config;
          } }), t.blocklist = a(r(61042)), t.lists = a(r(22086)), t.call = a(r(38893)), t.cart = a(r(81151)), t.catalog = a(r(40164)), t.chat = a(r(74023)), t.community = a(r(83874)), t.conn = a(r(72927)), t.contact = a(r(56191)), t.ev = a(r(13691)), t.group = a(r(64456)), t.indexdb = a(r(60513)), t.labels = a(r(48486)), t.newsletter = a(r(74310)), t.order = a(r(37783)), t.privacy = a(r(33599)), t.profile = a(r(5882)), t.status = a(r(31167)), t.util = a(r(62857)), t.whatsapp = a(r(14647));
          var l = r(13691);
          Object.defineProperty(t, "emit", { enumerable: true, get: function() {
            return l.emit;
          } }), Object.defineProperty(t, "emitAsync", { enumerable: true, get: function() {
            return l.emitAsync;
          } }), Object.defineProperty(t, "eventNames", { enumerable: true, get: function() {
            return l.eventNames;
          } }), Object.defineProperty(t, "getMaxListeners", { enumerable: true, get: function() {
            return l.getMaxListeners;
          } }), Object.defineProperty(t, "hasListeners", { enumerable: true, get: function() {
            return l.hasListeners;
          } }), Object.defineProperty(t, "listenerCount", { enumerable: true, get: function() {
            return l.listenerCount;
          } }), Object.defineProperty(t, "listeners", { enumerable: true, get: function() {
            return l.listeners;
          } }), Object.defineProperty(t, "listenersAny", { enumerable: true, get: function() {
            return l.listenersAny;
          } }), Object.defineProperty(t, "listenTo", { enumerable: true, get: function() {
            return l.listenTo;
          } }), Object.defineProperty(t, "many", { enumerable: true, get: function() {
            return l.many;
          } }), Object.defineProperty(t, "off", { enumerable: true, get: function() {
            return l.off;
          } }), Object.defineProperty(t, "offAny", { enumerable: true, get: function() {
            return l.offAny;
          } }), Object.defineProperty(t, "on", { enumerable: true, get: function() {
            return l.on;
          } }), Object.defineProperty(t, "onAny", { enumerable: true, get: function() {
            return l.onAny;
          } }), Object.defineProperty(t, "once", { enumerable: true, get: function() {
            return l.once;
          } }), Object.defineProperty(t, "prependAny", { enumerable: true, get: function() {
            return l.prependAny;
          } }), Object.defineProperty(t, "prependListener", { enumerable: true, get: function() {
            return l.prependListener;
          } }), Object.defineProperty(t, "prependMany", { enumerable: true, get: function() {
            return l.prependMany;
          } }), Object.defineProperty(t, "prependOnceListener", { enumerable: true, get: function() {
            return l.prependOnceListener;
          } }), Object.defineProperty(t, "removeAllListeners", { enumerable: true, get: function() {
            return l.removeAllListeners;
          } }), Object.defineProperty(t, "removeListener", { enumerable: true, get: function() {
            return l.removeListener;
          } }), Object.defineProperty(t, "setMaxListeners", { enumerable: true, get: function() {
            return l.setMaxListeners;
          } }), Object.defineProperty(t, "stopListeningTo", { enumerable: true, get: function() {
            return l.stopListeningTo;
          } }), Object.defineProperty(t, "waitFor", { enumerable: true, get: function() {
            return l.waitFor;
          } }), t.version = "4.5.0", t.supportedWhatsappWeb = ">=2.3000.1038792969-alpha", t.license = "Apache-2.0", s.injectLoader();
        }, 56802(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMessagesFromRowId = async function(e2) {
            const { minRowId: t2, limit: r = 1e3 } = e2;
            if ("number" != typeof t2) throw new Error("minRowId must be a number");
            if (!Number.isFinite(t2)) throw new Error("minRowId must be a finite number");
            if (t2 < 0) throw new Error("minRowId must be a non-negative number");
            if ("number" != typeof r) throw new Error("limit must be a number");
            if (!Number.isFinite(r)) throw new Error("limit must be a finite number");
            if (-1 !== r && r <= 0) throw new Error("limit must be either -1 (unlimited) or a positive number");
            return new Promise((e3, n) => {
              const o = indexedDB.open("model-storage");
              o.onsuccess = function(o2) {
                const i = o2.target.result, a = i.transaction(["message"], "readonly").objectStore("message").index("rowId"), s = IDBKeyRange.lowerBound(t2, true), u = [], c = a.openCursor(s);
                c.onsuccess = function(t3) {
                  const n2 = t3.target.result;
                  n2 && (r < 0 || u.length < r) ? (u.push(n2.value), n2.continue()) : (i.close(), e3(u));
                }, c.onerror = function() {
                  i.close(), n(c.error);
                };
              }, o.onerror = function() {
                n(o.error);
              };
            });
          };
        }, 72355(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMessagesFromRowId = void 0;
          var n = r(56802);
          Object.defineProperty(t, "getMessagesFromRowId", { enumerable: true, get: function() {
            return n.getMessagesFromRowId;
          } });
        }, 60513(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(72355), t);
        }, 4475(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.addNewLabel = async function(e2, t2 = {}) {
            (0, n.assertIsBusiness)();
            let r2 = t2.labelColor || void 0;
            r2 || (r2 = await (0, a.getNewLabelColor)());
            "string" == typeof r2 && r2.length > 2 && (r2 = (0, i.getAllLabelColors)().findIndex((e3) => e3 === r2));
            if (r2 = parseInt(r2.toString()), !await (0, a.colorIsInLabelPalette)(r2)) throw new o.WPPError("color_not_in_pallet", "Color not in pallet");
            const s = await (0, i.getNextLabelId)();
            return await (0, i.labelAddAction)(e2, r2), await (0, a.getLabelById)(s.toString());
          };
          const n = r(41687), o = r(62857), i = r(52757), a = r(62540);
        }, 3105(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.addOrRemoveLabels = async function(e2, t2) {
            (0, n.assertIsBusiness)(), Array.isArray(e2) || (e2 = [e2]);
            Array.isArray(t2) || (t2 = [t2]);
            const r2 = e2.map((e3) => (0, n.assertGetChat)(e3)), i = t2.map((e3) => ({ id: e3.labelId, type: e3.type }));
            return await o.LabelStore.addOrRemoveLabels(i, r2);
          };
          const n = r(41687), o = r(14647);
        }, 9793(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.colorIsInLabelPalette = async function(e2) {
            (0, n.assertIsBusiness)();
            const t2 = await (0, o.getLabelColorPalette)();
            return t2 && (t2.includes(e2.toString()) || null != t2[parseInt(e2.toString())]);
          };
          const n = r(41687), o = r(62540);
        }, 90805(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.deleteAllLabels = async function() {
            (0, n.assertIsBusiness)();
            const e2 = await (0, o.getAllLabels)();
            return (0, o.deleteLabel)(e2.map((e3) => e3.id));
          };
          const n = r(41687), o = r(62540);
        }, 50451(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.deleteLabel = async function(e2) {
            var t2;
            (0, n.assertIsBusiness)();
            let r2 = false;
            Array.isArray(e2) || (r2 = true, e2 = [e2]);
            const a = [];
            for (const r3 of e2) {
              const e3 = o.LabelStore.get(r3.toString());
              e3 && await (0, i.callLabelDeleteAction)(r3.toString(), e3.name, null !== (t2 = e3.colorIndex) && void 0 !== t2 ? t2 : 0), a.push({ id: r3, deleteLabelResult: null != e3 && null == o.LabelStore.get(r3.toString()) });
            }
            if (r2) return a[0];
            return a;
          };
          const n = r(41687), o = r(14647), i = r(64794);
        }, 40866(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.editLabel = async function(e2, t2 = {}) {
            (0, n.assertIsBusiness)();
            const r2 = i.LabelStore.get(e2.toString());
            if (!r2) throw new o.WPPError("label_not_exist", `Label with id ${e2} not exist`);
            let u = t2.labelColor || void 0;
            if (u && ("string" == typeof u && u.length > 2 && (u = (0, a.getAllLabelColors)().findIndex((e3) => e3 === u)), u = parseInt(u.toString()), !await (0, s.colorIsInLabelPalette)(u))) throw new o.WPPError("color_not_in_pallet", "Color not in pallet");
            return await (0, a.labelEditAction)(e2, t2.name || r2.name, 0, u || r2.colorIndex), await (0, s.getLabelById)(e2.toString());
          };
          const n = r(41687), o = r(62857), i = r(14647), a = r(52757), s = r(62540);
        }, 90846(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getAllLabels = async function() {
            return o.LabelStore.getModelsArray().map((e2) => ({ id: e2.id, name: e2.name, color: e2.hexColor ? (0, n.assertColor)(e2.hexColor) : null, count: (0, a.patchLabelCount)(e2), hexColor: (0, i.colorIndexToHex)(e2.colorIndex), colorIndex: e2.colorIndex }));
          };
          const n = r(41687), o = r(14647), i = r(52757), a = r(30612);
        }, 28068(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getLabelById = async function(e2) {
            const t2 = i.LabelStore.get(e2);
            if (!t2) throw new o.WPPError("canot_get_label_error", "Can't get label by id");
            return { id: t2.id, name: t2.name, color: t2.hexColor ? (0, n.assertColor)(t2.hexColor) : null, count: (0, s.patchLabelCount)(t2), hexColor: (0, a.colorIndexToHex)(t2.colorIndex), colorIndex: t2.colorIndex };
          };
          const n = r(41687), o = r(62857), i = r(14647), a = r(52757), s = r(30612);
        }, 5978(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getLabelColorPalette = async function() {
            (0, n.assertIsBusiness)();
            const e2 = (0, i.getAllLabelColors)();
            if (!e2) throw new o.WPPError("canot_get_color_palette", "Can't get color palette");
            return e2;
          };
          const n = r(41687), o = r(62857), i = r(52757);
        }, 34753(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getNewLabelColor = async function() {
            (0, n.assertIsBusiness)();
            const e2 = await i.LabelStore.getNextAvailableColor();
            if (!e2) throw new o.WPPError("cannot_get_color", "Can't get new label color");
            return (0, n.assertColor)(Number(e2));
          };
          const n = r(41687), o = r(62857), i = r(14647);
        }, 62540(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getNewLabelColor = t.getLabelColorPalette = t.getLabelById = t.getAllLabels = t.editLabel = t.deleteLabel = t.deleteAllLabels = t.colorIsInLabelPalette = t.addOrRemoveLabels = t.addNewLabel = void 0;
          var n = r(4475);
          Object.defineProperty(t, "addNewLabel", { enumerable: true, get: function() {
            return n.addNewLabel;
          } });
          var o = r(3105);
          Object.defineProperty(t, "addOrRemoveLabels", { enumerable: true, get: function() {
            return o.addOrRemoveLabels;
          } });
          var i = r(9793);
          Object.defineProperty(t, "colorIsInLabelPalette", { enumerable: true, get: function() {
            return i.colorIsInLabelPalette;
          } });
          var a = r(90805);
          Object.defineProperty(t, "deleteAllLabels", { enumerable: true, get: function() {
            return a.deleteAllLabels;
          } });
          var s = r(50451);
          Object.defineProperty(t, "deleteLabel", { enumerable: true, get: function() {
            return s.deleteLabel;
          } });
          var u = r(40866);
          Object.defineProperty(t, "editLabel", { enumerable: true, get: function() {
            return u.editLabel;
          } });
          var c = r(90846);
          Object.defineProperty(t, "getAllLabels", { enumerable: true, get: function() {
            return c.getAllLabels;
          } });
          var l = r(28068);
          Object.defineProperty(t, "getLabelById", { enumerable: true, get: function() {
            return l.getLabelById;
          } });
          var d = r(5978);
          Object.defineProperty(t, "getLabelColorPalette", { enumerable: true, get: function() {
            return d.getLabelColorPalette;
          } });
          var f = r(34753);
          Object.defineProperty(t, "getNewLabelColor", { enumerable: true, get: function() {
            return f.getNewLabelColor;
          } });
        }, 48486(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(62540), t), o(r(27055), t);
        }, 30612(e, t, r) {
          "use strict";
          t.patchLabelCount = function(e2) {
            let t2 = 0;
            for (const r2 of e2.labelItemCollection._models) {
              if ("Chat" !== r2.parentType) continue;
              const e3 = n.ChatStore.get(r2.parentId);
              (null == e3 ? void 0 : e3.archive) || (t2 += 1);
            }
            return t2;
          };
          const n = r(14647);
        }, 27055(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
        }, 75228(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.addChats = async function(e2, t2) {
            if (0 === t2.length) return;
            if (!i.LabelStore.get(e2)) throw new o.WPPError("list_not_found", `List ${e2} not found`, { id: e2 });
            const r2 = t2.map((e3) => (0, n.assertGetChat)(e3));
            await i.LabelStore.addOrRemoveLabels([{ id: e2, type: "add" }], r2);
          };
          const n = r(41687), o = r(62857), i = r(14647);
        }, 63886(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.create = async function(e2, t2 = [], r2) {
            var s;
            if (!(null == e2 ? void 0 : e2.trim())) throw new o.WPPError("list_name_required", "List name is required");
            if (void 0 !== r2 && (!Number.isInteger(r2) || r2 < 0)) throw new o.WPPError("list_invalid_color", "colorIndex must be a non-negative integer");
            const u = void 0 !== r2 ? r2 : null !== (s = await i.LabelStore.getNextAvailableColor()) && void 0 !== s ? s : 0, c = await (0, a.getNextLabelId)();
            if (await (0, a.labelAddAction)(e2.trim(), u), t2.length > 0) {
              const e3 = t2.map((e4) => (0, n.assertGetChat)(e4));
              await i.LabelStore.addOrRemoveLabels([{ id: String(c), type: "add" }], e3);
            }
            return String(c);
          };
          const n = r(41687), o = r(62857), i = r(14647), a = r(52757);
        }, 88204(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.rename = t.removeChats = t.remove = t.list = t.create = t.addChats = void 0;
          var n = r(75228);
          Object.defineProperty(t, "addChats", { enumerable: true, get: function() {
            return n.addChats;
          } });
          var o = r(63886);
          Object.defineProperty(t, "create", { enumerable: true, get: function() {
            return o.create;
          } });
          var i = r(87790);
          Object.defineProperty(t, "list", { enumerable: true, get: function() {
            return i.list;
          } });
          var a = r(31034);
          Object.defineProperty(t, "remove", { enumerable: true, get: function() {
            return a.remove;
          } });
          var s = r(46131);
          Object.defineProperty(t, "removeChats", { enumerable: true, get: function() {
            return s.removeChats;
          } });
          var u = r(55388);
          Object.defineProperty(t, "rename", { enumerable: true, get: function() {
            return u.rename;
          } });
        }, 87790(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.list = function() {
            return n.LabelStore.getModelsArray().filter((e2) => 5 === e2.type).map((e2) => {
              var t2;
              return { id: String(e2.id), name: e2.name, colorIndex: null !== (t2 = e2.colorIndex) && void 0 !== t2 ? t2 : 0 };
            });
          };
          const n = r(14647);
        }, 31034(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.remove = async function(e2) {
            var t2;
            const r2 = o.LabelStore.get(e2);
            if (!r2) throw new n.WPPError("list_not_found", `List ${e2} not found`, { id: e2 });
            await (0, i.callLabelDeleteAction)(e2, r2.name, null !== (t2 = r2.colorIndex) && void 0 !== t2 ? t2 : 0);
          };
          const n = r(62857), o = r(14647), i = r(64794);
        }, 46131(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.removeChats = async function(e2, t2) {
            if (0 === t2.length) return;
            if (!i.LabelStore.get(e2)) throw new o.WPPError("list_not_found", `List ${e2} not found`, { id: e2 });
            const r2 = t2.map((e3) => (0, n.assertGetChat)(e3));
            await i.LabelStore.addOrRemoveLabels([{ id: e2, type: "remove" }], r2);
          };
          const n = r(41687), o = r(62857), i = r(14647);
        }, 55388(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.rename = async function(e2, t2) {
            var r2, a;
            if (!(null == t2 ? void 0 : t2.trim())) throw new n.WPPError("list_name_required", "List name is required");
            const s = o.LabelStore.get(e2);
            if (!s) throw new n.WPPError("list_not_found", `List ${e2} not found`, { id: e2 });
            await (0, i.labelEditAction)(e2, t2.trim(), null !== (r2 = s.predefinedId) && void 0 !== r2 ? r2 : 0, null !== (a = s.colorIndex) && void 0 !== a ? a : 0);
          };
          const n = r(62857), o = r(14647), i = r(52757);
        }, 22086(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(88204), t);
        }, 22769(e, t) {
          "use strict";
          t.IGNORE_FAIL_MODULES = t.META_MODULE_ID_BLACKLIST = void 0, t.META_MODULE_ID_BLACKLIST = /* @__PURE__ */ new Set(["WAWebEmojiPanelContentEmojiSearchEmpty.react", "WAWebMoment-es-do"]), t.IGNORE_FAIL_MODULES = /* @__PURE__ */ new Set(["revokeStatus", "toggleNewsletterAdminActivityMuteStateAction", "msgFindQuery", "msgFindBefore", "msgFindAfter", "msgFindByDirection", "msgFindCallLog", "msgFindEvents", "msgFindMedia", "msgFindSearch", "msgFindStarred", "CartItemCollection", "subscribeGroupPresence", "muteNewsletter", "unmuteNewsletter", "ServerPropsModel", "getUserhash", "Constants"]);
        }, 7222(e, t, r) {
          "use strict";
          var n = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.fallbackModules = t.moduleRequire = t.__debug = t.isFullReady = t.isReady = t.isInjected = t.loaderType = void 0, t.onInjected = function(e2, t2 = 0) {
            i.internalEv.on("loader.injected", () => {
              setTimeout(e2, t2);
            });
          }, t.onReady = function(e2, t2 = 0) {
            i.internalEv.on("loader.ready", () => {
              setTimeout(e2, t2);
            });
          }, t.onFullReady = function(e2, t2 = 0) {
            i.internalEv.on("loader.full_ready", () => {
              setTimeout(e2, t2);
            });
          }, t.injectLoader = function() {
            if (t.isInjected) return;
            const e2 = self || window;
            !function(e3) {
              const r3 = () => {
                "unknown" === t.loaderType && e3.require && e3.__d && async function(e4) {
                  if ("unknown" !== t.loaderType) return;
                  t.loaderType = "meta", t.moduleRequire = function(t2) {
                    try {
                      return e4.ErrorGuard.skipGuardGlobal(true), e4.importNamespace(t2);
                    } catch (e5) {
                    }
                    return null;
                  }, Object.defineProperty(t.moduleRequire, "m", { get: () => function() {
                    var e5;
                    const r4 = (0, t.__debug)().modulesMap, n4 = Object.keys(r4);
                    if (l && n4.length === d) return l;
                    const o4 = {};
                    for (const t2 of n4) /^(?:use)?WA/.test(t2) && !a.META_MODULE_ID_BLACKLIST.has(t2) && (o4[t2] = null === (e5 = r4[t2]) || void 0 === e5 ? void 0 : e5.factory);
                    return l = o4, d = n4.length, o4;
                  }() }), await async function({ quiet: e5 = 750, timeout: r4 = 2e4, poll: n4 = 100 } = {}) {
                    const o4 = () => {
                      try {
                        return Object.keys((0, t.__debug)().modulesMap).length;
                      } catch (e6) {
                        return 0;
                      }
                    }, i2 = Date.now() + r4;
                    let a2 = o4(), u2 = Date.now();
                    for (; Date.now() < i2; ) {
                      await new Promise((e6) => setTimeout(e6, n4));
                      const t2 = o4();
                      if (t2 !== a2) a2 = t2, u2 = Date.now();
                      else if (t2 > 0 && Date.now() - u2 >= e5) return void s(`meta modules settled at ${t2} (quiet ${e5}ms)`);
                    }
                    s(`meta modules settle timed out after ${r4}ms (count ${a2})`);
                  }(), t.isInjected = true, s("injected"), await i.internalEv.emitAsync("loader.injected").catch(() => null), await u;
                  await async function(e5, { timeout: t2 = 3e4, initialDelay: r4 = 50, maxDelay: n4 = 500 } = {}) {
                    const o4 = Date.now() + t2;
                    let i2 = r4, a2 = e5();
                    if (a2) return a2;
                    for (; Date.now() < o4; ) {
                      if (await new Promise((e6) => setTimeout(e6, i2)), a2 = e5(), a2) return a2;
                      i2 = Math.min(n4, Math.floor(1.5 * i2));
                    }
                    return null;
                  }(() => {
                    try {
                      return (0, t.moduleRequire)("WAWebUserPrefsMeUser");
                    } catch (e5) {
                      return null;
                    }
                  }, { timeout: 5e3, initialDelay: 25, maxDelay: 250 }) || s("meta loader: core module not resolvable within 5s, continuing");
                  t.isReady = true, s("ready to use"), await i.internalEv.emitAsync("loader.ready").catch(() => null), window.wppForceMainLoad ? (s("wppForceMainLoad is set, waiting 5 seconds"), await new Promise((e5) => setTimeout(e5, 5e3))) : (s("waiting main ready"), await c);
                  t.isFullReady = true, s("full ready to use"), await i.internalEv.emitAsync("loader.full_ready").catch(() => null);
                }(e3);
              };
              if (e3.require && e3.__d) return void r3();
              const n3 = (t2) => {
                const n4 = Object.getOwnPropertyDescriptor(e3, t2);
                if (n4 && false === n4.configurable) return false;
                let o4 = null == n4 ? void 0 : n4.value;
                try {
                  return Object.defineProperty(e3, t2, { configurable: true, enumerable: true, get: () => o4, set(e4) {
                    o4 = e4, r3();
                  } }), true;
                } catch (e4) {
                  return false;
                }
              }, o3 = n3("__d"), f2 = n3("require"), p2 = setInterval(() => {
                "unknown" === t.loaderType ? r3() : clearInterval(p2);
              }, 250);
              setTimeout(() => clearInterval(p2), 6e4), o3 && f2 || s("meta loader: setter trap unavailable, relying on fallback poll");
            }(e2);
            const r2 = "webpackChunkwhatsapp_web_client", n2 = e2[r2] || [];
            n2 && 0 !== (null == n2 ? void 0 : n2.length) ? t.loaderType = "webpack" : Object.defineProperty(e2, r2, n2);
            const o2 = Date.now();
            n2.push([[o2], {}, (e3) => {
              t.moduleRequire = e3, queueMicrotask(() => (async (e4) => {
                t.loaderType = "webpack", t.moduleRequire = e4, t.isInjected = true, s("injected"), await i.internalEv.emitAsync("loader.injected").catch(() => null), await new Promise((e5) => setTimeout(e5, 500));
                const r3 = new Array(1e4).fill(1).map((e5, t2) => e5 + t2).filter((e5) => {
                  const r4 = t.moduleRequire.u(e5);
                  return r4.includes("locales") ? navigator.languages.some((e6) => r4.includes(`locales/${e6}`)) : !r4.includes("undefined");
                }), n3 = r3.filter((e5) => {
                  const r4 = t.moduleRequire.u(e5);
                  return r4.includes("main") && !r4.includes("locales");
                });
                for (const e5 of n3) try {
                  await t.moduleRequire.e(e5);
                } catch (r4) {
                  s("load file error", t.moduleRequire.u(e5));
                }
                t.isReady = true, s("ready to use"), await i.internalEv.emitAsync("loader.ready").catch(() => null), s("wppForceMainLoad", window.wppForceMainLoad), window.wppForceMainLoad ? await new Promise((e5) => setTimeout(e5, 5e3)) : await c, s("loading full runtime files");
                for (const e5 of r3) try {
                  await t.moduleRequire.e(e5);
                } catch (r4) {
                  s("load file error", t.moduleRequire.u(e5));
                }
                s("all runtime files loaded"), t.isFullReady = true, s("full ready to use"), await i.internalEv.emitAsync("loader.full_ready").catch(() => null);
              })(e3));
            }]);
          }, t.moduleSource = p, t.isReactComponent = _, t.searchId = j, t.search = function(e2, t2 = false, r2) {
            const n2 = j(e2, t2, r2);
            if (!n2) return null;
            return S(n2);
          }, t.modules = function(e2, r2 = false) {
            const n2 = {};
            let o2 = Object.keys(t.moduleRequire.m);
            r2 && (o2 = o2.reverse());
            for (const r3 of o2) if ("webpack" !== t.loaderType || !_(r3)) try {
              const o3 = S(r3);
              if ("webpack" !== t.loaderType && h(r3, o3)) continue;
              e2 && !e2(o3, r3) || (n2[r3] = o3);
            } catch (e3) {
              continue;
            }
            return s(`${Object.keys(n2).length} modules found with: ${null == e2 ? void 0 : e2.toString()}`), n2;
          }, t.loadModule = S, t.injectFallbackModule = function(e2, r2) {
            if (/^fallback_/.test(e2 += "")) throw new Error("Invalid fallback ID");
            t.fallbackModules[`fallback_${e2}`] = r2;
          };
          const o = n(r(17833)), i = r(13691), a = r(22769), s = (0, o.default)("WA-JS:loader");
          t.loaderType = "unknown", t.isInjected = false, t.isReady = false, t.isFullReady = false;
          t.__debug = () => (self || window).require("__debug"), t.fallbackModules = {};
          const u = i.internalEv.waitFor("conn.main_init"), c = i.internalEv.waitFor("conn.main_ready");
          let l = null, d = -1;
          const f = /* @__PURE__ */ new Map();
          function p(e2) {
            if ("webpack" !== t.loaderType) return "";
            if (!t.moduleRequire.m[e2]) return "";
            if (f.has(e2)) return f.get(e2);
            const r2 = t.moduleRequire.m[e2].toString();
            return f.set(e2, r2), r2;
          }
          const g = /* @__PURE__ */ new Map();
          let m = null;
          function y(e2) {
            if (!e2) return false;
            const r2 = function() {
              var e3, r3;
              if (m) return m;
              try {
                m = (0, t.moduleRequire)("WAWebReact");
              } catch (e4) {
              }
              if (!m) try {
                m = null === (r3 = (e3 = self).require) || void 0 === r3 ? void 0 : r3.call(e3, "react");
              } catch (e4) {
              }
              return m;
            }(), n2 = [e2, e2.default, ..."object" == typeof e2 ? Object.values(e2) : []];
            for (const e3 of n2) if (e3) {
              if ("object" == typeof e3 && e3.$$typeof) return true;
              if (r2 && "function" == typeof e3 && e3.prototype && (r2.Component && e3.prototype instanceof r2.Component || r2.PureComponent && e3.prototype instanceof r2.PureComponent)) return true;
            }
            return false;
          }
          const v = /* @__PURE__ */ new Map(), b = /* @__PURE__ */ new Map();
          function h(e2, t2) {
            if (g.has(e2)) return g.get(e2);
            const r2 = y(t2);
            return g.set(e2, r2), r2;
          }
          function _(e2) {
            if (g.has(e2)) return g.get(e2);
            let r2 = false;
            if ("webpack" === t.loaderType) {
              const t2 = /\w+\.(Pure)?Component\s*\{/, n2 = p(e2);
              r2 = t2.test(n2);
            } else try {
              r2 = y((0, t.moduleRequire)(e2));
            } catch (e3) {
              r2 = false;
            }
            return g.set(e2, r2), r2;
          }
          let P = null, M = -1;
          function w(e2) {
            return e2.split(/(?=[A-Z])|[._-]/).map((e3) => e3.toLowerCase()).filter(Boolean);
          }
          function O(e2) {
            const r2 = Object.keys(t.moduleRequire.m);
            if (e2 instanceof RegExp) return r2.filter((t2) => e2.test(t2));
            const n2 = function() {
              const e3 = Object.keys(t.moduleRequire.m);
              if (P && e3.length === M) return P;
              const r3 = /* @__PURE__ */ new Map();
              for (const t2 of e3) for (const e4 of w(t2)) {
                let n3 = r3.get(e4);
                n3 || (n3 = [], r3.set(e4, n3)), n3.push(t2);
              }
              return P = r3, M = e3.length, r3;
            }(), o2 = w(e2);
            if (!o2.length) return [];
            let i2 = null;
            for (const e3 of o2) {
              const t2 = n2.get(e3);
              if (!t2) return [];
              if (i2) {
                const e4 = new Set(t2);
                if (i2 = i2.filter((t3) => e4.has(t3)), !i2.length) return [];
              } else i2 = t2.slice();
            }
            return i2 || [];
          }
          function j(e2, r2 = false, n2) {
            const o2 = v.get(e2);
            if (o2) return o2;
            if (null === o2 && b.get(e2) === Object.keys(t.moduleRequire.m).length) return null;
            const i2 = Object.keys(t.moduleRequire.m), a2 = r2 ? i2.slice().reverse() : i2;
            let u2;
            if (n2) {
              const e3 = O(n2);
              if (e3.length) {
                const t2 = new Set(e3);
                u2 = r2 ? e3.slice().reverse().concat(a2.filter((e4) => !t2.has(e4))) : e3.concat(a2.filter((e4) => !t2.has(e4)));
              } else u2 = a2;
            } else u2 = a2;
            const c2 = setTimeout(() => {
              s(`Searching for: ${e2.toString()}`);
            }, 500);
            for (const r3 of u2) if ("webpack" !== t.loaderType || !_(r3)) try {
              const n3 = (0, t.moduleRequire)(r3);
              if ("webpack" !== t.loaderType && h(r3, n3)) continue;
              if (e2(n3, r3)) return s(`Module found: ${r3} - ${e2.toString()}`), clearTimeout(c2), v.set(e2, r3), r3;
            } catch (e3) {
              continue;
            }
            const l2 = Object.keys(t.fallbackModules);
            for (const r3 of l2) try {
              const n3 = t.fallbackModules[r3];
              if (e2(n3, r3)) return s(`Fallback Module found: ${r3} - ${e2.toString()}`), clearTimeout(c2), v.set(e2, r3), r3;
            } catch (e3) {
              continue;
            }
            return clearTimeout(c2), s(`Module not found: ${e2.toString()}`), v.set(e2, null), b.set(e2, i2.length), null;
          }
          function S(e2) {
            return /^fallback_/.test(e2) ? t.fallbackModules[e2] : (0, t.moduleRequire)(e2);
          }
        }, 8686(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.create = async function(e2, t2) {
            var r2, i, a;
            let s;
            if (null == t2 ? void 0 : t2.picture) {
              const e3 = await (0, n.convertToFile)(t2.picture);
              s = await (0, n.blobToBase64)(e3), { data: s } = await (0, n.downloadImage)(s, "image/jpeg");
            }
            const u = await (0, o.createNewsletterQuery)({ name: e2, description: (null == t2 ? void 0 : t2.description) || null, picture: s || null });
            return { idJid: null == u ? void 0 : u.idJid, inviteCode: null == u ? void 0 : u.newsletterInviteLinkMetadataMixin.inviteCode, inviteLink: `https://whatsapp.com/channel/${null == u ? void 0 : u.newsletterInviteLinkMetadataMixin.inviteCode}`, name: null === (r2 = null == u ? void 0 : u.newsletterNameMetadataMixin) || void 0 === r2 ? void 0 : r2.nameElementValue, state: null === (i = null == u ? void 0 : u.newsletterStateMetadataMixin) || void 0 === i ? void 0 : i.stateType, subscribersCount: null == u ? void 0 : u.newsletterSubscribersMetadataMixin.subscribersCount, description: (null == t2 ? void 0 : t2.description) || null, timestamp: null === (a = null == u ? void 0 : u.newsletterCreationTimeMetadataMixin) || void 0 === a ? void 0 : a.creationTimeValue };
          };
          const n = r(62857), o = r(52757);
        }, 1158(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.destroy = async function(e2) {
            if (!e2 || !e2.includes("newsletter")) throw new n.WPPError("send_correctly_newsletter_id", "Please, send the correct newsletter ID.");
            try {
              return await (0, o.deleteNewsletter)(e2);
            } catch (e3) {
              return false;
            }
          };
          const n = r(62857), o = r(52757);
        }, 25578(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.edit = async function(e2, t2) {
            var r2, a, s, u, c;
            let l;
            if (null == t2 ? void 0 : t2.picture) {
              let e3 = t2.picture;
              t2.picture.includes("http") && ({ data: e3 } = await (0, n.downloadImage)(null == t2 ? void 0 : t2.picture, "image/jpeg"));
              const r3 = await (0, n.convertToFile)(e3), o2 = await (0, n.resizeImage)(r3, { width: 640, height: 640, mimeType: "image/jpeg", resize: "cover" });
              l = await (0, n.blobToBase64)(o2);
            }
            await (0, o.editNewsletterMetadataAction)(await (0, i.ensureNewsletter)(e2), { editDescription: !!t2.description, editName: !!t2.name, editPicture: !(!l && null != t2.picture) }, { name: t2.name, description: t2.description, picture: null == t2.picture ? null : l });
            const d = await (0, o.queryNewsletterMetadataByJid)(e2, { picture: true, description: true, name: true, state: true, creationTime: true });
            return { idJid: null == d ? void 0 : d.idJid, inviteCode: null == d ? void 0 : d.newsletterInviteLinkMetadataMixin.inviteCode, inviteLink: `https://whatsapp.com/channel/${null == d ? void 0 : d.newsletterInviteLinkMetadataMixin.inviteCode}`, name: null === (r2 = null == d ? void 0 : d.newsletterNameMetadataMixin) || void 0 === r2 ? void 0 : r2.nameElementValue, state: null === (a = null == d ? void 0 : d.newsletterStateMetadataMixin) || void 0 === a ? void 0 : a.stateType, subscribersCount: null == d ? void 0 : d.newsletterSubscribersMetadataMixin.subscribersCount, description: null === (u = null === (s = null == d ? void 0 : d.newsletterDescriptionMetadataMixin) || void 0 === s ? void 0 : s.descriptionQueryDescriptionResponseMixin) || void 0 === u ? void 0 : u.elementValue, timestamp: null === (c = null == d ? void 0 : d.newsletterCreationTimeMetadataMixin) || void 0 === c ? void 0 : c.creationTimeValue };
          };
          const n = r(62857), o = r(52757), i = r(16211);
        }, 16211(e, t, r) {
          "use strict";
          t.ensureNewsletter = async function(e2) {
            const t2 = (0, n.assertGetChat)(e2);
            if (!t2.isNewsletter) throw new o.WPPError("not_a_newsletter", `Chat ${t2.id._serialized} is not a newsletter`);
            return t2;
          };
          const n = r(41687), o = r(62857);
        }, 94523(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.follow = async function(e2) {
            if (!e2 || !e2.includes("@newsletter")) throw new n.WPPError("invalid_newsletter_id", "Please provide a valid newsletter ID (must contain @newsletter)");
            try {
              return await (0, o.mexJoinNewsletter)(e2), true;
            } catch (e3) {
              if (419 === e3.status) throw new n.WPPError("newsletter_follower_limit", "This newsletter has reached the follower limit. Please try again later.", { error: e3 });
              if (405 === e3.status) throw new n.WPPError("newsletter_closed", "This newsletter is closed to new followers. Try again later.", { error: e3 });
              if (451 === e3.status) throw new n.WPPError("newsletter_geosuspended", "This newsletter is not available in your country.", { error: e3 });
              throw new n.WPPError("newsletter_follow_failed", `Failed to follow newsletter: ${e3.message}`, { error: e3 });
            }
          };
          const n = r(62857), o = r(52757);
        }, 37069(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getSubscribers = async function(e2) {
            if (!e2 || !e2.includes("newsletter")) throw new n.WPPError("send_correctly_newsletter_id", "Please, send the correct newsletter ID.");
            try {
              return (await (0, o.getNewsletterSubscribers)(e2, 9, "LIMITED")).subscribers;
            } catch (e3) {
              return false;
            }
          };
          const n = r(62857), o = r(52757);
        }, 48812(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.unfollow = t.search = t.mute = t.getSubscribers = t.follow = t.edit = t.destroy = t.create = void 0;
          var n = r(8686);
          Object.defineProperty(t, "create", { enumerable: true, get: function() {
            return n.create;
          } });
          var o = r(1158);
          Object.defineProperty(t, "destroy", { enumerable: true, get: function() {
            return o.destroy;
          } });
          var i = r(25578);
          Object.defineProperty(t, "edit", { enumerable: true, get: function() {
            return i.edit;
          } });
          var a = r(94523);
          Object.defineProperty(t, "follow", { enumerable: true, get: function() {
            return a.follow;
          } });
          var s = r(37069);
          Object.defineProperty(t, "getSubscribers", { enumerable: true, get: function() {
            return s.getSubscribers;
          } });
          var u = r(7071);
          Object.defineProperty(t, "mute", { enumerable: true, get: function() {
            return u.mute;
          } });
          var c = r(80614);
          Object.defineProperty(t, "search", { enumerable: true, get: function() {
            return c.search;
          } });
          var l = r(17956);
          Object.defineProperty(t, "unfollow", { enumerable: true, get: function() {
            return l.unfollow;
          } });
        }, 7071(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.mute = async function(e2, t2) {
            var r2;
            const u = await (0, s.ensureNewsletter)(e2);
            if (null != t2 && "boolean" != typeof t2) throw new n.WPPError("invalid_mute_value", "Mute value must be boolean");
            const c = null !== (r2 = null === i.CHANNEL_EVENT_SURFACE || void 0 === i.CHANNEL_EVENT_SURFACE ? void 0 : i.CHANNEL_EVENT_SURFACE.CHANNEL_UPDATES_HOME) && void 0 !== r2 ? r2 : 1, l = false === t2 ? 0 : -1;
            a.toggleNewsletterAdminActivityMuteStateAction ? await (0, a.toggleNewsletterAdminActivityMuteStateAction)(u.id, l, { eventSurface: c }) : false === t2 ? await (0, a.unmuteNewsletter)([e2]) : await (0, a.muteNewsletter)([e2]);
            return o.NewsletterStore.get(e2);
          };
          const n = r(62857), o = r(14647), i = r(20514), a = r(52757), s = r(16211);
        }, 80614(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.search = async function(e2, t2) {
            if (!e2 || 0 === e2.trim().length) throw new n.WPPError("invalid_search_query", "Search query cannot be empty");
            try {
              const r2 = { searchText: e2.trim(), categories: (null == t2 ? void 0 : t2.categories) || [], limit: (null == t2 ? void 0 : t2.limit) || 20, cursorToken: null == t2 ? void 0 : t2.cursorToken }, n2 = await (0, o.mexFetchNewsletterDirectorySearchResults)(r2), i = null == n2 ? void 0 : n2.xwa2_newsletters_directory_search, a = (null == i ? void 0 : i.result) || [], s = null == i ? void 0 : i.page_info;
              return { newsletters: a.map((e3) => {
                var t3, r3, n3;
                const o2 = e3.thread_metadata || {};
                let i2 = 0;
                if (o2.subscribers_count) {
                  const e4 = parseInt(o2.subscribers_count, 10);
                  i2 = isNaN(e4) ? 0 : e4;
                }
                let a2 = 0;
                if (o2.creation_time) {
                  const e4 = parseInt(o2.creation_time, 10);
                  a2 = isNaN(e4) ? 0 : e4;
                }
                return { idJid: e3.idJid || e3.id || "", name: (null === (t3 = o2.name) || void 0 === t3 ? void 0 : t3.text) || e3.name || "", description: (null === (r3 = o2.description) || void 0 === r3 ? void 0 : r3.text) || e3.description || "", picture: (null === (n3 = o2.picture) || void 0 === n3 ? void 0 : n3.direct_path) || o2.picture || "", subscribersCount: i2, verification: o2.verification || "", handle: o2.handle || null, inviteCode: o2.invite || "", creationTime: a2, _raw: e3 };
              }), pageInfo: s ? { hasNextPage: s.has_next_page, endCursor: s.end_cursor } : void 0 };
            } catch (e3) {
              throw new n.WPPError("newsletter_search_failed", `Failed to search newsletters: ${e3.message}`, { error: e3 });
            }
          };
          const n = r(62857), o = r(52757);
        }, 17956(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.unfollow = async function(e2) {
            if (!e2 || !e2.includes("@newsletter")) throw new n.WPPError("invalid_newsletter_id", "Please provide a valid newsletter ID (must contain @newsletter)");
            try {
              return await (0, o.mexLeaveNewsletter)(e2), true;
            } catch (e3) {
              if (400 === e3.status) return true;
              throw new n.WPPError("newsletter_unfollow_failed", `Failed to unfollow newsletter: ${e3.message}`, { error: e3 });
            }
          };
          const n = r(62857), o = r(52757);
        }, 74310(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(48812), t);
        }, 3421(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), r(55497);
        }, 55497(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(() => {
            c.MsgStore.on("add", (e2) => {
              var t2, r2, n2, o2, i2, a2;
              if ("interactive" !== e2.type || "payment_method" !== (null === (n2 = null === (r2 = null === (t2 = e2.interactivePayload) || void 0 === t2 ? void 0 : t2.buttons) || void 0 === r2 ? void 0 : r2[0]) || void 0 === n2 ? void 0 : n2.name) || !e2.isNewMsg) return;
              const u2 = JSON.parse(null === (a2 = null === (i2 = null === (o2 = e2.interactivePayload) || void 0 === o2 ? void 0 : o2.buttons) || void 0 === i2 ? void 0 : i2[0]) || void 0 === a2 ? void 0 : a2.buttonParamsJson);
              queueMicrotask(() => {
                s.internalEv.emit("order.payment_status", { method: u2.payment_method, timestamp: u2.payment_timestamp, reference_id: u2.reference_id, msgId: e2.id });
              });
            });
          });
        }, 80369(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.accept = async function(e2) {
            const { msgId: t2 } = e2, r2 = i.MsgStore.get(t2);
            if (!r2) throw new o.WPPError("msg_not_found", "Message not found");
            if (r2.type !== a.MSG_TYPE.ORDER) throw new o.WPPError("msg_not_order", "Message is not an order");
            if (!r2.orderId || !r2.token) throw new o.WPPError("invalid_order_message", "Message is missing orderId or token");
            const c = r2.chat, l = r2.sellerJid || r2.to;
            if (!c || !l) throw new o.WPPError("invalid_order_message", "Message does not contain valid order information");
            const d = await (0, s.queryOrder)(r2.orderId, 80, 80, r2.token), f = { items: d.products.map((e3) => ({ id: e3.id.toString(), name: e3.name, amount: e3.price || 0, quantity: e3.quantity || 1, isCustomItem: false, isQuantitySet: true })), totalAmount: d.total || 0, subtotal: d.subtotal || 0, tax: d.tax || void 0, currency: d.currency, referenceId: r2.orderId };
            (0, s.updateMessageTable)(r2.id, { status: u.OrderMessageStatus.ACCEPTED }), r2.set({ status: u.OrderMessageStatus.ACCEPTED });
            const p = { reference_id: r2.orderId, type: "physical-goods", payment_configuration: "merchant_categorization_code", currency: d.currency, total_amount: { value: f.totalAmount, offset: 1e3 }, order_type: "ORDER", order: { status: "payment_requested", items: f.items.map((e3) => ({ retailer_id: e3.id, name: e3.name, amount: { value: e3.amount, offset: 1e3 }, quantity: e3.quantity, isCustomItem: e3.isCustomItem || false, isQuantitySet: e3.isQuantitySet || true })), subtotal: { value: f.subtotal, offset: 1e3 }, tax: f.tax ? { value: f.tax, offset: 1e3 } : null } }, g = { type: "interactive", nativeFlowName: "order_details", interactiveType: "native_flow", interactiveHeader: { hasmediaAttachment: false, mediaType: void 0, subtitle: void 0, thumbnail: r2.thumbnail, title: null }, interactivePayload: { buttons: [{ buttonParamsJson: JSON.stringify(p), name: "review_and_pay" }], messageVersion: 1 } };
            await (0, n.sendRawMessage)(c.id, g, { quotedMsg: r2 });
          };
          const n = r(97829), o = r(62857), i = r(14647), a = r(20514), s = r(52757), u = r(60738);
        }, 21747(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.decline = async function(e2) {
            const { msgId: t2, declineNote: r2 } = e2, c = i.MsgStore.get(t2);
            if (!c) throw new o.WPPError("msg_not_found", "Message not found");
            if (c.type !== a.MSG_TYPE.ORDER) throw new o.WPPError("msg_not_order", "Message is not an order");
            if (!c.orderId || !c.token) throw new o.WPPError("invalid_order_message", "Message is missing orderId or token");
            const l = c.chat, d = c.sellerJid || c.to;
            if (!l || !d) throw new o.WPPError("invalid_order_message", "Message does not contain valid order information");
            const f = await (0, s.queryOrder)(c.orderId, 80, 80, c.token), p = { items: f.products.map((e3) => ({ id: e3.id.toString(), name: e3.name, amount: e3.price || 0, quantity: e3.quantity || 1, isCustomItem: false, isQuantitySet: true })), totalAmount: f.total || 0, subtotal: f.subtotal || 0, tax: f.tax || void 0, currency: f.currency, referenceId: c.orderId }, g = c.msgContextInfo(l.id);
            (0, s.updateMessageTable)(c.id, { status: u.OrderMessageStatus.DECLINED }), c.set({ status: u.OrderMessageStatus.DECLINED }), await (0, s.sendOrderStatusMessageAsMerchant)({ chat: l, sellerJid: d, orderInfo: p, orderNote: r2, orderStatus: u.OrderStatus.Canceled, offset: 2, paymentStatus: u.PaymentStatus.Pending, paymentMethod: void 0, contextInfo: g });
            const m = { reference_id: c.orderId, type: "physical-goods", payment_configuration: "merchant_categorization_code", currency: f.currency, total_amount: { value: p.totalAmount, offset: 1e3 }, order_type: "ORDER", order: { status: "canceled", items: p.items.map((e3) => ({ retailer_id: e3.id, name: e3.name, amount: { value: e3.amount, offset: 1e3 }, quantity: e3.quantity, isCustomItem: e3.isCustomItem || false, isQuantitySet: e3.isQuantitySet || true })), subtotal: { value: p.subtotal, offset: 1e3 }, tax: p.tax ? { value: p.tax, offset: 1e3 } : null } }, y = { type: "interactive", nativeFlowName: "order_details", interactiveType: "native_flow", interactiveHeader: { hasmediaAttachment: false, mediaType: void 0, subtitle: void 0, thumbnail: c.thumbnail, title: null }, interactivePayload: { buttons: [{ buttonParamsJson: JSON.stringify(m), name: "review_and_pay" }], messageVersion: 1 } };
            await (0, n.sendRawMessage)(l.id, y, { quotedMsg: c });
          };
          const n = r(97829), o = r(62857), i = r(14647), a = r(20514), s = r(52757), u = r(60738);
        }, 34949(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.get = async function(e2) {
            const t2 = o.MsgStore.get(e2);
            if (!t2) throw new n.WPPError("msg_not_found", "Message not found");
            if (t2.type === i.MSG_TYPE.ORDER) {
              const e3 = await (0, a.queryOrder)(t2.orderId, 80, 80, t2.token);
              return new o.OrderModel({ id: t2.orderId, products: e3.products, itemCount: e3.products.length, subtotal: e3.subtotal, tax: e3.tax, total: e3.total, currency: e3.currency, createdAt: e3.createdAt, sellerJid: t2.sellerJid });
            }
            throw new n.WPPError("msg_not_is_a_order", "Message not is a order");
          };
          const n = r(62857), o = r(14647), i = r(20514), a = r(52757);
        }, 18165(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.update = t.get = t.decline = t.accept = void 0;
          var n = r(80369);
          Object.defineProperty(t, "accept", { enumerable: true, get: function() {
            return n.accept;
          } });
          var o = r(21747);
          Object.defineProperty(t, "decline", { enumerable: true, get: function() {
            return o.decline;
          } });
          var i = r(34949);
          Object.defineProperty(t, "get", { enumerable: true, get: function() {
            return i.get;
          } });
          var a = r(31728);
          Object.defineProperty(t, "update", { enumerable: true, get: function() {
            return a.update;
          } });
        }, 31728(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.update = async function(e2) {
            const { msgId: t2, orderStatus: r2, orderNote: u, offset: c = 2, referenceId: l, paymentStatus: d = s.PaymentStatus.Pending, paymentMethod: f } = e2, p = o.MsgStore.get(t2);
            if (!p) throw new n.WPPError("msg_not_found", "Message not found");
            if (p.type !== i.MSG_TYPE.ORDER) throw new n.WPPError("msg_not_order", "Message is not an order");
            if (p.status !== s.OrderMessageStatus.ACCEPTED && p.status !== s.OrderMessageStatus.DECLINED) throw new n.WPPError("order_not_processed", "Order must be accepted or declined before updating. Use accept() or decline() first.");
            const g = p.chat, m = p.sellerJid || p.to;
            if (!g || !m) throw new n.WPPError("invalid_order_message", "Message does not contain valid order information");
            const y = await (0, a.queryOrder)(p.orderId, 80, 80, p.token), v = { items: y.products.map((e3) => ({ id: e3.id.toString(), name: e3.name, amount: e3.price || 0, quantity: e3.quantity || 1, isCustomItem: false, isQuantitySet: true })), totalAmount: y.total || 0, subtotal: y.subtotal || 0, tax: y.tax || void 0, currency: y.currency, referenceId: l || p.orderId }, b = p.msgContextInfo(g.id);
            await (0, a.sendOrderStatusMessageAsMerchant)({ chat: g, sellerJid: m, orderInfo: v, orderNote: u, orderStatus: r2, offset: c, paymentStatus: d, paymentMethod: f, contextInfo: b });
          };
          const n = r(62857), o = r(14647), i = r(20514), a = r(52757), s = r(60738);
        }, 37783(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(3421), t), o(r(18165), t), o(r(60738), t);
        }, 60738(e, t) {
          "use strict";
          var r, n, o;
          Object.defineProperty(t, "__esModule", { value: true }), t.OrderMessageStatus = t.PaymentStatus = t.OrderStatus = void 0, function(e2) {
            e2.Pending = "pending", e2.Processing = "processing", e2.PartiallyShipped = "partially_shipped", e2.Shipped = "shipped", e2.Complete = "completed", e2.Canceled = "canceled", e2.PaymentRequested = "payment_requested", e2.PreparingToShip = "preparing_to_ship", e2.Delivered = "delivered", e2.Confirmed = "confirmed", e2.Delayed = "delayed", e2.Failed = "failed", e2.OutForDelivery = "out_for_delivery", e2.Refunded = "refunded";
          }(r || (t.OrderStatus = r = {})), function(e2) {
            e2.Pending = "pending", e2.Captured = "captured", e2.Failed = "failed", e2.Canceled = "canceled";
          }(n || (t.PaymentStatus = n = {})), function(e2) {
            e2[e2.INQUIRY = 1] = "INQUIRY", e2[e2.ACCEPTED = 2] = "ACCEPTED", e2[e2.DECLINED = 3] = "DECLINED";
          }(o || (t.OrderMessageStatus = o = {}));
        }, 95629(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.get = async function() {
            return Object.assign(Object.assign({}, (0, n.getUserPrivacySettings)()), { status: await (0, n.getStatusPrivacySetting)() });
          };
          const n = r(52757);
        }, 73865(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getDisallowedList = async function(e2) {
            if ("string" != typeof e2 || !Object.values(n.PrivacyDisallowedListType).includes(e2)) throw new o.WPPError("incorrect_type", `Incorrect type ${e2 || "<empty>"} for get disalowed list`, { type: e2 });
            const t2 = await (0, i.getPrivacyDisallowedListTable)().get(e2);
            return t2 ? t2.disallowedList : null;
          };
          const n = r(83734), o = r(62857), i = r(52757);
        }, 85837(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setStatus = t.setReadReceipts = t.setProfilePic = t.setOnline = t.setLastSeen = t.setAddGroup = t.setAbout = t.getDisallowedList = t.get = void 0;
          var n = r(95629);
          Object.defineProperty(t, "get", { enumerable: true, get: function() {
            return n.get;
          } });
          var o = r(73865);
          Object.defineProperty(t, "getDisallowedList", { enumerable: true, get: function() {
            return o.getDisallowedList;
          } });
          var i = r(99804);
          Object.defineProperty(t, "setAbout", { enumerable: true, get: function() {
            return i.setAbout;
          } });
          var a = r(26947);
          Object.defineProperty(t, "setAddGroup", { enumerable: true, get: function() {
            return a.setAddGroup;
          } });
          var s = r(56414);
          Object.defineProperty(t, "setLastSeen", { enumerable: true, get: function() {
            return s.setLastSeen;
          } });
          var u = r(41898);
          Object.defineProperty(t, "setOnline", { enumerable: true, get: function() {
            return u.setOnline;
          } });
          var c = r(84474);
          Object.defineProperty(t, "setProfilePic", { enumerable: true, get: function() {
            return c.setProfilePic;
          } });
          var l = r(81096);
          Object.defineProperty(t, "setReadReceipts", { enumerable: true, get: function() {
            return l.setReadReceipts;
          } });
          var d = r(85019);
          Object.defineProperty(t, "setStatus", { enumerable: true, get: function() {
            return d.setStatus;
          } });
        }, 77602(e, t, r) {
          "use strict";
          t.prepareDisallowedList = async function(e2, t2, r2) {
            if ("contact_blacklist" !== t2) return { ids: [], dhash: null, idsFormatted: [], allUsers: [] };
            if ("string" != typeof e2 || !Object.values(n.PrivacyDisallowedListType).includes(e2)) throw new o.WPPError("incorrect_type", `Incorrect type ${e2 || "<empty>"} for get disalowed list`, { type: e2 });
            const s = await (0, a.getPrivacyDisallowedListTable)().get(e2);
            if (!r2 || 0 === (null == r2 ? void 0 : r2.length)) {
              if (!s) throw new o.WPPError("disallowed_list_is_mandatory", "Disallowed list is empty, please send disallowed list param");
              return { ids: s.disallowedList.map((e3) => new i.Wid(e3, { intentionallyUsePrivateConstructor: true })), dhash: s.dhash, idsFormatted: [], allUsers: s.disallowedList.map((e3) => new i.Wid(e3, { intentionallyUsePrivateConstructor: true })) };
            }
            if (null == s) return { ids: (r2 = null == r2 ? void 0 : r2.filter((e3) => "remove" !== e3.action)).map((e3) => new i.Wid(e3.id, { intentionallyUsePrivateConstructor: true })), dhash: null, idsFormatted: r2.map((e3) => ({ wid: new i.Wid(e3.id, { intentionallyUsePrivateConstructor: true }), action: "add" })), allUsers: r2.map((e3) => new i.Wid(e3.id, { intentionallyUsePrivateConstructor: true })) };
            const u = s.disallowedList.filter((e3) => !r2.some((t3) => "remove" === t3.action && t3.id === e3)), c = r2.filter((e3) => "remove" !== e3.action), l = [].concat(c.map((e3) => new i.Wid(e3.id, { intentionallyUsePrivateConstructor: true })), u.map((e3) => new i.Wid(e3, { intentionallyUsePrivateConstructor: true })));
            return { ids: r2.map((e3) => new i.Wid(e3.id, { intentionallyUsePrivateConstructor: true })), dhash: s.dhash, idsFormatted: r2.map((e3) => ({ wid: new i.Wid(e3.id, { intentionallyUsePrivateConstructor: true }), action: e3.action })), allUsers: l };
          };
          const n = r(83734), o = r(62857), i = r(14647), a = r(52757);
        }, 99804(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setAboutTypes = void 0, t.setAbout = async function(e2, t2) {
            if ("string" != typeof e2 || !Object.values(s).includes(e2)) throw new o.WPPError("incorrect_type", `Incorrect type ${e2 || "<empty>"} for set about privacy`, { value: e2 });
            const r2 = await (0, a.prepareDisallowedList)(n.PrivacyDisallowedListType.About, e2, t2);
            return await (0, i.setPrivacyForOneCategory)({ name: n.PrivacyDisallowedListType.About, value: e2, dhash: "contact_blacklist" === e2 ? r2.dhash : null, users: "contact_blacklist" === e2 ? r2.idsFormatted : void 0 }, "contact_blacklist" === e2 ? r2.allUsers : void 0), (0, i.getUserPrivacySettings)().about;
          };
          const n = r(83734), o = r(62857), i = r(52757), a = r(77602);
          var s;
          !function(e2) {
            e2.all = "all", e2.contacts = "contacts", e2.none = "none", e2.contact_blacklist = "contact_blacklist";
          }(s || (t.setAboutTypes = s = {}));
        }, 26947(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setAddGroupTypes = void 0, t.setAddGroup = async function(e2, t2) {
            if ("string" != typeof e2 || !Object.values(s).includes(e2)) throw new o.WPPError("incorrect_type", `Incorrect type ${e2 || "<empty>"} for set add group privacy`, { value: e2 });
            const r2 = await (0, a.prepareDisallowedList)(n.PrivacyDisallowedListType.GroupAdd, e2, t2);
            return await (0, i.setPrivacyForOneCategory)({ name: n.PrivacyDisallowedListType.GroupAdd, value: e2, dhash: "contact_blacklist" === e2 ? r2.dhash : null, users: "contact_blacklist" === e2 ? r2.idsFormatted : void 0 }, "contact_blacklist" === e2 ? r2.allUsers : void 0), (0, i.getUserPrivacySettings)().groupAdd;
          };
          const n = r(83734), o = r(62857), i = r(52757), a = r(77602);
          var s;
          !function(e2) {
            e2.all = "all", e2.contacts = "contacts", e2.contact_blacklist = "contact_blacklist";
          }(s || (t.setAddGroupTypes = s = {}));
        }, 56414(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setLastSeenTypes = void 0, t.setLastSeen = async function(e2, t2) {
            if ("string" != typeof e2 || !Object.values(s).includes(e2)) throw new o.WPPError("incorrect_type", `Incorrect type ${e2 || "<empty>"} for set last seen privacy`, { value: e2 });
            const r2 = await (0, a.prepareDisallowedList)(n.PrivacyDisallowedListType.LastSeen, e2, t2);
            return await (0, i.setPrivacyForOneCategory)({ name: "last", value: e2, dhash: "contact_blacklist" === e2 ? r2.dhash : null, users: "contact_blacklist" === e2 ? r2.idsFormatted : void 0 }, "contact_blacklist" === e2 ? r2.allUsers : void 0), (0, i.getUserPrivacySettings)().lastSeen;
          };
          const n = r(83734), o = r(62857), i = r(52757), a = r(77602);
          var s;
          !function(e2) {
            e2.all = "all", e2.contacts = "contacts", e2.none = "none", e2.contact_blacklist = "contact_blacklist";
          }(s || (t.setLastSeenTypes = s = {}));
        }, 41898(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setOnlineTypes = void 0, t.setOnline = async function(e2) {
            if ("string" != typeof e2 || !Object.values(i).includes(e2)) throw new n.WPPError("incorrect_type", `Incorrect type ${e2 || "<empty>"} for set online privacy`, { value: e2 });
            return await (0, o.setPrivacyForOneCategory)({ name: "online", value: e2 }), (0, o.getUserPrivacySettings)().online;
          };
          const n = r(62857), o = r(52757);
          var i;
          !function(e2) {
            e2.all = "all", e2.match_last_seen = "match_last_seen";
          }(i || (t.setOnlineTypes = i = {}));
        }, 84474(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setProfilePicTypes = void 0, t.setProfilePic = async function(e2, t2) {
            if ("string" != typeof e2 || !Object.values(s).includes(e2)) throw new o.WPPError("incorrect_type", `Incorrect type ${e2 || "<empty>"} for set profile pic privacy`, { value: e2 });
            const r2 = await (0, a.prepareDisallowedList)(n.PrivacyDisallowedListType.ProfilePicture, e2, t2);
            return await (0, i.setPrivacyForOneCategory)({ name: n.PrivacyDisallowedListType.ProfilePicture, value: e2, dhash: "contact_blacklist" === e2 ? r2.dhash : null, users: "contact_blacklist" === e2 ? r2.idsFormatted : void 0 }, "contact_blacklist" === e2 ? r2.allUsers : void 0), (0, i.getUserPrivacySettings)().profilePicture;
          };
          const n = r(83734), o = r(62857), i = r(52757), a = r(77602);
          var s;
          !function(e2) {
            e2.all = "all", e2.contacts = "contacts", e2.none = "none", e2.contact_blacklist = "contact_blacklist";
          }(s || (t.setProfilePicTypes = s = {}));
        }, 81096(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setReadReceiptsTypes = void 0, t.setReadReceipts = async function(e2) {
            if ("string" != typeof e2 || !Object.values(i).includes(e2)) throw new n.WPPError("incorrect_type", `Incorrect type ${e2 || "<empty>"} for set read receipts privacy`, { value: e2 });
            return await (0, o.setPrivacyForOneCategory)({ name: "readreceipts", value: e2 }), (0, o.getUserPrivacySettings)().readReceipts;
          };
          const n = r(62857), o = r(52757);
          var i;
          !function(e2) {
            e2.all = "all", e2.none = "none";
          }(i || (t.setReadReceiptsTypes = i = {}));
        }, 85019(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setStatusTypes = void 0, t.setStatus = async function(e2, t2) {
            if ("string" != typeof e2 || !Object.values(a).includes(e2)) throw new o.WPPError("incorrect_type", `Incorrect type ${e2 || "<empty>"} for set about privacy`, { value: e2 });
            if ((e2 == a.ALLOW_LIST || e2 == a.DENY_LIST) && !t2) throw new o.WPPError("list_is_mandatory", "List is empty <empty>, send the list to allow or deny");
            if (t2) {
              Array.isArray(t2) || (t2 = [t2]);
              const r2 = t2.map(n.assertWid);
              await (0, i.setStatusPrivacyConfig)({ setting: e2, list: r2 });
            } else await (0, i.setStatusPrivacyConfig)({ setting: e2, list: [] });
            return (0, i.getStatusPrivacySetting)();
          };
          const n = r(41687), o = r(62857), i = r(52757);
          var a;
          !function(e2) {
            e2.contact = "contact", e2.DENY_LIST = "deny-list", e2.ALLOW_LIST = "allow-list";
          }(a || (t.setStatusTypes = a = {}));
        }, 33599(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(85837), t);
        }, 40923(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.editBusinessProfile = async function(e2) {
            if (!i.Conn.isSMB) throw new o.WPPError("NOT_BUSINESS_PROFILE", "Not a business profile");
            e2.website && Array.isArray(e2.website) && (e2.website = e2.website.map((e3) => ({ url: e3 })));
            await (0, a.editBusinessProfile)(e2);
            const t2 = (0, n.getMyUserWid)();
            return await i.BusinessProfileStore.fetchBizProfile(t2);
          };
          const n = r(21942), o = r(62857), i = r(14647), a = r(52757);
        }, 42670(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMyProfileName = function() {
            return n.functions.getPushname();
          };
          const n = r(14647);
        }, 82807(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMyProfilePicture = async function() {
            const e2 = (0, n.getMyUserWid)();
            return await o.ProfilePicThumbStore.find(e2);
          };
          const n = r(21942), o = r(14647);
        }, 29116(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMyStatus = async function() {
            return (await o.StatusStore.find((0, n.getMyUserWid)())).status;
          };
          const n = r(21942), o = r(14647);
        }, 23144(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setMyStatus = t.setMyProfilePicture = t.setMyProfileName = t.removeMyProfilePicture = t.isBusiness = t.getMyStatus = t.getMyProfilePicture = t.getMyProfileName = t.editBusinessProfile = void 0;
          var n = r(40923);
          Object.defineProperty(t, "editBusinessProfile", { enumerable: true, get: function() {
            return n.editBusinessProfile;
          } });
          var o = r(42670);
          Object.defineProperty(t, "getMyProfileName", { enumerable: true, get: function() {
            return o.getMyProfileName;
          } });
          var i = r(82807);
          Object.defineProperty(t, "getMyProfilePicture", { enumerable: true, get: function() {
            return i.getMyProfilePicture;
          } });
          var a = r(29116);
          Object.defineProperty(t, "getMyStatus", { enumerable: true, get: function() {
            return a.getMyStatus;
          } });
          var s = r(17616);
          Object.defineProperty(t, "isBusiness", { enumerable: true, get: function() {
            return s.isBusiness;
          } });
          var u = r(95333);
          Object.defineProperty(t, "removeMyProfilePicture", { enumerable: true, get: function() {
            return u.removeMyProfilePicture;
          } });
          var c = r(35098);
          Object.defineProperty(t, "setMyProfileName", { enumerable: true, get: function() {
            return c.setMyProfileName;
          } });
          var l = r(20059);
          Object.defineProperty(t, "setMyProfilePicture", { enumerable: true, get: function() {
            return l.setMyProfilePicture;
          } });
          var d = r(48736);
          Object.defineProperty(t, "setMyStatus", { enumerable: true, get: function() {
            return d.setMyStatus;
          } });
        }, 17616(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.isBusiness = function() {
            return n.Conn.isSMB;
          };
          const n = r(14647);
        }, 95333(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.removeMyProfilePicture = async function() {
            return 200 === (await o.functions.requestDeletePicture((0, n.getMyUserWid)())).status;
          };
          const n = r(21942), o = r(14647);
        }, 35098(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setMyProfileName = async function(e2) {
            return await n.functions.setPushname(e2), true;
          };
          const n = r(14647);
        }, 20059(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.setMyProfilePicture = async function(e2) {
            const t2 = await (0, o.convertToFile)(e2), r2 = await (0, o.resizeImage)(t2, { width: 96, height: 96, mimeType: "image/jpeg", resize: "cover" }), a = await (0, o.resizeImage)(t2, { width: 640, height: 640, mimeType: "image/jpeg", resize: "cover" }), s = await (0, o.blobToBase64)(r2), u = await (0, o.blobToBase64)(a);
            return (0, i.sendSetPicture)((0, n.getMyUserWid)(), s, u);
          };
          const n = r(21942), o = r(62857), i = r(52757);
        }, 48736(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.setMyStatus = async function(e2) {
            await c.setMyStatus(e2);
            const t2 = await u.StatusStore.find((0, s.getMyUserWid)());
            t2 && (t2.status = e2);
            return true;
          };
          const s = r(21942), u = r(14647), c = a(r(52757));
        }, 5882(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(23144), t);
        }, 47494(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.defaultSendStatusOptions = void 0, t.defaultSendStatusOptions = { waitForAck: true };
        }, 4213(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), r(9364);
        }, 9364(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(13691), u = a(r(7222)), c = r(14647);
          u.onInjected(() => {
            c.StatusV3Store.on("sync", () => {
              s.internalEv.emit("status.sync");
            });
          });
        }, 16973(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.get = function(e2) {
            const t2 = (0, n.assertWid)(e2);
            return o.StatusV3Store.get(t2);
          };
          const n = r(41687), o = r(14647);
        }, 93809(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.getMyStatus = async function() {
            let e2 = o.StatusV3Store.getMyStatus();
            e2 || (e2 = await o.StatusV3Store.find((0, n.getMyUserWid)()));
            return e2;
          };
          const n = r(21942), o = r(14647);
        }, 99341(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.updateParticipants = t.sendVideoStatus = t.sendTextStatus = t.sendReadStatus = t.sendRawStatus = t.sendImageStatus = t.remove = t.getMyStatus = t.get = void 0;
          var n = r(16973);
          Object.defineProperty(t, "get", { enumerable: true, get: function() {
            return n.get;
          } });
          var o = r(93809);
          Object.defineProperty(t, "getMyStatus", { enumerable: true, get: function() {
            return o.getMyStatus;
          } });
          var i = r(68249);
          Object.defineProperty(t, "remove", { enumerable: true, get: function() {
            return i.remove;
          } });
          var a = r(2700);
          Object.defineProperty(t, "sendImageStatus", { enumerable: true, get: function() {
            return a.sendImageStatus;
          } });
          var s = r(71459);
          Object.defineProperty(t, "sendRawStatus", { enumerable: true, get: function() {
            return s.sendRawStatus;
          } });
          var u = r(34809);
          Object.defineProperty(t, "sendReadStatus", { enumerable: true, get: function() {
            return u.sendReadStatus;
          } });
          var c = r(72686);
          Object.defineProperty(t, "sendTextStatus", { enumerable: true, get: function() {
            return c.sendTextStatus;
          } });
          var l = r(53390);
          Object.defineProperty(t, "sendVideoStatus", { enumerable: true, get: function() {
            return l.sendVideoStatus;
          } });
          var d = r(45218);
          Object.defineProperty(t, "updateParticipants", { enumerable: true, get: function() {
            return d.updateParticipants;
          } });
        }, 28227(e, t, r) {
          "use strict";
          var n = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.postSendStatus = function(e2) {
            try {
              const t2 = i.MsgStore.get(e2.id);
              if (!t2) return;
              i.StatusV3Store.addStatusMessages(t2.author, [t2]), i.StatusV3Store.handleUpdate(t2.attributes, null, false);
              const r2 = i.StatusV3Store.getMyStatus();
              r2 && r2.msgs.add(t2);
            } catch (t2) {
              a("failed to update the status stores for %s: %o", e2.id, t2);
            }
          };
          const o = n(r(17833)), i = r(14647), a = (0, o.default)("WA-JS:status");
        }, 68249(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.remove = async function(e2) {
            const t2 = await (0, n.getMessageById)(e2);
            try {
              return await (0, a.revokeStatus)(i.StatusV3Store.get(i.UserPrefs.getMaybeMePnUser()), t2), true;
            } catch (t3) {
              throw new o.WPPError("error_on_remove_status", `Error on remove status with id ${e2.toString()}`);
            }
          };
          const n = r(74023), o = r(62857), i = r(14647), a = r(52757);
        }, 2700(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendImageStatus = async function(e2, t2 = {}) {
            const r2 = (0, i.getMyUserWid)(), c = new a.MsgKey({ fromMe: true, id: (0, s.randomHex)(16), participant: r2, remote: (0, n.assertWid)("status@broadcast") });
            t2 = Object.assign(Object.assign(Object.assign({}, u.defaultSendStatusOptions), { messageId: c }), t2);
            return await (0, o.sendFileMessage)("status@broadcast", e2, Object.assign(Object.assign({}, t2), { type: "image" }));
          };
          const n = r(41687), o = r(74023), i = r(21942), a = r(14647), s = r(52757), u = r(31167);
        }, 71459(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.sendRawStatus = async function(e2, t2 = {}) {
            const r2 = (0, c.getMyUserWid)(), n2 = new d.MsgKey({ fromMe: true, id: (0, p.randomHex)(16), participant: r2, remote: (0, s.assertWid)("status@broadcast") });
            t2 = Object.assign(Object.assign(Object.assign({}, g.defaultSendStatusOptions), { messageId: n2 }), t2), e2.author = r2;
            const o2 = await u.sendRawMessage("status@broadcast", e2, Object.assign({}, t2));
            return (0, m.postSendStatus)(o2), o2;
          };
          const s = r(41687), u = a(r(74023)), c = r(21942), l = a(r(7222)), d = r(14647), f = r(54993), p = r(52757), g = r(31167), m = r(28227);
          l.onInjected(() => {
            (0, f.wrapModuleFunction)(p.createMsgProtobuf, (e2, ...t2) => {
              const [r2] = t2, n2 = e2(...t2);
              return n2.extendedTextMessage && ("number" == typeof r2.backgroundColor && (n2.extendedTextMessage.backgroundArgb = r2.backgroundColor), "number" == typeof r2.textColor && (n2.extendedTextMessage.textArgb = r2.textColor), "number" == typeof r2.font && (n2.extendedTextMessage.font = r2.font), n2.extendedTextMessage.inviteLinkGroupTypeV2 = 0, n2.extendedTextMessage.previewType = 0), n2;
            }), (0, f.wrapModuleFunction)(p.encryptAndSendMsg, async (e2, ...t2) => {
              var r2;
              const [n2, o2] = t2;
              if ("status@broadcast" == (null === (r2 = n2.data.to) || void 0 === r2 ? void 0 : r2.toString())) {
                const e3 = (0, p.createMsgProtobuf)(n2.data);
                try {
                  return await (0, p.encryptAndSendStatusMsg)(n2, e3, o2), { t: n2.data.t, sync: null, phash: null, addressingMode: null, count: null, error: null };
                } catch (e4) {
                  return null;
                }
              }
              return await e2(...t2);
            });
          }), l.onFullReady(() => {
            (0, f.wrapModuleFunction)(p.getABPropConfigValue, (e2, ...t2) => {
              const [r2] = t2;
              switch (r2) {
                case "web_status_posting_enabled":
                case "post_status_in_companion":
                  return 1;
              }
              return e2(...t2);
            }), (0, f.wrapModuleFunction)(p.primaryFeatureEnabled, (e2, ...t2) => {
              const [r2] = t2;
              switch (r2) {
                case "post_status_in_companion":
                case "text_status_creation_support":
                  return true;
              }
              return e2(...t2);
            });
          });
        }, 34809(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendReadStatus = async function(e2, t2) {
            var r2;
            const i = (0, n.assertWid)(e2), a = o.StatusV3Store.get(i), s = null == a ? void 0 : a.msgs.get(t2);
            await (null == a ? void 0 : a.sendReadStatus(s, null == s ? void 0 : s.mediaKeyTimestamp));
            const u = o.StatusV3Store.get(i);
            return (null === (r2 = null == u ? void 0 : u.msgs.get(t2)) || void 0 === r2 ? void 0 : r2.serialize()) || [];
          };
          const n = r(41687), o = r(14647);
        }, 72686(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendTextStatus = async function(e2, t2 = {}) {
            t2 = Object.assign(Object.assign({}, o.defaultSendStatusOptions), t2);
            let r2 = (0, n.assertColor)("#000000"), a = 0;
            ["number", "string"].includes(typeof t2.backgroundColor) && (r2 = (0, n.assertColor)(t2.backgroundColor));
            t2.font && t2.font >= 0 && t2.font <= 5 && (a = t2.font);
            const s = { body: e2, type: "chat", richPreviewType: 0, inviteGrpType: 0, font: a, backgroundColor: r2 };
            return await (0, i.sendRawStatus)(s, t2);
          };
          const n = r(41687), o = r(31167), i = r(99341);
        }, 53390(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.sendVideoStatus = async function(e2, t2 = {}) {
            const r2 = (0, i.getMyUserWid)(), c = new a.MsgKey({ fromMe: true, id: (0, s.randomHex)(16), participant: r2, remote: (0, n.assertWid)("status@broadcast") });
            t2 = Object.assign(Object.assign(Object.assign({}, u.defaultSendStatusOptions), { messageId: c }), t2);
            return await (0, o.sendFileMessage)("status@broadcast", e2, Object.assign(Object.assign({}, t2), { type: "video" }));
          };
          const n = r(41687), o = r(74023), i = r(21942), a = r(14647), s = r(52757), u = r(31167);
        }, 45218(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.updateParticipants = async function(e2) {
            let t2 = "custom";
            const r2 = (0, i.getMyUserWid)();
            e2 && 0 !== e2.length || (e2 = a.ContactStore.getModelsArray().filter((e3) => e3.isMyContact && !e3.isContactBlocked).filter((e3) => e3.notifyName && !e3.isMe).filter((e3) => !e3.id.equals(r2)).map((e3) => e3.id), t2 = "contacts");
            const s = e2.map(n.assertWid).filter((e3) => !e3.equals(r2));
            o.config.sendStatusToDevice && s.push(r2);
            const u = s.map((e3) => new a.ParticipantModel({ id: e3, isAdmin: false, isSuperAdmin: false })), c = a.WidFactory.createWid("status@broadcast");
            await a.functions.updateParticipants({ group: c, participants: u, version: Date.now(), isOffline: false }), localStorage.setItem("wpp-status-participants", t2);
          };
          const n = r(41687), o = r(91491), i = r(21942), a = r(14647);
        }, 31167(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), r(4213), r(98281), o(r(47494), t), o(r(99341), t);
        }, 98281(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(28156), u = r(21942), c = a(r(7222)), l = r(54993), d = r(52757);
          c.onFullReady(function() {
            (0, l.wrapModuleFunction)(d.handleSingleMsg, async (e2, ...t2) => {
              const [r2, n2] = t2;
              if (!s.config.syncAllStatus && r2.isStatusV3()) {
                const e3 = (0, u.getMyUserWid)();
                if (n2.author && !e3.equals(n2.author)) return;
              }
              return e2(...t2);
            });
          });
        }, 10632(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.blobToArrayBuffer = function(e2) {
            return new Promise((t2, r) => {
              const n = new FileReader();
              n.onloadend = function() {
                t2(n.result);
              }, n.onabort = r, n.onerror = r, n.readAsArrayBuffer(e2);
            });
          };
        }, 66604(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.blobToBase64 = function(e2) {
            return new Promise((t2, r) => {
              const n = new FileReader();
              n.onloadend = function() {
                t2(n.result);
              }, n.onabort = r, n.onerror = r, n.readAsDataURL(e2);
            });
          };
        }, 39681(e, t, r) {
          "use strict";
          var n = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.convertToFile = async function(e2, t2, r2) {
            if (e2 instanceof File) return e2;
            let n2 = null;
            if ("string" == typeof e2 && (0, a.isUrl)(e2)) {
              const t3 = await fetch(e2);
              n2 = await t3.blob();
            } else if ("string" == typeof e2) {
              let r3 = (0, i.default)(e2);
              if (!r3 && (0, a.isBase64)(e2) && (r3 = (0, i.default)("data:;base64," + e2)), !r3) throw "invalid_data_url";
              t2 || (t2 = r3.contentType);
              const o2 = r3.toBuffer();
              n2 = new Blob([Uint8Array.from(o2)], { type: t2 });
            } else n2 = e2;
            if (!r2 || !t2) {
              const e3 = await o.default.fromBuffer(await n2.arrayBuffer());
              if (e3) {
                const n3 = e3.mime.split("/")[0];
                r2 = r2 || `${n3}.${e3.ext}`, t2 = t2 || e3.mime;
              }
              r2 = r2 || "unknown", t2 = t2 || "application/octet-stream";
            }
            return new File([n2], r2, { type: t2, lastModified: Date.now() });
          };
          const o = n(r(53846)), i = n(r(62759)), a = r(62857);
        }, 13257(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.createWid = function(e2) {
            if (!e2) return;
            const t2 = o();
            if (t2 && t2.isWidlike && t2.isWidlike(e2)) return t2.createWidFromWidLike(e2);
            e2 && "object" == typeof e2 && "object" == typeof e2._serialized && (e2 = e2._serialized);
            e2 && "object" == typeof e2 && "string" == typeof e2._serialized && (e2 = e2._serialized);
            if ("string" != typeof e2) return;
            if (/@\w*lid\b/.test(e2)) return i(e2, "lid");
            if (/^\d+$/.test(e2)) return i(e2, "c.us");
            if (/^\d+-\d+$/.test(e2)) return i(e2, "g.us");
            if (/status$/.test(e2)) return i(e2, "broadcast");
            if (t2 && "function" == typeof t2.createWid) return t2.createWid(e2);
            return;
          };
          const n = r(14647);
          function o() {
            return void 0 !== n.WidFactory && n.WidFactory ? n.WidFactory : "undefined" != typeof globalThis && globalThis.WidFactory ? globalThis.WidFactory : void 0;
          }
          const i = (e2, t2) => {
            const r2 = o();
            if (r2) return "function" == typeof r2.createUserWidOrThrow ? r2.createUserWidOrThrow(e2, t2) : "function" == typeof r2.createUserWid ? r2.createUserWid(e2, t2) : "function" == typeof r2.createWid ? r2.createWid(t2 ? `${e2}@${t2}` : e2) : void 0;
          };
        }, 97016(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.downloadImage = function(e2, t2 = "image/jpeg", r = 0.85) {
            return new Promise((n, o) => {
              const i = new Image();
              i.crossOrigin = "anonymous", i.src = e2, i.onerror = o, i.onload = () => {
                const e3 = document.createElement("canvas"), o2 = e3.getContext("2d");
                e3.height = i.naturalHeight, e3.width = i.naturalWidth, o2.drawImage(i, 0, 0);
                const a = e3.toDataURL(t2, r);
                n({ data: a, height: i.naturalHeight, width: i.naturalWidth });
              };
            });
          };
        }, 55026(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.WPPError = void 0;
          class r extends Error {
            constructor(e2, t2, r2 = {}) {
              if (super(t2), this.code = e2, r2) {
                const e3 = Object.keys(r2);
                for (const t3 of e3) this[t3] = r2[t3];
              }
            }
          }
          t.WPPError = r;
        }, 24298(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.fetchDataFromPNG = function(e2) {
            return new Promise((t2, r) => {
              const n = new Image();
              n.crossOrigin = "anonymous", n.src = e2, n.onerror = r, n.onload = function() {
                const e3 = document.createElement("canvas"), r2 = e3.getContext("2d");
                e3.width = n.naturalWidth, e3.height = n.naturalHeight, r2.drawImage(n, 0, 0);
                const o = r2.getImageData(0, 0, e3.width, e3.height).data, i = new Uint8Array(Math.floor(3 * o.length / 4));
                for (let e4 = 0, t3 = 0; e4 < o.length; e4 += 4) i[t3++] = o[e4], i[t3++] = o[e4 + 1], i[t3++] = o[e4 + 2];
                let a = BigInt(0);
                for (let e4 = 0; e4 < 8; e4++) a = (a << BigInt(8)) + BigInt(i[e4]);
                const s = Number(a);
                t2(i.subarray(8, 8 + s));
              };
            });
          };
        }, 21294(e, t) {
          "use strict";
          t.formatFileSize = function(e2) {
            if (0 === e2) return "0 Bytes";
            const t2 = Math.floor(Math.log(e2) / Math.log(1024));
            return parseFloat((e2 / Math.pow(1024, t2)).toFixed(2)) + " " + ["Bytes", "KB", "MB", "GB"][t2];
          }, t.getMediaTypeForValidation = function(e2, t2) {
            if (e2 && "auto-detect" !== e2) return e2;
            if (t2.startsWith("image/")) return "image";
            if (t2.startsWith("video/")) return "video";
            if (t2.startsWith("audio/")) return "audio";
            return "document";
          };
        }, 25274(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.generateOrderUniqueId = function() {
            const e2 = String(Date.now()), t2 = Math.random().toFixed(4).slice(-4), r = e2 + t2;
            return ("function" == typeof BigInt ? BigInt(r) : Number(r)).toString(36).toUpperCase();
          };
        }, 82368(e, t, r) {
          "use strict";
          var n = r(48287).hp;
          Object.defineProperty(t, "__esModule", { value: true }), t.getVideoInfoFromBuffer = function(e2) {
            const t2 = n.from(e2), r2 = n.from("mvhd"), o = t2.indexOf(r2) + 17, i = t2.readUInt32BE(o), a = t2.readUInt32BE(o + 4), s = t2.indexOf(n.from("moov")), u = t2.indexOf(n.from("trak"), s + 4), c = t2.indexOf(n.from("stbl"), u + 4), l = t2.indexOf(n.from("avc1"), c + 4), d = t2.readUInt16BE(l + 4 + 24), f = t2.readUInt16BE(l + 4 + 26), p = Math.floor(a / i * 1e3) / 1e3;
            return { duration: Math.floor(p), width: d, height: f };
          };
        }, 62857(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(10632), t), o(r(66604), t), o(r(39681), t), o(r(13257), t), o(r(97016), t), o(r(55026), t), o(r(24298), t), o(r(25274), t), o(r(82368), t), o(r(7418), t), o(r(89076), t), o(r(12040), t), o(r(31617), t), o(r(59036), t), o(r(16817), t);
        }, 7418(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.isBase64 = function(e2) {
            return r.test(e2);
          };
          const r = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
        }, 89076(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.isUrl = function(e2) {
            if (!e2 || "string" != typeof e2) return false;
            const t2 = e2.trim();
            if (!/^https?:\/\//i.test(t2)) return false;
            try {
              const e3 = new URL(t2);
              return "http:" === e3.protocol || "https:" === e3.protocol;
            } catch (e3) {
              return false;
            }
          };
        }, 73113(e, t, r) {
          "use strict";
          var n = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.fetchRemoteLinkPreviewData = async function(e2) {
            if (p[e2]) return l("Link preview found in the cache", e2), p[e2];
            const t2 = new TextDecoder();
            for (let r2 = d.length - 1; r2 >= 0; r2--) {
              const n2 = d[r2];
              l(`Fetching link preview using ${n2}`, e2);
              const o2 = `${n2}/v1/link-preview/fetch-data.png?url=` + encodeURI(e2), i2 = await (0, c.fetchDataFromPNG)(o2).then((e3) => t2.decode(e3)).then((e3) => JSON.parse(e3)).catch(() => null);
              if (null === i2 || !("title" in i2) && !("status" in i2)) {
                l(`The server ${n2} is unavailable for link preview`), d.splice(r2, 1);
                continue;
              }
              if (!i2.title && 200 !== i2.status) continue;
              const a2 = /^video/.test(i2.mediaType), s2 = { title: i2.title, description: i2.description, canonicalUrl: i2.url, matchedText: e2, richPreviewType: a2 ? 1 : 0, doNotPlayInline: !a2, imageUrl: i2.image };
              return p[e2] = s2, setTimeout(() => {
                delete p[e2];
              }, 3e5), s2;
            }
            return null;
          }, t.generateThumbnailLinkPreviewData = async function(e2) {
            if (g[e2]) return l("Thumb for link preview found in cache.", e2), g[e2];
            if (!d[0]) return null;
            const t2 = d[0];
            l(`Downloading the preview image using ${t2}`, e2);
            const r2 = `${t2}/v1/link-preview/download-image?url=` + encodeURI(e2), n2 = await (0, u.downloadImage)(r2).catch(() => null);
            if (!n2) return null;
            if (n2.width < f || n2.height < 100) return null;
            const o2 = await function(e3) {
              return new Promise((t3, r3) => {
                const n3 = new Image();
                n3.crossOrigin = "anonymous", n3.src = e3, n3.onerror = r3, n3.onload = () => {
                  try {
                    const e4 = document.createElement("canvas"), r4 = e4.getContext("2d");
                    e4.width = f, e4.height = f;
                    const o3 = Math.min(n3.width, n3.height), i3 = (n3.width - o3) / 2, a2 = (n3.height - o3) / 2;
                    r4.drawImage(n3, i3, a2, o3, o3, 0, 0, f, f), t3(e4.toDataURL("image/jpeg").replace(/^data:image\/jpeg;base64,/, ""));
                  } catch (e4) {
                    r3();
                  }
                };
              });
            }(n2.data), i2 = n2.data.replace("data:image/jpeg;base64,", ""), c2 = await a.OpaqueData.createFromBase64Jpeg(i2), p2 = new Uint8Array(32), m = (window.crypto.getRandomValues(p2), { key: a.Base64.encodeB64(p2), timestamp: (0, s.unixTime)() }), y = new AbortController(), v = await (0, s.uploadThumbnail)({ thumbnail: c2, mediaType: "thumbnail-link", mediaKeyInfo: m, uploadOrigin: 1, forwardedFromWeb: false, signal: y.signal, timeout: 3e3, isViewOnce: false }), b = v.mediaEntry, h = { thumbnail: o2, thumbnailHQ: i2, mediaKey: b.mediaKey, mediaKeyTimestamp: b.mediaKeyTimestamp, thumbnailDirectPath: b.directPath, thumbnailSha256: v.filehash, thumbnailEncSha256: b.encFilehash, thumbnailWidth: n2.width, thumbnailHeight: n2.height };
            return g[e2] = h, setTimeout(() => {
              delete g[e2];
            }, 3e5), h;
          };
          const o = n(r(17833)), i = r(91491), a = r(14647), s = r(52757), u = r(97016), c = r(24298), l = (0, o.default)("WA-JS:link-preview"), d = i.config.linkPreviewApiServers || ["https://cobrancas.uppermesh.com.br:8000", "https://wajsapi.titanchat.com.br", "https://wppc-linkpreview.cloudtrix.com.br"], f = 140, p = {}, g = {};
          !function(e2) {
            for (let t2 = e2.length - 1; t2 > 0; t2--) {
              const r2 = Math.floor(Math.random() * (t2 + 1));
              [e2[t2], e2[r2]] = [e2[r2], e2[t2]];
            }
          }(d);
        }, 12040(e, t, r) {
          "use strict";
          var n = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t.resizeImage = function(e2, t2 = {}) {
            return new Promise((r2, n2) => {
              new o.default(e2, Object.assign(Object.assign({}, t2), { success: r2, error: n2 }));
            });
          };
          const o = n(r(23807));
        }, 31617(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.toArrayBuffer = function(e2) {
            if (!e2) return null;
            if (e2 instanceof ArrayBuffer) return e2;
            if (ArrayBuffer.isView(e2)) {
              return new Uint8Array(e2.buffer, e2.byteOffset, e2.byteLength).slice().buffer;
            }
            return new Uint8Array(e2).slice().buffer;
          };
        }, 59036(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
        }, 16817(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true }), t.wrapFunction = function(e2, t2) {
            return (...r) => t2(e2, ...r);
          };
        }, 28922(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { AggReactionsCollection: "AggReactionsCollection" }, (e2) => e2.AggReactionsCollection);
        }, 93316(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { BaseCollection: "BaseCollection" }, (e2) => e2.BaseCollection);
        }, 924(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { BlocklistCollection: ["BlocklistCollectionImpl", "BlocklistCollection"] }, (e2) => e2.BlocklistCollectionImpl || e2.BlocklistCollection);
        }, 18795(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { BotProfileCollection: ["BotProfileCollection"] }, (e2) => e2.BotProfileCollection);
        }, 51150(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { BusinessCategoriesResultCollection: "BusinessCategoriesResultCollectionImpl" }, (e2) => e2.BusinessCategoriesResultCollectionImpl);
        }, 21330(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { BusinessProfileCollection: ["BusinessProfileCollectionImpl", "BusinessProfileCollection"] }, (e2) => e2.BusinessProfileCollectionImpl || e2.BusinessProfileCollection);
        }, 83573(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ButtonCollection: ["ButtonCollectionImpl", "ButtonCollection", "default"] }, (e2, t2) => "WAWebButtonCollection" === t2 || !(!e2.ButtonCollectionImpl && !e2.ButtonCollection));
        }, 96993(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { CallCollection: ["CallCollectionImpl", "default.constructor"] }, (e2) => e2.CallCollectionImpl || e2.default.processIncomingCall);
        }, 22523(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { CartCollection: ["CartCollectionImpl", "CartCollection"] }, (e2) => e2.CartCollectionImpl || e2.CartCollection);
        }, 25716(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { CartItemCollection: ["CartItemCollectionImpl", "CartItemCollection"] }, (e2) => e2.CartItemCollectionImpl || e2.CartItemCollection);
        }, 10674(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { CatalogCollection: ["CatalogCollectionImpl", "CatalogCollection"] }, (e2) => e2.CatalogCollectionImpl || e2.CatalogCollection);
        }, 29683(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ChatCollection: "ChatCollectionImpl" }, (e2) => e2.ChatCollectionImpl);
        }, 27462(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ChatstateCollection: ["ChatstateCollectionImpl", "Chatstate"] }, (e2) => e2.ChatstateCollectionImpl || e2.Chatstate);
        }, 60193(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { Collection: "default" }, (e2) => e2.default.toString().includes("Collection initialized without model"));
        }, 54477(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ContactCollection: "ContactCollectionImpl" }, (e2) => e2.ContactCollectionImpl);
        }, 16794(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { EmojiVariantCollection: ["EmojiVariantCollectionImpl", "EmojiVariantCollection"] }, (e2) => e2.EmojiVariantCollectionImpl || e2.EmojiVariantCollection);
        }, 58699(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { GroupMetadataCollection: "default.constructor" }, (e2) => "function" == typeof e2.default.onParentGroupChange || "function" == typeof e2.default._handleParentGroupChange);
        }, 86451(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { LabelCollection: ["LabelCollectionImpl", "LabelCollection"] }, (e2) => e2.LabelCollectionImpl || e2.LabelCollection);
        }, 35052(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { LabelItemCollection: ["LabelItemCollectionImpl", "LabelItemCollection"] }, (e2) => e2.LabelItemCollectionImpl || e2.LabelItemCollection);
        }, 67880(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { MsgCollection: ["MsgCollectionImpl", "MsgCollection.constructor"] }, (e2) => {
            var t2;
            return e2.MsgCollectionImpl || "function" == typeof (null === (t2 = e2.MsgCollection) || void 0 === t2 ? void 0 : t2.processMultipleMessages);
          });
        }, 1160(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { MsgInfoCollection: ["MsgInfoCollectionImpl", "MsgInfoCollection"] }, (e2) => e2.MsgInfoCollectionImpl || e2.MsgInfoCollection);
        }, 58383(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ParticipantCollection: ["ParticipantCollection"] }, (e2) => e2.ParticipantCollection);
        }, 22712(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { MuteCollection: ["MuteCollectionImpl", "MuteCollection"] }, (e2) => e2.MuteCollectionImpl || e2.MuteCollection);
        }, 85509(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { NoteCollection: ["NoteCollection.constructor"] }, (e2) => e2.NoteCollection);
        }, 21865(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { OrderCollection: ["OrderCollectionImpl", "OrderCollection"] }, (e2) => e2.OrderCollectionImpl || e2.OrderCollection);
        }, 27082(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { OrderItemCollection: ["OrderItemCollectionImpl", "OrderItemCollection"] }, (e2) => e2.OrderItemCollectionImpl || e2.OrderItemCollection);
        }, 2100(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ParticipantCollection: ["default"] }, (e2) => e2.default.prototype.iAmMember);
        }, 90175(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { PinInChatCollection: ["PinInChatCollectionImpl", "PinInChatCollection"] }, (e2) => e2.PinInChatCollectionImpl || e2.PinInChatCollection);
        }, 74308(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { PresenceCollection: ["PresenceCollectionImpl", "PresenceCollection"] }, (e2) => e2.PresenceCollectionImpl || e2.PresenceCollection);
        }, 6384(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ProductCollCollection: ["ProductCollCollectionImpl", "ProductCollCollection"] }, (e2) => e2.ProductCollCollectionImpl || e2.ProductCollCollection);
        }, 88354(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ProductCollection: ["ProductCollectionImpl", "ProductCollection"] }, (e2) => e2.ProductCollectionImpl || e2.ProductCollection);
        }, 99013(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ProductImageCollection: ["ProductImageCollectionImpl", "ProductImageCollection"] }, (e2) => e2.ProductImageCollectionImpl || e2.ProductImageCollection);
        }, 9239(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ProductMessageListCollection: ["ProductMessageListCollectionImpl", "ProductMessageListCollection"] }, (e2) => e2.ProductMessageListCollectionImpl || e2.ProductMessageListCollection);
        }, 39240(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ProfilePicThumbCollection: ["ProfilePicThumbCollectionImpl", "ProfilePicThumbCollection"] }, (e2) => e2.ProfilePicThumbCollectionImpl || e2.ProfilePicThumbCollection);
        }, 79320(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { QuickReplyCollection: ["QuickReplyCollectionImpl", "QuickReplyCollection"] }, (e2) => e2.QuickReplyCollectionImpl || e2.QuickReplyCollection);
        }, 9601(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ReactionsCollection: ["ReactionsCollectionImpl", "ReactionsCollection"] }, (e2) => e2.ReactionsCollectionImpl || e2.ReactionsCollection);
        }, 76363(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ReactionsSendersCollection: "ReactionsSendersCollection" }, (e2) => e2.ReactionsSendersCollection);
        }, 37354(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { RecentEmojiCollection: ["RecentEmojiCollectionImpl", "RecentEmojiCollection"] }, (e2) => e2.RecentEmojiCollectionImpl || e2.RecentEmojiCollection);
        }, 17987(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { RecentStickerCollection: ["RecentStickerCollectionImpl", "RecentStickerCollection"] }, (e2) => e2.RecentStickerCollectionImpl || e2.RecentStickerCollection);
        }, 18393(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { StarredMsgCollection: ["StarredMsgCollectionImpl", "StarredMsgCollection"] }, (e2) => e2.StarredMsgCollectionImpl || e2.StarredMsgCollection);
        }, 85959(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { StatusCollection: ["TextStatusCollectionImpl", "TextStatusCollection"] }, (e2) => e2.TextStatusCollectionImpl || e2.TextStatusCollection);
        }, 23572(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { StatusV3Collection: ["StatusV3CollectionImpl", "StatusCollectionImpl", "StatusCollection"] }, (e2) => e2.StatusV3CollectionImpl || e2.StatusV3Collection || e2.StatusCollectionImpl || e2.StatusCollection);
        }, 87210(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { StickerCollection: "StickerCollectionImpl" }, (e2) => e2.StickerCollectionImpl || e2.StickerCollection);
        }, 84471(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { StickerPackCollection: ["StickerPackCollectionImpl", "StickerPackCollection"] }, (e2) => e2.StickerPackCollectionImpl || e2.StickerPackCollection);
        }, 69634(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { StickerSearchCollection: ["StickerSearchCollectionImpl", "StickerSearchCollection"] }, (e2) => e2.StickerSearchCollectionImpl || e2.StickerSearchCollection);
        }, 40999(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { TemplateButtonCollection: "TemplateButtonCollection" }, (e2) => e2.TemplateButtonCollectionImpl || e2.TemplateButtonCollection);
        }, 12105(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(28922), t), o(r(93316), t), o(r(924), t), o(r(18795), t), o(r(51150), t), o(r(21330), t), o(r(83573), t), o(r(96993), t), o(r(22523), t), o(r(25716), t), o(r(10674), t), o(r(29683), t), o(r(27462), t), o(r(60193), t), o(r(54477), t), o(r(54477), t), o(r(54477), t), o(r(16794), t), o(r(58699), t), o(r(86451), t), o(r(35052), t), o(r(67880), t), o(r(1160), t), o(r(58383), t), o(r(22712), t), o(r(85509), t), o(r(21865), t), o(r(27082), t), o(r(2100), t), o(r(90175), t), o(r(74308), t), o(r(6384), t), o(r(88354), t), o(r(99013), t), o(r(9239), t), o(r(39240), t), o(r(79320), t), o(r(9601), t), o(r(76363), t), o(r(37354), t), o(r(17987), t), o(r(18393), t), o(r(85959), t), o(r(23572), t), o(r(87210), t), o(r(84471), t), o(r(69634), t), o(r(40999), t);
        }, 34491(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { DROP_ATTR: ["DROP_ATTR"] }, (e2) => e2.DROP_ATTR);
        }, 40504(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { SANITIZED_VERSION_STR: ["SANITIZED_VERSION_STR"] }, (e2) => e2.SANITIZED_VERSION_STR);
        }, 19198(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(34491), t), o(r(40504), t);
        }, 91979(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ACK: ["ACK", "default.ACK"], EDIT_ATTR: ["EDIT_ATTR", "default.EDIT_ATTR"], ACK_STRING: ["ACK_STRING", "default.ACK_STRING"] }, (e2) => e2.ACK && e2.ACK_STRING || e2.default.ACK && e2.default.ACK_STRING);
        }, 48077(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { CALL_STATES: ["CALL_STATES", "CallState"] }, (e2) => e2.CALL_STATES || e2.CallState);
        }, 71214(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { CHANNEL_EVENT_SURFACE: "CHANNEL_EVENT_SURFACE" }, (e2) => e2.CHANNEL_EVENT_SURFACE);
        }, 49193(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { GROUP_SETTING_TYPE: ["GROUP_SETTING_TYPE", "default.GROUP_SETTING_TYPE"] }, (e2) => e2.GROUP_SETTING_TYPE || e2.default.GROUP_SETTING_TYPE);
        }, 10611(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { KIC_ENTRY_POINT_TYPE: "KIC_ENTRY_POINT_TYPE" }, (e2) => e2.KIC_ENTRY_POINT_TYPE);
        }, 14774(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { LogoutReason: "LogoutReason", LOGOUT_REASON_CODE: "LOGOUT_REASON_CODE" }, (e2) => e2.LogoutReason && e2.LOGOUT_REASON_CODE);
        }, 26105(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { MSG_TYPE: ["MSG_TYPE", "default.MSG_TYPE"], SYSTEM_MESSAGE_TYPES: ["SYSTEM_MESSAGE_TYPES", "default.SYSTEM_MESSAGE_TYPES"] }, (e2) => e2.MSG_TYPE || e2.default.MSG_TYPE);
        }, 63718(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { OUTWARD_TYPES: "OUTWARD_TYPES" }, (e2) => e2.OUTWARD_TYPES);
        }, 57579(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { PIN_STATE: "PIN_STATE" }, (e2) => e2.PIN_STATE);
        }, 51351(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { PinExpiryDurationOption: "PinExpiryDurationOption" }, (e2) => e2.PinExpiryDurationOption);
        }, 89763(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { SOCKET_STATE: ["SOCKET_STATE", "default.SOCKET_STATE"], SOCKET_STREAM: ["SOCKET_STREAM", "default.SOCKET_STREAM"], WATCHED_SOCKET_STATE: ["WATCHED_SOCKET_STATE", "default.WATCHED_SOCKET_STATE"] }, (e2) => e2.SOCKET_STATE || e2.default.SOCKET_STATE);
        }, 40936(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { SendMsgResult: "SendMsgResult" }, (e2) => e2.SendMsgResult);
        }, 7740(e, t) {
          "use strict";
          var r;
          Object.defineProperty(t, "__esModule", { value: true }), t.StreamInfo = void 0, function(e2) {
            e2.OFFLINE = "OFFLINE", e2.OPENING = "OPENING", e2.PAIRING = "PAIRING", e2.SYNCING = "SYNCING", e2.RESUMING = "RESUMING", e2.CONNECTING = "CONNECTING", e2.NORMAL = "NORMAL";
          }(r || (t.StreamInfo = r = {}));
        }, 39003(e, t) {
          "use strict";
          var r;
          Object.defineProperty(t, "__esModule", { value: true }), t.StreamMode = void 0, function(e2) {
            e2.QR = "QR", e2.MAIN = "MAIN", e2.SYNCING = "SYNCING", e2.OFFLINE = "OFFLINE", e2.CONFLICT = "CONFLICT", e2.PROXYBLOCK = "PROXYBLOCK", e2.TOS_BLOCK = "TOS_BLOCK", e2.SMB_TOS_BLOCK = "SMB_TOS_BLOCK", e2.DEPRECATED_VERSION = "DEPRECATED_VERSION";
          }(r || (t.StreamMode = r = {}));
        }, 91626(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { WAWebNonJidMentionType: "default" }, (e2) => {
            var t2;
            return 1 === (null === (t2 = e2.default) || void 0 === t2 ? void 0 : t2.MENTION_ALL);
          });
        }, 20514(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(91979), t), o(r(48077), t), o(r(71214), t), o(r(49193), t), o(r(10611), t), o(r(14774), t), o(r(26105), t), o(r(63718), t), o(r(57579), t), o(r(51351), t), o(r(40936), t), o(r(7740), t), o(r(39003), t), o(r(91626), t);
        }, 54993(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          }), s = this && this.__importDefault || function(e2) {
            return e2 && e2.__esModule ? e2 : { default: e2 };
          };
          Object.defineProperty(t, "__esModule", { value: true }), t._moduleIdMap = void 0, t.exportModule = h, t.exportProxyModel = function(e2, t2) {
            const r2 = t2.replace(/Model$/, ""), n2 = [r2];
            n2.push(r2.replace(/^(\w)/, (e3) => e3.toLowerCase()));
            const o2 = r2.split(/(?=[A-Z])/);
            n2.push(o2.join("-").toLowerCase()), n2.push(o2.join("_").toLowerCase()), h(e2, { [t2]: ["default", t2, r2] }, (e3) => {
              var o3, i2, a2, s2, u2, c2;
              return n2.includes((null === (i2 = null === (o3 = e3.default) || void 0 === o3 ? void 0 : o3.prototype) || void 0 === i2 ? void 0 : i2.proxyName) || (null === (s2 = null === (a2 = e3[t2]) || void 0 === a2 ? void 0 : a2.prototype) || void 0 === s2 ? void 0 : s2.proxyName) || (null === (c2 = null === (u2 = e3[r2]) || void 0 === u2 ? void 0 : u2.prototype) || void 0 === c2 ? void 0 : c2.proxyName));
            });
          }, t.wrapModuleFunction = function(e2, r2) {
            if ("function" != typeof e2) return void console.error("func is not a function");
            const n2 = t._moduleIdMap.get(e2);
            if (!n2) return void console.error("func is not an exported function");
            const o2 = d.loadModule(n2), i2 = v.get(e2);
            if (!i2) return void console.error("function path was not found");
            g.extend("wrap")(`Wrapping '${i2} for module ${n2}'`);
            const a2 = i2.split("."), s2 = a2.pop();
            if (!s2) {
              const e3 = `function was not found in the module ${n2}`;
              return console.error(e3), void (0, l.trackException)(e3);
            }
            const u2 = a2.reduce((e3, t2) => null == e3 ? void 0 : e3[t2], o2);
            u2[s2] = "getShouldAppearInList" == s2 ? (0, c.wrapShouldAppearFunction)(e2.bind(u2), r2) : (0, p.wrapFunction)(e2.bind(u2), r2);
            y.set(u2[s2], n2), v.set(u2[s2], i2);
          };
          const u = s(r(17833)), c = r(43859), l = r(22418), d = a(r(7222)), f = r(22769), p = r(62857), g = (0, u.default)("WA-JS:export");
          class m extends WeakMap {
            constructor() {
              super(...arguments), this.stringMap = /* @__PURE__ */ new Map();
            }
            delete(e2) {
              return "string" == typeof e2 ? this.stringMap.delete(e2) : super.delete(e2);
            }
            get(e2) {
              return "string" == typeof e2 ? this.stringMap.get(e2) : super.get(e2);
            }
            has(e2) {
              return "string" == typeof e2 ? this.stringMap.has(e2) : super.has(e2);
            }
            set(e2, t2) {
              return "string" == typeof e2 ? (this.stringMap.set(e2, t2), this) : (super.set(e2, t2), this);
            }
          }
          const y = new m(), v = new m();
          t._moduleIdMap = y;
          const b = /* @__PURE__ */ new Set();
          function h(e2, t2, r2) {
            "string" == typeof t2 && (t2 = { [t2]: null });
            for (const n2 of Object.keys(t2)) {
              const o2 = t2[n2];
              Object.defineProperty(e2, n2, { enumerable: true, configurable: true, get() {
                let e3, t3;
                const i2 = d.searchId(r2);
                if (!i2) {
                  const e4 = `Module ${n2} was not found with ${r2.toString()}`;
                  return void (f.IGNORE_FAIL_MODULES.has(n2) || b.has(n2) || (b.add(n2), console.error(e4), (0, l.trackException)(e4)));
                }
                const a2 = d.loadModule(i2);
                if (Array.isArray(o2)) {
                  for (const r3 of o2) if (e3 = () => r3.split(".").reduce((e4, t4) => null == e4 ? void 0 : e4[t4], a2), e3()) {
                    t3 = r3;
                    break;
                  }
                  if (!e3()) {
                    const e4 = `Property ${o2.join(" or ")} was not found for ${n2} in module ${i2}`;
                    return console.error(e4), (0, l.trackException)(e4), void Object.defineProperty(this, n2, { get: () => {
                    } });
                  }
                } else if ("string" == typeof o2) {
                  if (e3 = () => o2.split(".").reduce((e4, t4) => null == e4 ? void 0 : e4[t4], a2), !e3()) {
                    const e4 = `Property ${o2} was not found for ${n2} in module ${i2}`;
                    return console.error(e4), (0, l.trackException)(e4), void Object.defineProperty(this, n2, { get: () => {
                    } });
                  }
                  t3 = o2;
                } else e3 = () => a2;
                if (e3) {
                  Object.defineProperty(this, n2, { get: e3 });
                  try {
                    const r3 = e3();
                    y.set(r3, i2), t3 && v.set(r3, t3);
                  } catch (e4) {
                  }
                  return e3();
                }
                Object.defineProperty(this, n2, { get: () => {
                } });
              } });
            }
          }
        }, 11782(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { GROUP_JID: "GROUP_JID", CHAT_JID: "CHAT_JID" }, (e2) => e2.GROUP_JID && e2.CHAT_JID);
        }, 83019(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { STATUS_JID: "STATUS_JID" }, (e2) => e2.STATUS_JID);
        }, 35674(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getAllABPropConfigs: "getAllABPropConfigs", getAllABPropsMap: "getAllABPropsMap", getABPropConfigNameFromCode: "getABPropConfigNameFromCode" }, (e2) => e2.getAllABPropConfigs && e2.getABPropConfigNameFromCode);
        }, 72116(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { addAndSendMessageEdit: "addAndSendMessageEdit" }, (e2) => e2.addAndSendMessageEdit);
        }, 19885(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { addAndSendMsgToChat: "addAndSendMsgToChat" }, (e2) => e2.addAndSendMsgToChat);
        }, 33505(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { addOrEditNoteAction: "addOrEditNoteAction", retrieveOnlyNoteForChatJid: "retrieveOnlyNoteForChatJid" }, (e2) => e2.addOrEditNoteAction && e2.retrieveOnlyNoteForChatJid);
        }, 25736(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(54993);
          (0, n.exportModule)(t, { addProductToCart: "addProductToCart" }, (e2) => e2.addProductToCart), (0, n.exportModule)(t, { updateProductQuantityCart: "default" }, (e2) => {
            var t2, r2;
            return null === (r2 = null === (t2 = e2.default) || void 0 === t2 ? void 0 : t2.displayName) || void 0 === r2 ? void 0 : r2.includes("BizUpdateProductQuantityCartAction");
          }), (0, n.exportModule)(t, { deleteProductFromCart: "default" }, (e2) => {
            var t2, r2;
            return null === (r2 = null === (t2 = e2.default) || void 0 === t2 ? void 0 : t2.displayName) || void 0 === r2 ? void 0 : r2.includes("BizDeleteProductFromCartAction");
          });
        }, 55889(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { addToLabelCollection: "addToLabelCollection", createLabelItemId: "createLabelItemId", getParentCollection: "getParentCollection", initializeLabels: "initializeLabels", removeLabelFromCollection: "removeLabelFromCollection" }, (e2) => e2.addToLabelCollection);
        }, 50854(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { blockContact: "blockContact", unblockContact: "unblockContact" }, (e2) => e2.blockContact && e2.unblockContact);
        }, 22328(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { calculateFilehashFromBlob: "calculateFilehashFromBlob" }, (e2) => e2.calculateFilehashFromBlob);
        }, 90722(e, t, r) {
          "use strict";
          t.callGetSearchContext = function(e2, t2) {
            if (1 === n.getSearchContext.length) return (0, n.getSearchContext)({ chat: e2, msgKey: t2 });
            return (0, n.getSearchContext)(e2, t2);
          };
          const n = r(73890);
        }, 64794(e, t, r) {
          "use strict";
          t.callLabelDeleteAction = function(e2, t2, r2) {
            if (1 === n.labelDeleteAction.length) return (0, n.labelDeleteAction)({ labelId: e2, name: t2, color: r2 });
            return (0, n.labelDeleteAction)(e2, t2, r2);
          };
          const n = r(33750);
        }, 29697(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { canEditCaption: "canEditCaption" }, (e2) => e2.canEditCaption);
        }, 77082(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { canEditMsg: ["canEditText", "canEditMsg"] }, (e2) => e2.canEditMsg || e2.canEditText);
        }, 71274(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { canReplyMsg: "canReplyMsg" }, (e2) => e2.canReplyMsg);
        }, 40581(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { canSaveAsMyContact: ["canSaveAsMyContact", "canSaveAsMyContacts"], canSaveAsMyContacts: ["canSaveAsMyContact", "canSaveAsMyContacts"] }, (e2) => e2.canSaveAsMyContact || e2.canSaveAsMyContacts);
        }, 4525(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(7222), o = r(54993), i = r(57411), a = r(43593), s = r(41968), u = r(80214);
          (0, o.exportModule)(t, { changeOptInStatusForExternalWebBeta: "changeOptInStatusForExternalWebBeta" }, (e2) => e2.changeOptInStatusForExternalWebBeta), (0, n.injectFallbackModule)("changeOptInStatusForExternalWebBeta", { changeOptInStatusForExternalWebBeta: async (e2) => {
            await Promise.all([(0, s.setWhatsAppWebExternalBetaDirtyBitIdb)(true), (0, s.setWhatsAppWebExternalBetaJoinedIdb)(e2)]), await (0, i.stopComms)(), await (0, i.startWebComms)(), await (0, i.startHandlingRequests)(), await (0, u.syncABPropsTask)(), await (0, a.frontendFireAndForget)("changeOptInStatusForExternalWebBeta", {}), await (0, s.setWhatsAppWebExternalBetaDirtyBitIdb)(false);
          } });
        }, 63548(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { checkChatExistedOrCreate: ["checkChatExistedOrCreate", "checkChatExistsOrCreate"] }, (e2) => e2.checkChatExistedOrCreate || e2.checkChatExistsOrCreate);
        }, 58652(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(54993);
          (0, n.exportModule)(t, { createCollection: "createCollection" }, (e2) => e2.createCollection), (0, n.exportModule)(t, { deleteCollection: "deleteCollection", editCollection: "editCollection" }, (e2) => e2.deleteCollection && e2.editCollection), (0, n.exportModule)(t, { queryCollectionsIQ: ["queryCollectionsIQ", "default"] }, (e2) => {
            var t2, r2;
            return e2.queryCollectionsIQ || (null === (r2 = null === (t2 = e2.default) || void 0 === t2 ? void 0 : t2.displayName) || void 0 === r2 ? void 0 : r2.toString().includes("QueryProductCollections"));
          });
        }, 71400(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { colorIndexToHex: "colorIndexToHex", getAllLabelColors: "getAllLabelColors" }, (e2) => e2.colorIndexToHex && e2.getAllLabelColors);
        }, 37300(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(54993);
          (0, n.exportModule)(t, { getNotifyName: "getNotifyName", getPremiumMessageName: "getPremiumMessageName", getUserid: "getUserid", getIsMe: "getIsMe", getIsUser: "getIsUser", getIsGroup: "getIsGroup", getIsBroadcast: "getIsBroadcast", getIsNewsletter: "getIsNewsletter", getIsPSA: "getIsPSA", getIsIAS: "getIsIAS", getIsSupportAccount: "getIsSupportAccount", getIsWAContact: "getIsWAContact", getCanRequestPhoneNumber: "getCanRequestPhoneNumber", getShowBusinessCheckmarkAsPrimary: "getShowBusinessCheckmarkAsPrimary", getShowBusinessCheckmarkAsSecondary: "getShowBusinessCheckmarkAsSecondary", getShowBusinessCheckmarkInChatlist: "getShowBusinessCheckmarkInChatlist", getIsDisplayNameApproved: "getIsDisplayNameApproved", getShouldForceBusinessUpdate: "getShouldForceBusinessUpdate" }, (e2) => e2.getNotifyName && e2.getIsMe && e2.getUserid), (0, n.exportModule)(t, { getUserhash: "getUserhash" }, (e2) => e2.getNotifyName && e2.getIsMe && e2.getUserhash), (0, n.exportModule)(t, { getDisplayName: "getDisplayName", getPnForLid: "getPnForLid", getDisplayNameOrPnForLid: ["getUserDisplayNameForLid", "getDisplayNameOrPnForLid"], getFormattedPhone: ["getFormattedPhone", "getFormattedUsernameOrPhone"], getFormattedUsernameOrPhone: ["getFormattedUsernameOrPhone", "getFormattedPhone"], getFormattedShortNameWithNonBreakingSpaces: "getFormattedShortNameWithNonBreakingSpaces", getFormattedShortName: "getFormattedShortName", getFormattedName: "getFormattedName", getFormattedUser: "getFormattedUser", getSearchName: "getSearchName" }, (e2) => e2.getPhoneNumber && e2.getTextStatusString && e2.getPnForLid), (0, n.exportModule)(t, { getIsMyContact: "getIsMyContact", getMentionName: ["getMentionName", "getFormattedShortName"] }, (e2) => e2.getIsMyContact), (0, n.exportModule)(t, { getSearchVerifiedName: "getSearchVerifiedName", getHeader: "getHeader" }, (e2) => e2.getSearchVerifiedName && e2.getHeader);
        }, 46915(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { createChat: "createChat" }, (e2) => e2.createChat);
        }, 15878(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { createChatRecord: "createChatRecord" }, (e2) => e2.createChatRecord);
        }, 95141(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { createEventCallLink: "createEventCallLink" }, (e2) => e2.createEventCallLink);
        }, 95612(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { createFanoutMsgStanza: "createFanoutMsgStanza" }, (e2) => e2.createFanoutMsgStanza);
        }, 97718(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { createGroup: "createGroup" }, (e2) => e2.createGroup && e2.GroupAlreadyExistsError);
        }, 7967(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { createMsgProtobuf: "createMsgProtobuf" }, (e2) => e2.createMsgProtobuf);
        }, 28940(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { createNewsletterQuery: "createNewsletterQuery" }, (e2) => e2.createNewsletterQuery);
        }, 48441(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { createOrUpdateReactions: ["addOrUpdateReactionsModelCollection"] }, (e2) => e2.addOrUpdateReactionsModelCollection);
        }, 10293(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { createOrder: "createOrder" }, (e2) => e2.createOrder);
        }, 25882(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { currencyForCountryShortcode: ["currencyForCountryShortcode"] }, (e2) => e2.currencyForCountryShortcode);
        }, 70806(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { deleteContactAction: "deleteContactAction", deleteContactActionV2: "deleteContactAction" }, (e2) => e2.deleteContactAction);
        }, 51137(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { deleteNewsletter: "deleteNewsletter" }, (e2) => e2.deleteNewsletter);
        }, 85882(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { editBusinessProfile: "editBusinessProfile" }, (e2) => e2.editBusinessProfile);
        }, 82641(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { editNewsletterMetadataAction: "editNewsletterMetadataAction" }, (e2) => e2.editNewsletterMetadataAction);
        }, 4375(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { encodeMaybeMediaType: "encodeMaybeMediaType" }, (e2) => e2.encodeMaybeMediaType);
        }, 16877(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { encryptAndSendGroupMsg: "encryptAndSendGroupMsg" }, (e2) => e2.encryptAndSendGroupMsg);
        }, 53008(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { encryptAndSendMsg: "encryptAndSendMsg" }, (e2) => e2.encryptAndSendMsg);
        }, 32(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { encryptAndSendSenderKeyMsg: "encryptAndSendSenderKeyMsg" }, (e2) => e2.encryptAndSendSenderKeyMsg);
        }, 61158(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { encryptAndSendStatusMsg: "encryptAndSendStatusMsg" }, (e2) => e2.encryptAndSendStatusMsg);
        }, 34040(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { encryptMsgProtobuf: "encryptMsgProtobuf" }, (e2) => e2.encryptMsgProtobuf);
        }, 6357(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = a(r(7222));
          (0, r(54993).exportModule)(t, { fetchLinkPreview: ["getLinkPreview", "default"] }, (e2, t2) => {
            if (e2.getLinkPreview && !e2.getAck) return true;
            const r2 = s.moduleSource(t2);
            return r2.includes(".genMinimalLinkPreview") && r2.includes(".getProductOrCatalogLinkPreview");
          });
        }, 21892(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(64456), o = r(7222), i = r(54993), a = r(9534);
          (0, i.exportModule)(t, { fetchMexGroupInviteCode: "fetchMexGroupInviteCode" }, (e2) => e2.fetchMexGroupInviteCode), (0, o.injectFallbackModule)("fetchMexGroupInviteCode", { fetchMexGroupInviteCode: async (e2) => {
            const t2 = await (0, n.iAmAdmin)(e2);
            return await (0, a.queryGroupInviteCode)(e2, t2).then((e3) => e3.code);
          } });
        }, 34324(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { findChat: ["findChat", "findExistingChat"] }, (e2) => e2.findChat || e2.findExistingChat);
        }, 49035(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { findCommonGroups: "findCommonGroups" }, (e2) => e2.findCommonGroups);
        }, 95554(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { findFirstWebLink: "findFirstWebLink" }, (e2) => e2.findFirstWebLink);
        }, 84874(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { findOrCreateLatestChat: "findOrCreateLatestChat" }, (e2) => e2.findOrCreateLatestChat);
        }, 40300(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { forwardMessages: "forwardMessages" }, (e2, t2) => "WAWebChatForwardMessage" === t2);
        }, 64538(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(7222), o = r(54993), i = r(40649);
          (0, o.exportModule)(t, { forwardMessagesToChats: "forwardMessagesToChats" }, (e2) => e2.forwardMessagesToChats), (0, n.injectFallbackModule)("forwardMessagesToChats", { forwardMessagesToChats: (e2, t2, r2) => i.ChatStore.forwardMessagesToChats(e2, t2, r2) });
        }, 43593(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { frontendFireAndForget: "frontendFireAndForget" }, (e2) => e2.frontendFireAndForget);
        }, 24444(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { genBotMsgSecretFromMsgSecret: "genBotMsgSecretFromMsgSecret" }, (e2) => e2.genBotMsgSecretFromMsgSecret);
        }, 47440(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { genLinkDeviceCodeForPhoneNumber: "genLinkDeviceCodeForPhoneNumber" }, (e2) => e2.genLinkDeviceCodeForPhoneNumber);
        }, 25602(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { genMinimalLinkPreview: "genMinimalLinkPreview" }, (e2) => e2.genMinimalLinkPreview);
        }, 85541(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { generateVideoThumbsAndDuration: "generateVideoThumbsAndDuration" }, (e2) => e2.generateVideoThumbsAndDuration);
        }, 95524(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getABPropConfigValue: "getABPropConfigValue" }, (e2) => e2.getABPropConfigValue);
        }, 92538(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getAsMms: "getAsMms" }, (e2) => e2.getAsMms);
        }, 89559(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getChatRecordByAccountLid: "getChatRecordByAccountLid" }, (e2) => e2.getChatRecordByAccountLid);
        }, 42930(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getCommunityParticipants: "getCommunityParticipants" }, (e2) => e2.getCommunityParticipants);
        }, 19553(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getCountryShortcodeByPhone: ["getCountryShortcodeByPhone"] }, (e2) => e2.getCountryShortcodeByPhone);
        }, 79731(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getCurrentLid: "getCurrentLid" }, (e2) => e2.getCurrentLid);
        }, 74857(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getEnforceCurrentLid: ["getEnforceCurrentLid", "getCurrentLidForUserWid", "toLid"] }, (e2) => e2.getEnforceCurrentLid || e2.getCurrentLidForUserWid || e2.toLid);
        }, 92787(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getEphemeralFields: "getEphemeralFields" }, (e2) => e2.getEphemeralFields);
        }, 55072(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getExisting: "getExisting" }, (e2) => e2.getExisting);
        }, 86362(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getFanOutList: "getFanOutList" }, (e2) => e2.getFanOutList);
        }, 58084(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getGroupSenderKeyList: "getGroupSenderKeyList", markForgetSenderKey: "markForgetSenderKey" }, (e2) => e2.getGroupSenderKeyList);
        }, 66852(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getGroupSizeLimit: "getGroupSizeLimit" }, (e2) => e2.getGroupSizeLimit);
        }, 6281(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getHistorySyncProgress: ["getHistorySyncProgressModel", "getHistorySyncProgress"] }, (e2) => e2.getHistorySyncProgressModel || e2.getHistorySyncProgress && !e2.getHistorySyncLogDetailsString);
        }, 54616(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getMembershipApprovalRequests: "getMembershipApprovalRequests" }, (e2) => e2.getMembershipApprovalRequests);
        }, 78943(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getNewsletterSubscribers: "getNewsletterSubscribers" }, (e2) => e2.getNewsletterSubscribers);
        }, 52385(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getNextLabelId: "getNextLabelId" }, (e2) => e2.getNextLabelId);
        }, 21236(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getNumChatsPinned: ["getNumChatsPinned", "getNumConversationsPinned"] }, (e2) => e2.getNumChatsPinned || e2.getNumConversationsPinned);
        }, 29473(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getOrderInfo: "getOrderInfo" }, (e2) => e2.getOrderInfo);
        }, 55631(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getParticipants: "getParticipants" }, (e2) => e2.getParticipants && e2.addParticipants);
        }, 43520(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getPhoneLangPref: "getPhoneLangPref", setPhoneLangPref: "setPhoneLangPref" }, (e2) => e2.getPhoneLangPref && e2.setPhoneLangPref);
        }, 72216(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getPhoneNumber: "getPhoneNumber" }, (e2) => e2.getPhoneNumber);
        }, 4389(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getPrivacyDisallowedListTable: "getPrivacyDisallowedListTable" }, (e2) => e2.getPrivacyDisallowedListTable);
        }, 65130(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getPushname: "getPushname", getUserPrivacySettings: "getUserPrivacySettings" }, (e2) => e2.getPushname && e2.setBrowserId && e2.getUserPrivacySettings);
        }, 21427(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getQuotedMsgObj: "getQuotedMsgObj" }, (e2) => e2.getQuotedMsgObj);
        }, 23749(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getReactions: "getReactions" }, (e2) => e2.getReactions);
        }, 73890(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getSearchContext: "getSearchContext" }, (e2) => e2.getSearchContext);
        }, 36048(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(7222), o = r(54993);
          (0, o.exportModule)(t, { getShouldAppearInList: "getShouldAppearInList", getPreviewMessage: "getPreviewMessage", getShowChangeNumberNotification: "getShowChangeNumberNotification", getShouldShowUnreadDivider: "getShouldShowUnreadDivider" }, (e2) => e2.getShouldAppearInList && e2.getPreviewMessage && e2.getShowChangeNumberNotification && e2.getShouldShowUnreadDivider), (0, o.exportModule)(t, { getHasUnread: "getHasUnread" }, (e2) => e2.getHasUnread), (0, n.injectFallbackModule)("getShouldAppearInList", { getShouldAppearInList: (e2) => e2.shouldAppearInList, getPreviewMessage: (e2) => e2.previewMessage, getShowChangeNumberNotification: (e2) => e2.showChangeNumberNotification, getShouldShowUnreadDivider: (e2) => e2.shouldShowUnreadDivider }), (0, n.injectFallbackModule)("getHasUnread", { getHasUnread: (e2) => e2.hasUnread });
        }, 27027(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getStatusAllowList: "default.getStatusAllowList", getStatusContacts: "default.getStatusContacts", getStatusDenyList: "default.getStatusDenyList", getStatusList: "default.getStatusList", getStatusPrivacySetting: "default.getStatusPrivacySetting", getStatusPrivacySettingConfig: "default.getStatusPrivacySettingConfig", setStatusPrivacyConfig: "default.setStatusPrivacyConfig" }, (e2) => e2.default.getStatusList);
        }, 44804(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getTableVotes: ["getTable"] }, (e2) => e2.getTable.toString().includes('"poll-votes"'));
        }, 92848(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getVoipStackInterface: "getVoipStackInterface" }, (e2) => e2.getVoipStackInterface);
        }, 22696(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(7222), o = r(54993), i = r(44804), a = r(42547);
          (0, o.exportModule)(t, { getVotes: "getVotes", getVote: "getVote" }, (e2) => e2.getVotes && e2.getVote), (0, n.injectFallbackModule)("getVotes", { getVote: (e2) => e2, getVotes: async (e2) => (await (0, i.getTableVotes)().anyOf(["parentMsgKey"], e2.map((e3) => e3.toString()))).map((e3) => (0, a.voteFromDbRow)(e3)) });
        }, 41968(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getWhatsAppWebExternalBetaJoinedIdb: ["getWhatsAppWebExternalBetaJoinedIdb", "getWhatsAppWebBetaJoined"], setWhatsAppWebExternalBetaDirtyBitIdb: ["setWhatsAppWebExternalBetaDirtyBitIdb", "setWhatsAppWebBetaDirtyBit"], setWhatsAppWebExternalBetaJoinedIdb: ["setWhatsAppWebExternalBetaJoinedIdb", "setWhatsAppWebBetaJoined"] }, (e2) => e2.getWhatsAppWebExternalBetaJoinedIdb && e2.setWhatsAppWebExternalBetaDirtyBitIdb && e2.setWhatsAppWebExternalBetaJoinedIdb || e2.getWhatsAppWebBetaJoined && e2.setWhatsAppWebBetaDirtyBit && e2.setWhatsAppWebBetaJoined);
        }, 70772(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { addParticipants: "addParticipants", removeParticipants: "removeParticipants", promoteCommunityParticipants: "promoteCommunityParticipants", promoteParticipants: "promoteParticipants", demoteCommunityParticipants: "demoteCommunityParticipants", demoteParticipants: "demoteParticipants" }, (e2) => e2.addParticipants && e2.removeParticipants && e2.promoteCommunityParticipants && e2.promoteParticipants && e2.demoteCommunityParticipants && e2.demoteParticipants && !e2.updateParticipants);
        }, 2058(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(54993);
          (0, n.exportModule)(t, { handleStatusSimpleAck: ["handleStatusSimpleReceipt"], handleStatusSimpleReceipt: ["handleStatusSimpleReceipt"] }, (e2) => e2.handleStatusSimpleReceipt), (0, n.exportModule)(t, { handleChatSimpleAck: ["handleChatSimpleReceipt"], handleChatSimpleReceipt: ["handleChatSimpleReceipt"] }, (e2) => e2.handleChatSimpleReceipt), (0, n.exportModule)(t, { handleGroupSimpleAck: ["handleGroupSimpleReceipt"], handleGroupSimpleReceipt: ["handleGroupSimpleReceipt"] }, (e2) => e2.handleGroupSimpleReceipt);
        }, 96954(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { handleSingleMsg: ["handleSingleMsg"] }, (e2) => e2.handleSingleMsg);
        }, 52757(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(35674), t), o(r(72116), t), o(r(19885), t), o(r(25736), t), o(r(55889), t), o(r(50854), t), o(r(22328), t), o(r(29697), t), o(r(77082), t), o(r(71274), t), o(r(40581), t), o(r(4525), t), o(r(63548), t), o(r(58652), t), o(r(71400), t), o(r(37300), t), o(r(46915), t), o(r(15878), t), o(r(95141), t), o(r(95612), t), o(r(97718), t), o(r(7967), t), o(r(28940), t), o(r(10293), t), o(r(48441), t), o(r(25882), t), o(r(70806), t), o(r(51137), t), o(r(85882), t), o(r(82641), t), o(r(4375), t), o(r(16877), t), o(r(53008), t), o(r(32), t), o(r(61158), t), o(r(34040), t), o(r(6357), t), o(r(21892), t), o(r(34324), t), o(r(49035), t), o(r(95554), t), o(r(84874), t), o(r(40300), t), o(r(64538), t), o(r(43593), t), o(r(24444), t), o(r(85541), t), o(r(47440), t), o(r(25602), t), o(r(95524), t), o(r(92538), t), o(r(89559), t), o(r(42930), t), o(r(19553), t), o(r(79731), t), o(r(74857), t), o(r(92787), t), o(r(55072), t), o(r(86362), t), o(r(58084), t), o(r(66852), t), o(r(6281), t), o(r(54616), t), o(r(78943), t), o(r(52385), t), o(r(21236), t), o(r(29473), t), o(r(55631), t), o(r(43520), t), o(r(72216), t), o(r(4389), t), o(r(65130), t), o(r(21427), t), o(r(23749), t), o(r(73890), t), o(r(36048), t), o(r(27027), t), o(r(44804), t), o(r(92848), t), o(r(22696), t), o(r(41968), t), o(r(11782), t), o(r(70772), t), o(r(2058), t), o(r(96954), t), o(r(89336), t), o(r(35454), t), o(r(28690), t), o(r(5724), t), o(r(2931), t), o(r(1009), t), o(r(34601), t), o(r(97153), t), o(r(27981), t), o(r(24369), t), o(r(33750), t), o(r(95795), t), o(r(87071), t), o(r(46589), t), o(r(946), t), o(r(64119), t), o(r(89791), t), o(r(7016), t), o(r(97591), t), o(r(43002), t), o(r(2057), t), o(r(68593), t), o(r(56650), t), o(r(88831), t), o(r(74323), t), o(r(98799), t), o(r(68500), t), o(r(92111), t), o(r(14877), t), o(r(6678), t), o(r(58625), t), o(r(65005), t), o(r(65512), t), o(r(35154), t), o(r(51262), t), o(r(9534), t), o(r(90087), t), o(r(40469), t), o(r(33433), t), o(r(18827), t), o(r(34048), t), o(r(68278), t), o(r(1703), t), o(r(28081), t), o(r(95528), t), o(r(88856), t), o(r(76030), t), o(r(72110), t), o(r(42556), t), o(r(99544), t), o(r(10200), t), o(r(11370), t), o(r(67047), t), o(r(7882), t), o(r(76966), t), o(r(37008), t), o(r(2571), t), o(r(54649), t), o(r(63028), t), o(r(23583), t), o(r(17472), t), o(r(40502), t), o(r(97920), t), o(r(98927), t), o(r(43410), t), o(r(59502), t), o(r(98872), t), o(r(34910), t), o(r(59604), t), o(r(16541), t), o(r(35603), t), o(r(83019), t), o(r(3424), t), o(r(29044), t), o(r(80214), t), o(r(72804), t), o(r(6946), t), o(r(958), t), o(r(54530), t), o(r(84236), t), o(r(70434), t), o(r(50481), t), o(r(69758), t), o(r(24245), t), o(r(21475), t), o(r(88570), t), o(r(26206), t), o(r(43068), t), o(r(76418), t), o(r(99481), t), o(r(81657), t), o(r(33347), t), o(r(97747), t), o(r(42547), t);
        }, 89336(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { initializeAltDeviceLinking: "initializeAltDeviceLinking" }, (e2) => e2.initializeAltDeviceLinking);
        }, 35454(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { isAnimatedWebp: "isAnimatedWebp" }, (e2) => e2.isAnimatedWebp);
        }, 28690(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { isAuthenticated: ["isLoggedIn", "Z"], isLoggedIn: ["isLoggedIn", "Z"] }, (e2) => {
            var t2, r2;
            return (null === (t2 = e2.Z) || void 0 === t2 ? void 0 : t2.toString().includes("isRegistered")) && (null === (r2 = e2.Z) || void 0 === r2 ? void 0 : r2.toString().includes("getLoginTokens")) || e2.isLoggedIn;
          });
        }, 5724(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { isFilterExcludedFromSearchTreatmentInInboxFlow: "isFilterExcludedFromSearchTreatmentInInboxFlow" }, (e2) => e2.isFilterExcludedFromSearchTreatmentInInboxFlow);
        }, 2931(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { isLidMigrated: ["Lid1X1MigrationUtils.isLidMigrated"] }, (e2) => e2.Lid1X1MigrationUtils && "function" == typeof e2.Lid1X1MigrationUtils.isLidMigrated);
        }, 1009(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { isRegistered: ["isRegistered"] }, (e2) => e2.isRegistered);
        }, 34601(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { isUnreadTypeMsg: ["isUnreadTypeMsg", "isUnreadType", "getIsUnreadType"] }, (e2) => e2.isUnreadTypeMsg || e2.isUnreadType || e2.getIsUnreadType);
        }, 97153(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { isWid: "default.isWid" }, (e2) => e2.default.isWid);
        }, 27981(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { joinGroupViaInvite: "joinGroupViaInvite" }, (e2) => e2.joinGroupViaInvite && e2.resetGroupInviteCode);
        }, 24369(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { keepMessage: "keepMessage", undoKeepMessage: "undoKeepMessage" }, (e2) => e2.keepMessage);
        }, 33750(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { labelAddAction: "labelAddAction", labelDeleteAction: "labelDeleteAction", labelEditAction: "labelEditAction" }, (e2) => e2.labelAddAction && e2.labelDeleteAction && e2.labelEditAction);
        }, 95795(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getErrorCodeFromLogoutReason: "getErrorCodeFromLogoutReason", setPrevLogoutReasonCode: "setPrevLogoutReasonCode", setPrevCustomLogoutMessage: "setPrevCustomLogoutMessage", getPrevLogoutReasonCode: "getPrevLogoutReasonCode", getPrevCustomLogoutMessage: "getPrevCustomLogoutMessage" }, (e2) => e2.getErrorCodeFromLogoutReason);
        }, 87071(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(54993);
          (0, n.exportModule)(t, { markUnread: "markUnread", sendSeen: "sendSeen" }, (e2) => e2.markUnread && e2.sendSeen), (0, n.exportModule)(t, { markPlayed: "markPlayed", canMarkPlayed: "canMarkPlayed" }, (e2) => e2.markPlayed);
        }, 46589(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { md5: "md5" }, (e2) => e2.md5 && e2.md5ArrayBufferHex);
        }, 946(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { mediaTypeFromProtobuf: "mediaTypeFromProtobuf" }, (e2) => e2.mediaTypeFromProtobuf);
        }, 64119(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { membershipApprovalRequestAction: "membershipApprovalRequestAction" }, (e2) => e2.membershipApprovalRequestAction);
        }, 89791(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { mexFetchNewsletterDirectorySearchResults: "mexFetchNewsletterDirectorySearchResults" }, (e2) => e2.mexFetchNewsletterDirectorySearchResults);
        }, 7016(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { mexJoinNewsletter: "mexJoinNewsletter" }, (e2) => e2.mexJoinNewsletter);
        }, 97591(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { mexLeaveNewsletter: "mexLeaveNewsletter" }, (e2) => e2.mexLeaveNewsletter);
        }, 43002(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { msgDataFromMsgModel: "msgDataFromMsgModel" }, (e2) => e2.msgDataFromMsgModel);
        }, 2057(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { msgFindBefore: "msgFindBefore", msgFindAfter: "msgFindAfter", msgFindByDirection: "msgFindByDirection" }, (e2) => e2.msgFindByDirection && e2.msgFindBefore && e2.msgFindAfter);
        }, 68593(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { msgFindCallLog: "msgFindCallLog" }, (e2) => e2.msgFindCallLog);
        }, 56650(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { msgFindEvents: "msgFindEvents" }, (e2) => e2.msgFindEvents);
        }, 88831(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { msgFindMedia: "msgFindMedia" }, (e2) => e2.msgFindMedia);
        }, 74323(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { msgFindQuery: "msgFindQuery" }, (e2) => e2.msgFindQuery && e2.getMsgsByMsgKey || e2.msgFindQuery && e2.queryMessageType);
        }, 98799(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { msgFindSearch: "msgFindSearch" }, (e2) => e2.msgFindSearch);
        }, 68500(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { msgFindStarred: "msgFindStarred" }, (e2) => e2.msgFindStarred);
        }, 92111(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { muteNewsletter: "muteNewsletter" }, (e2) => e2.muteNewsletter);
        }, 14877(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { processRawAudioVideo: "processRawAudioVideo" }, (e2) => e2.processRawAudioVideo);
        }, 6678(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { processRawMedia: ["processRawMedia", "default"] }, (e2) => {
            var t2, r2;
            return e2.processRawMedia || (null === (r2 = null === (t2 = e2.default) || void 0 === t2 ? void 0 : t2.toString) || void 0 === r2 ? void 0 : r2.call(t2).includes("Received unsupported mediaType"));
          });
        }, 58625(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { processRawSticker: "processRawSticker" }, (e2) => e2.processRawSticker);
        }, 65512(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { productVisibilitySet: "productVisibilitySet" }, (e2) => e2.productVisibilitySet);
        }, 65005(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { addProduct: "addProduct", editProduct: "editProduct", deleteProducts: "deleteProducts", sendProductToChat: "sendProductToChat", queryCatalog: "queryCatalog", queryProduct: "queryProduct", queryProductList: "queryProductList" }, (e2) => e2.sendProductToChat);
        }, 35154(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendSetPicture: "sendSetPicture", requestDeletePicture: "requestDeletePicture" }, (e2) => e2.sendSetPicture && e2.requestDeletePicture);
        }, 51262(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { queryAllGroups: "queryAllGroups" }, (e2) => e2.queryAllGroups);
        }, 9534(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { queryGroupInviteCode: "queryGroupInviteCode" }, (e2) => e2.queryGroupInviteCode);
        }, 90087(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { queryNewsletterMetadataByJid: "queryNewsletterMetadataByJid" }, (e2) => e2.queryNewsletterMetadataByJid);
        }, 40469(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { queryOrder: "queryOrder" }, (e2, t2) => e2.queryOrder && e2.queryOrderResponse || "WAWebBizQueryOrderJob" === t2);
        }, 33433(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { randomHex: "randomHex" }, (e2) => e2.randomHex);
        }, 18827(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { randomMessageId: ["default.newId"] }, (e2) => e2.default.newId);
        }, 34048(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { removeStatusMessage: ["removeStatusMessage"] }, (e2) => e2.removeStatusMessage);
        }, 68278(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { reportSpam: "reportSpam" }, (e2) => e2.reportSpam);
        }, 1703(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { resetGroupInviteCode: "resetGroupInviteCode" }, (e2) => e2.resetGroupInviteCode);
        }, 28081(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { revokeStatus: ["default", "sendStatusRevokeMsgAction"] }, (e2, t2) => {
            var r2, n;
            return (null === (n = null === (r2 = e2.default) || void 0 === r2 ? void 0 : r2.displayName) || void 0 === n ? void 0 : n.includes("RevokeStatusAction")) || "WAWebRevokeStatusAction" === t2;
          });
        }, 95528(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { saveContactAction: "saveContactAction", saveContactActionV2: "saveContactAction" }, (e2) => e2.saveContactAction);
        }, 88856(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { selectChatForOneOnOneMessage: "selectChatForOneOnOneMessage" }, (e2) => e2.selectChatForOneOnOneMessage);
        }, 76030(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendClear: "sendClear" }, (e2) => {
            var t2, r2;
            return e2.sendClear && (null === (r2 = null === (t2 = e2.sendClear) || void 0 === t2 ? void 0 : t2.toString()) || void 0 === r2 ? void 0 : r2.includes("WAWebStateUtils"));
          });
        }, 72110(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendCreateCommunity: "sendCreateCommunity", sendDeactivateCommunity: "sendDeactivateCommunity", sendLinkSubgroups: "sendLinkSubgroups", sendUnlinkSubgroups: "sendUnlinkSubgroups" }, (e2) => e2.sendCreateCommunity);
        }, 42556(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(75828), u = a(r(7222)), c = r(19198), l = r(54993), d = r(97718);
          (0, l.exportModule)(t, { sendCreateGroup: "sendCreateGroup" }, (e2) => e2.sendCreateGroup), u.injectFallbackModule("sendCreateGroup", { sendCreateGroup: async (e2, t2, r2, n2) => (0, s.compare)(c.SANITIZED_VERSION_STR, "2.3000.1027323699", ">=") ? await (0, d.createGroup)({ title: e2, ephemeralDuration: r2 || 0, restrict: true, announce: true, membershipApprovalMode: false, memberAddMode: true, parentGroupId: n2 }, t2.map((e3) => ({ phoneNumber: e3 }))).then((e3) => ({ gid: e3.wid, participants: e3.participants.map((e4) => ({ userWid: e4.wid, code: null != e4.error ? e4.error.toString() : "200", invite_code: e4.invite_code, invite_code_exp: e4.invite_code_exp })) })) : await (0, d.createGroup)({ title: e2, ephemeralDuration: r2 || 0, restrict: true, announce: true, membershipApprovalMode: false, memberAddMode: true, parentGroupId: n2 }, t2).then((e3) => ({ gid: e3.wid, participants: e3.participants.map((e4) => ({ userWid: e4.wid, code: null != e4.error ? e4.error.toString() : "200", invite_code: e4.invite_code, invite_code_exp: e4.invite_code_exp })) })) });
        }, 99544(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendDelete: "sendDelete" }, (e2) => e2.sendDelete);
        }, 10200(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendExitGroup: "sendExitGroup" }, (e2) => e2.sendExitGroup);
        }, 11370(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendAddParticipants: ["sendAddParticipants", "addGroupParticipants"], sendRemoveParticipants: ["sendRemoveParticipants", "removeGroupParticipants"], sendPromoteParticipants: ["sendPromoteParticipants", "promoteGroupParticipants"], sendDemoteParticipants: ["sendDemoteParticipants", "demoteGroupParticipants"] }, (e2) => e2.sendAddParticipants && e2.sendRemoveParticipants && e2.sendPromoteParticipants && e2.sendDemoteParticipants || e2.addGroupParticipants && e2.removeGroupParticipants && e2.promoteGroupParticipants && e2.demoteGroupParticipants);
        }, 67047(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = r(64456), u = a(r(7222)), c = r(14647), l = r(54993), d = r(27981);
          (0, l.exportModule)(t, { sendJoinGroupViaInvite: "sendJoinGroupViaInvite" }, (e2) => e2.sendJoinGroupViaInvite), u.injectFallbackModule("sendJoinGroupViaInvite", { sendJoinGroupViaInvite: async (e2) => {
            const t2 = await (0, s.getGroupInfoFromInviteCode)(e2), r2 = c.ChatStore.get(t2.id.toString());
            if (r2) {
              if (await (0, s.iAmMember)(t2.id.toString())) return { gid: r2.id, membershipApprovalMode: false };
            }
            return { gid: (await (0, d.joinGroupViaInvite)(e2, t2.membershipApprovalMode)).gid, membershipApprovalMode: t2.membershipApprovalMode };
          } });
        }, 7882(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendNewsletterMessageJob: ["sendNewsletterMessageJob", "sendNewsletterMessage"] }, (e2) => e2.sendNewsletterMessageJob || e2.sendNewsletterMessage);
        }, 76966(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendOrderStatusMessageAsMerchant: "sendOrderStatusMessageAsMerchant" }, (e2) => e2.sendOrderStatusMessageAsMerchant && e2.sendOrderPaymentStatusMessageAsMerchant);
        }, 37008(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendPinInChatMsg: "sendPinInChatMsg" }, (e2) => e2.sendPinInChatMsg);
        }, 2571(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { queryWidExists: ["queryWidExists"] }, (e2) => e2.queryWidExists && e2.queryPhoneExists);
        }, 54649(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendQueryGroupInvite: "sendQueryGroupInvite" }, (e2) => e2.sendQueryGroupInvite);
        }, 63028(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = a(r(7222)), u = r(54993), c = r(52757);
          (0, u.exportModule)(t, { sendQueryGroupInviteCode: "sendQueryGroupInviteCode" }, (e2) => e2.sendQueryGroupInviteCode), s.injectFallbackModule("sendQueryGroupInviteCode", { sendQueryGroupInviteCode: async (e2) => await (0, c.fetchMexGroupInviteCode)(e2) });
        }, 23583(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { queryUsernameExists: ["queryUsernameExists"] }, (e2) => e2.queryUsernameExists);
        }, 17472(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendReactionToMsg: "sendReactionToMsg" }, (e2) => e2.sendReactionToMsg);
        }, 40502(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = a(r(7222)), u = r(54993), c = r(1703);
          (0, u.exportModule)(t, { sendRevokeGroupInviteCode: "sendRevokeGroupInviteCode" }, (e2) => e2.sendRevokeGroupInviteCode), s.injectFallbackModule("sendRevokeGroupInviteCode", { sendRevokeGroupInviteCode: async (e2) => await (0, c.resetGroupInviteCode)(e2).then((e3) => e3.code) });
        }, 97920(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendTextMsgToChat: "sendTextMsgToChat" }, (e2) => e2.sendTextMsgToChat);
        }, 98927(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { setArchive: "setArchive" }, (e2) => e2.setArchive);
        }, 43410(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendSetGroupSubject: ["sendSetGroupSubject", "setGroupSubject"], sendSetGroupDescription: ["sendSetGroupDescription", "setGroupDescription"], sendSetGroupProperty: ["sendSetGroupProperty", "setGroupProperty"] }, (e2) => e2.sendSetGroupSubject && e2.sendSetGroupDescription && e2.sendSetGroupProperty || e2.setGroupSubject && e2.setGroupDescription && e2.setGroupProperty);
        }, 59502(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { setPin: "setPin" }, (e2) => e2.setPin && !e2.unpinAll && !e2.getPinLimit);
        }, 98872(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { setPrivacyForOneCategory: "setPrivacyForOneCategory" }, (e2) => e2.setPrivacyForOneCategory);
        }, 34910(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { setPushname: "setPushname" }, (e2) => e2.setPushname && !e2.setBrowserId);
        }, 59604(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { shouldHaveAccountLid: ["shouldHaveAccountLid"] }, (e2) => "function" == typeof e2.shouldHaveAccountLid);
        }, 16541(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { startWAWebVoipCall: "startWAWebVoipCall" }, (e2) => e2.startWAWebVoipCall);
        }, 35603(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getStatus: "getStatus", setMyStatus: "setMyStatus" }, (e2) => e2.getStatus && e2.setMyStatus && e2.queryStatusAll);
        }, 3424(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { primaryFeatureEnabled: "primaryFeatureEnabled" }, (e2) => e2.primaryFeatureEnabled);
        }, 29044(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(54993);
          (0, n.exportModule)(t, { subscribePresence: ["subscribePresence", "subscribeUserPresence"] }, (e2, t2) => "WAWebContactPresenceBridge" === t2 || !(!e2.subscribePresence && !e2.subscribeUserPresence)), (0, n.exportModule)(t, { subscribeGroupPresence: "subscribeGroupPresence" }, (e2) => !!e2.subscribeGroupPresence);
        }, 80214(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { syncABPropsTask: "syncABPropsTask" }, (e2) => e2.syncABPropsTask);
        }, 6946(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { toUserLid: ["toUserLid", "toUserLidOrThrow"], toUserLidOrThrow: "toUserLidOrThrow" }, (e2) => e2.toUserLid || e2.toUserLidOrThrow);
        }, 72804(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { toggleNewsletterAdminActivityMuteStateAction: "toggleNewsletterAdminActivityMuteStateAction" }, (e2) => e2.toggleNewsletterAdminActivityMuteStateAction);
        }, 958(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { typeAttributeFromProtobuf: "typeAttributeFromProtobuf" }, (e2) => e2.typeAttributeFromProtobuf);
        }, 54530(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(54993);
          let o = false;
          (0, n.exportModule)(t, { unixTime: ["unixTime", "Clock.globalUnixTime"], unixTimeMs: ["unixTimeMs", "Clock.globalUnixTimeMilliseconds"] }, (e2) => {
            var t2, r2;
            return !!e2.unixTime || (!o && (null === (t2 = e2.Clock) || void 0 === t2 ? void 0 : t2.globalUnixTime) && (o = true, e2.Clock.globalUnixTime = e2.Clock.globalUnixTime.bind(e2.Clock), e2.Clock.globalUnixTimeMilliseconds = e2.Clock.globalUnixTimeMilliseconds.bind(e2.Clock)), null === (r2 = e2.Clock) || void 0 === r2 ? void 0 : r2.globalUnixTime);
          });
        }, 84236(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { unmuteNewsletter: "unmuteNewsletter" }, (e2) => e2.unmuteNewsletter);
        }, 70434(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { updateCart: "updateCart" }, (e2) => e2.updateCart);
        }, 50481(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { updateCartEnabled: "updateCartEnabled" }, (e2) => e2.updateCartEnabled);
        }, 69758(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { updateDBForGroupAction: ["updateDBForGroupAction", "handleGroupActionMD"] }, (e2) => e2.updateDBForGroupAction || e2.handleGroupActionMD);
        }, 24245(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { updateMessageTable: "updateMessageTable" }, (e2) => e2.updateMessageTable);
        }, 21475(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { updateNewsletterMsgRecord: "updateNewsletterMsgRecord", addNewsletterMsgsRecords: "addNewsletterMsgsRecords" }, (e2) => e2.updateNewsletterMsgRecord);
        }, 88570(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { updateParticipants: "updateParticipants" }, (e2) => e2.updateParticipants && e2.addParticipants);
        }, 26206(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { uploadMedia: "uploadMedia" }, (e2) => e2.uploadMedia);
        }, 43068(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { uploadProductImage: "uploadProductImage" }, (e2) => e2.uploadProductImage && e2.MediaPrep);
        }, 76418(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = a(r(7222));
          (0, r(54993).exportModule)(t, { uploadThumbnail: "default" }, (e2, t2) => {
            if ("WAWebMediaUploadMmsThumbnail" === t2) return true;
            const r2 = s.moduleSource(t2);
            return r2.includes("thumbnail") && r2.includes(".cancelUploadMedia") && r2.includes(".calculateFilehashFromBlob");
          });
        }, 99481(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { upsertVotes: ["upsertVotesDb", "upsertVotes"] }, (e2) => e2.upsertVotesDb || e2.upsertVotes);
        }, 81657(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { useExternalBetaOptIn: "useExternalBetaOptIn" }, (e2) => e2.useExternalBetaOptIn);
        }, 33347(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { requireVoipJsBackend: "requireVoipJsBackend" }, (e2) => e2.requireVoipJsBackend);
        }, 97747(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { isCallingEnabled: "isCallingEnabled", isUnsupportedBrowserForWebCalling: "isUnsupportedBrowserForWebCalling", isVoipDownloadEnabled: "isVoipDownloadEnabled", getUnsupportedBrowserReason: "getUnsupportedBrowserReason" }, (e2) => e2.isCallingEnabled && e2.isVoipDownloadEnabled);
        }, 42547(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { voteFromDbRow: ["voteFromDbRow"] }, (e2) => e2.voteFromDbRow);
        }, 14647(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || o(t2, e2, r2);
          }, s = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true }), t.websocket = t.multidevice = t.functions = t._moduleIdMap = t.enums = t.contants = void 0, a(r(12105), t), t.contants = s(r(19198)), t.enums = s(r(20514));
          var u = r(54993);
          Object.defineProperty(t, "_moduleIdMap", { enumerable: true, get: function() {
            return u._moduleIdMap;
          } }), t.functions = s(r(52757)), a(r(45588), t), a(r(51990), t), t.multidevice = s(r(83703)), a(r(40649), t), a(r(70754), t), t.websocket = s(r(57411));
        }, 19170(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "ApiContact", (e2) => e2.getCurrentLid && e2.getPhoneNumber);
        }, 50294(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { BackendEvent: "BackendEvent", BackendEventBus: "BackendEventBus" }, (e2) => e2.BackendEventBus && e2.BackendEvent);
        }, 84513(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "Base64", (e2) => e2.encodeB64 && e2.decodeB64);
        }, 48212(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { Browser: "default" }, (e2) => e2.default.id && e2.default.startDownloading);
        }, 91033(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "ChatPresence", (e2) => e2.markComposing);
        }, 35276(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { CmdClass: "CmdImpl", Cmd: "Cmd" }, (e2) => e2.Cmd && e2.CmdImpl);
        }, 46820(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ComposeBoxActions: "ComposeBoxActions" }, (e2) => e2.ComposeBoxActions);
        }, 19336(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { Conn: "Conn" }, (e2) => e2.Conn && e2.ConnImpl || e2.Conn);
        }, 42865(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { Constants: "default" }, (e2) => e2.default.IMG_THUMB_MAX_EDGE || e2.default.WA_COMMERCE_POLICY_URL);
        }, 38627(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "Enviroment", (e2) => void 0 !== e2.default.isWeb && void 0 !== e2.default.isWindows || void 0 !== e2.isWeb && void 0 !== e2.isWindows);
        }, 26740(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { EventEmitter: "default" }, (e2, t2) => "WAWebEventEmitter" === t2 || e2.default.toString().includes("Callback parameter passed is not a function"));
        }, 33216(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "ImageUtils", (e2) => e2.rotateAndResize);
        }, 47868(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = a(r(7222));
          (0, r(54993).exportModule)(t, "IsOfficialClient", (e2) => void 0 !== e2.isOfficialClient), s.injectFallbackModule("IsOfficialClient", { isOfficialClient: true });
        }, 95604(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { Lid1X1MigrationUtils: "Lid1X1MigrationUtils" }, (e2) => e2.Lid1X1MigrationUtils.isLidMigrated);
        }, 28117(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { lidPnCache: "lidPnCache" }, (e2) => e2.lidPnCache);
        }, 92448(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { LruMediaStore: "LruMediaStore" }, (e2) => e2.LruMediaStore && "function" == typeof e2.LruMediaStore.get && "function" == typeof e2.LruMediaStore.put && "function" == typeof e2.LruMediaStore.del && "function" == typeof e2.LruMediaStore.clear && "function" == typeof e2.LruMediaStore.count && "function" == typeof e2.LruMediaStore.has);
        }, 4749(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { MediaBlobCacheImpl: ["InMemoryMediaBlobCacheImpl", "MediaBlobCacheImpl"], MediaBlobCache: ["InMemoryMediaBlobCache", "MediaBlobCache"] }, (e2) => e2.InMemoryMediaBlobCacheImpl || e2.MediaBlobCache);
        }, 32974(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { MediaEntry: ["EncryptedMediaEntry", "MediaEntry"] }, (e2) => e2.EncryptedMediaEntry || e2.MediaEntry);
        }, 36939(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "MediaGatingUtils", (e2) => e2.getUploadLimit && "function" == typeof e2.getUploadLimit);
        }, 78959(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { MediaObject: "MediaObject" }, (e2) => e2.webMediaTypeToWamMediaType);
        }, 69675(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "MediaObjectUtil", (e2) => e2.getOrCreateMediaObject);
        }, 91911(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "MediaPrep", (e2) => e2.uploadProductImage && e2.MediaPrep);
        }, 33115(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "MediaUtils", (e2) => e2.getImageWidthHeight);
        }, 18358(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { MsgKey: "default" }, (e2) => {
            var t2, r2;
            if (!(null === (t2 = null == e2 ? void 0 : e2.default) || void 0 === t2 ? void 0 : t2.toString().includes("MsgKey error: obj is null/undefined"))) return false;
            try {
              const t3 = e2.default.prototype, n = null === (r2 = /\breturn this\.([$A-Za-z_][\w$]*)/.exec(Function.prototype.toString.call(t3.toString))) || void 0 === r2 ? void 0 : r2[1];
              if (n && "_serialized" !== n && !Object.getOwnPropertyDescriptor(t3, n)) {
                const e3 = (e4, t4) => {
                  Object.defineProperty(e4, "_serialized", { value: t4, writable: true, enumerable: true, configurable: true });
                }, r3 = (t4) => {
                  const r4 = Object.getOwnPropertyDescriptor(t4, n);
                  r4 && (delete t4[n], e3(t4, r4.value));
                };
                Object.defineProperty(t3, n, { configurable: true, get: function() {
                  return this._serialized;
                }, set: function(t4) {
                  e3(this, t4);
                } }), Object.defineProperty(t3, "_serialized", { configurable: true, get: function() {
                  var e4;
                  return r3(this), null === (e4 = Object.getOwnPropertyDescriptor(this, "_serialized")) || void 0 === e4 ? void 0 : e4.value;
                }, set: function(t4) {
                  e3(this, t4);
                } });
                const o = t3.toString;
                t3.toString = function() {
                  return r3(this), o.call(this);
                }, "toJSON" in t3 || Object.defineProperty(t3, "toJSON", { configurable: true, writable: true, value: function() {
                  return r3(this), this;
                } });
              }
            } catch (e3) {
            }
            return true;
          });
        }, 36061(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { MsgLoad: "ChatMsgsCollection" }, (e2) => e2.ChatMsgsCollection);
        }, 19424(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { NetworkStatus: "default" }, (e2) => e2.default.checkOnline);
        }, 84229(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(54993);
          (0, n.exportModule)(t, { OpaqueDataBase: "default" }, (e2) => e2.default.prototype.throwIfReleased), (0, n.exportModule)(t, { OpaqueData: "default" }, (e2) => e2.default.createFromData);
        }, 74070(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ProductCatalogSession: "ProductCatalogSession" }, (e2) => e2.ProductCatalogSession);
        }, 65931(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(7222), o = r(54993), i = r(35562);
          (0, o.exportModule)(t, { ServerProps: "ServerProps" }, (e2) => e2.getMaxFilesSizeServerProp && e2.ServerProps || e2.getMaxFilesSize && e2.ServerProps), (0, n.injectFallbackModule)("ServerProps", { getMaxFilesSizeServerProp: () => i.ServerPropsConstants.MAX_FILE_SIZE_BYTES, ServerProps: {} });
        }, 35562(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          const n = r(7222), o = r(54993), i = r(65931);
          (0, o.exportModule)(t, "ServerPropsConstants", (e2) => e2.MAX_FILE_SIZE_BYTES), (0, n.injectFallbackModule)("ServerPropsConstants", { MMS_VCARD_AUTODOWNLOAD_SIZE_KB: 64, VCARD_AS_DOCUMENT_SIZE_KB: 64, VCARD_MAX_SIZE_KB: 5e3, MULTICAST_LIMIT_GLOBAL: (null === i.ServerProps || void 0 === i.ServerProps ? void 0 : i.ServerProps.frequentlyForwardedMax) || 5, PTT_PLAYBACK_SPEED_HIDE_DELAY: 1500, DEFAULT_MAX_FILE_SIZE_BYTES: 104857600, MAX_FILE_SIZE_BYTES: (null === i.ServerProps || void 0 === i.ServerProps ? void 0 : i.ServerProps.maxFileSize) || 104857600, UNINITIALIZED_VALUE_WEB_BIZ_PROFILE_OPTIONS: 3 });
        }, 82183(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { Socket: "Socket" }, (e2) => e2.Socket);
        }, 40302(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { Stream: "Stream" }, (e2) => e2.Stream);
        }, 32122(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { USyncQuery: "USyncQuery" }, (e2) => e2.USyncQuery);
        }, 59659(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { USyncUser: "USyncUser" }, (e2) => e2.USyncUser);
        }, 43871(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "UserPrefs", (e2) => {
            var t2, r2;
            const n = "function" == typeof (null == e2 ? void 0 : e2.getMaybeMePnUser), o = "function" == typeof (null == e2 ? void 0 : e2.getMaybeMeUser);
            if (!n && !o) return false;
            try {
              if (e2 && "function" != typeof e2.getMaybeMeUser && (null === (t2 = e2.hasOwnProperty) || void 0 === t2 ? void 0 : t2.call(e2, "getMaybeMeUser"))) try {
                delete e2.getMaybeMeUser;
              } catch (e3) {
              }
              if (e2 && "function" != typeof e2.getMaybeMePnUser && (null === (r2 = e2.hasOwnProperty) || void 0 === r2 ? void 0 : r2.call(e2, "getMaybeMePnUser"))) try {
                delete e2.getMaybeMePnUser;
              } catch (e3) {
              }
              n && !o ? Object.defineProperty(e2, "getMaybeMeUser", { value: e2.getMaybeMePnUser.bind(e2), configurable: true, writable: true }) : o && !n && Object.defineProperty(e2, "getMaybeMePnUser", { value: e2.getMaybeMeUser.bind(e2), configurable: true, writable: true });
            } catch (e3) {
            }
            return true;
          });
        }, 90167(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { getAutoDownloadPhotos: "getAutoDownloadPhotos", setAutoDownloadPhotos: "setAutoDownloadPhotos", getAutoDownloadAudio: "getAutoDownloadAudio", setAutoDownloadAudio: "setAutoDownloadAudio", getAutoDownloadVideos: "getAutoDownloadVideos", setAutoDownloadVideos: "setAutoDownloadVideos", getAutoDownloadDocuments: "getAutoDownloadDocuments", setAutoDownloadDocuments: "setAutoDownloadDocuments", getTheme: "getTheme", setTheme: "setTheme" }, (e2) => e2.getAutoDownloadPhotos && e2.setAutoDownloadPhotos && e2.getTheme);
        }, 70924(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "VCard", (e2) => e2.vcardFromContactModel);
        }, 94484(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { Wid: "default" }, (e2) => e2.default.isXWid);
        }, 43996(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "WidFactory", (e2) => e2.createWid);
        }, 45588(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(19170), t), o(r(50294), t), o(r(84513), t), o(r(48212), t), o(r(91033), t), o(r(35276), t), o(r(46820), t), o(r(19336), t), o(r(42865), t), o(r(38627), t), o(r(26740), t), o(r(33216), t), o(r(47868), t), o(r(95604), t), o(r(28117), t), o(r(92448), t), o(r(4749), t), o(r(32974), t), o(r(36939), t), o(r(78959), t), o(r(69675), t), o(r(91911), t), o(r(33115), t), o(r(18358), t), o(r(36061), t), o(r(19424), t), o(r(84229), t), o(r(74070), t), o(r(65931), t), o(r(35562), t), o(r(82183), t), o(r(40302), t), o(r(43871), t), o(r(90167), t), o(r(32122), t), o(r(59659), t), o(r(70924), t), o(r(94484), t), o(r(43996), t);
        }, 10298(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "AggReactionsModel");
        }, 38656(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "AttachMediaModel");
        }, 27502(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "BlocklistModel");
        }, 94805(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "BotProfileModel");
        }, 51478(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "BusinessCategoriesResultModel");
        }, 33436(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "BusinessProfileModel");
        }, 98651(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { CallModel: "default" }, (e2, t2) => {
            var r2, n, o, i, a, s;
            return "WAWebCallModel" === t2 || ["call", "Call"].includes((null === (n = null === (r2 = e2.default) || void 0 === r2 ? void 0 : r2.prototype) || void 0 === n ? void 0 : n.proxyName) || (null === (i = null === (o = e2.CallModel) || void 0 === o ? void 0 : o.prototype) || void 0 === i ? void 0 : i.proxyName) || (null === (s = null === (a = e2.Call) || void 0 === a ? void 0 : a.prototype) || void 0 === s ? void 0 : s.proxyName));
          });
        }, 5424(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "CartItemModel");
        }, 55001(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "CartModel");
        }, 84424(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "CatalogModel");
        }, 19717(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "ChatModel");
        }, 28702(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "ChatPreferenceModel");
        }, 57516(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ChatstateModel: "Chatstate" }, (e2) => e2.Chatstate && e2.ChatstateCollection || e2.Chatstate);
        }, 27961(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ConnModel: ["ConnImpl", "Conn"] }, (e2) => e2.ConnImpl || e2.Conn && !e2.ConnImpl);
        }, 89853(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "ContactModel");
        }, 39467(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "ConversionTupleModel");
        }, 52710(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "EmojiVariantModel");
        }, 84291(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "GroupMetadataModel");
        }, 43669(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = a(r(7222)), u = r(54993), c = r(52757);
          (0, u.exportModule)(t, { HistorySyncProgressModel: "HistorySyncProgressModel" }, (e2) => e2.HistorySyncProgressModel);
          const l = {};
          Object.defineProperty(l, "HistorySyncProgressModel", { configurable: true, enumerable: true, get: () => (0, c.getHistorySyncProgress)().constructor }), s.injectFallbackModule("HistorySyncProgressModel", l);
        }, 74910(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "LabelItemModel");
        }, 30207(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "LabelModel");
        }, 67437(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "MediaDataModel");
        }, 8375(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { Model: "BaseModel" }, (e2) => e2.defineModel);
        }, 29836(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ModelChatBase: "default" }, (e2, t2) => "WAWebSuperChatMsgs" === t2 || e2.default.toString().includes("onEmptyMRM not implemented"));
        }, 35717(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "MsgButtonReplyMsgModel");
        }, 41202(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "MsgInfoModel");
        }, 88753(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "MsgInfoParticipantModel");
        }, 99090(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "MsgModel");
        }, 51868(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "MuteModel");
        }, 17993(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { NetworkStatusModel: "default.constructor" }, (e2) => e2.default.checkOnline);
        }, 76959(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "NoteModel");
        }, 40688(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "OrderItemModel");
        }, 55961(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "OrderModel");
        }, 88758(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "ParticipantModel");
        }, 53356(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { PresenceModel: "Presence" }, (e2) => e2.Presence && e2.ChatstateCollection || e2.Presence && e2.Chatstate);
        }, 62078(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "ProductCollModel");
        }, 60771(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "ProductImageModel");
        }, 11685(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ProductMessageListModel: "ProductMessageList" }, (e2) => e2.ProductMessageList);
        }, 68364(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "ProductModel");
        }, 18486(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "ProfilePicThumbModel");
        }, 76520(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "QuickReplyModel");
        }, 37285(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "ReactionsModel");
        }, 83497(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "ReactionsSendersModel");
        }, 49040(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "RecentEmojiModel");
        }, 56875(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "RecentStickerModel");
        }, 42217(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "ReplyButtonModel");
        }, 23752(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ServerPropsModel: "ServerProps" }, (e2) => e2.getMaxFilesSizeServerProp && e2.ServerProps || e2.getMaxFilesSize && e2.ServerProps);
        }, 38428(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { Socket: "Socket.constructor" }, (e2, t2) => {
            var r2;
            return (null === (r2 = e2.Socket) || void 0 === r2 ? void 0 : r2.initConn) || "WAWebSocketModel" === t2;
          });
        }, 8489(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { StatusModel: ["default"] }, (e2) => {
            var t2;
            return null === (t2 = e2.default) || void 0 === t2 ? void 0 : t2.prototype.__props.includes("status");
          });
        }, 77104(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { StatusV3Model: ["default"] }, (e2) => {
            var t2;
            return null === (t2 = e2.default) || void 0 === t2 ? void 0 : t2.prototype.sendReadStatus;
          });
        }, 4268(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "StickerModel");
        }, 45287(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "StickerPackModel");
        }, 15567(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { StreamModel: "Stream.constructor" }, (e2) => e2.Stream);
        }, 30781(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "TemplateButtonModel");
        }, 25468(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportProxyModel)(t, "UnreadMentionModel");
        }, 51990(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(10298), t), o(r(38656), t), o(r(27502), t), o(r(94805), t), o(r(51478), t), o(r(33436), t), o(r(98651), t), o(r(5424), t), o(r(55001), t), o(r(84424), t), o(r(19717), t), o(r(28702), t), o(r(57516), t), o(r(27961), t), o(r(89853), t), o(r(39467), t), o(r(52710), t), o(r(84291), t), o(r(43669), t), o(r(74910), t), o(r(30207), t), o(r(67437), t), o(r(8375), t), o(r(29836), t), o(r(35717), t), o(r(41202), t), o(r(88753), t), o(r(99090), t), o(r(51868), t), o(r(17993), t), o(r(76959), t), o(r(40688), t), o(r(55961), t), o(r(88758), t), o(r(88758), t), o(r(53356), t), o(r(62078), t), o(r(60771), t), o(r(11685), t), o(r(68364), t), o(r(18486), t), o(r(76520), t), o(r(37285), t), o(r(83497), t), o(r(49040), t), o(r(56875), t), o(r(42217), t), o(r(23752), t), o(r(38428), t), o(r(8489), t), o(r(77104), t), o(r(4268), t), o(r(45287), t), o(r(15567), t), o(r(30781), t), o(r(25468), t);
        }, 1570(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, "adv", (e2) => e2.getADVSecretKey && e2.setADVSignedIdentity);
        }, 83703(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(1570), t), o(r(91921), t), o(r(60154), t);
        }, 91921(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { waNoiseInfo: "waNoiseInfo" }, (e2) => e2.waNoiseInfo);
        }, 60154(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { waSignalStore: "waSignalStore" }, (e2) => e2.waSignalStore);
        }, 40649(e, t, r) {
          "use strict";
          var n, o = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), i = this && this.__setModuleDefault || (Object.create ? function(e2, t2) {
            Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
          } : function(e2, t2) {
            e2.default = t2;
          }), a = this && this.__importStar || (n = function(e2) {
            return n = Object.getOwnPropertyNames || function(e3) {
              var t2 = [];
              for (var r2 in e3) Object.prototype.hasOwnProperty.call(e3, r2) && (t2[t2.length] = r2);
              return t2;
            }, n(e2);
          }, function(e2) {
            if (e2 && e2.__esModule) return e2;
            var t2 = {};
            if (null != e2) for (var r2 = n(e2), a2 = 0; a2 < r2.length; a2++) "default" !== r2[a2] && o(t2, e2, r2[a2]);
            return i(t2, e2), t2;
          });
          Object.defineProperty(t, "__esModule", { value: true });
          const s = a(r(12105)), u = r(54993), c = ["BlocklistStore", "BusinessCategoriesResultStore", "BusinessProfileStore", "CallStore", "CartStore", "CatalogStore", "ChatStore", "ContactStore", "EmojiVariantStore", "GroupMetadataStore", "LabelStore", "MsgStore", "MsgInfoStore", "MuteStore", "OrderStore", "PinInChatStore", "PresenceStore", "ProductMessageListStore", "ProfilePicThumbStore", "QuickReplyStore", "ReactionsStore", "RecentEmojiStore", "StatusStore", "StatusV3Store", "StickerStore", "StickerSearchStore"];
          for (const e2 of c) {
            const r2 = e2.replace("Store", "Collection");
            (0, u.exportModule)(t, { [e2]: ["default", r2] }, (e3) => (e3.default || e3[r2]) instanceof s[r2]);
          }
          (0, u.exportModule)(t, { RecentStickerStore: ["default", "RecentStickerCollectionMd", "RecentStickerCollection"] }, (e2) => e2.RecentStickerCollection), (0, u.exportModule)(t, { StarredMsgStore: ["default", "AllStarredMsgsCollection"] }, (e2) => e2.StarredMsgCollection), (0, u.exportModule)(t, { StickerPackStore: ["default", "StickerPackCollectionMd", "StickerPackCollection"] }, (e2) => e2.StickerPackCollection), (0, u.exportModule)(t, { NewsletterStore: "default" }, (e2, t2) => "WAWebNewsletterCollection" === t2 && e2.default), (0, u.exportModule)(t, { StatusStore: "TextStatusCollection" }, (e2) => e2.TextStatusCollection), (0, u.exportModule)(t, { StatusV3Store: ["StatusV3Collection", "StatusCollection"] }, (e2) => e2.StatusV3CollectionImpl || e2.StatusCollection), (0, u.exportModule)(t, { BlocklistStore: ["default", "BlocklistCollection"] }, (e2) => e2.BlocklistCollection), (0, u.exportModule)(t, { PresenceStore: ["PresenceCollectionImpl", "PresenceCollection"] }, (e2) => e2.PresenceCollectionImpl || e2.PresenceCollection), (0, u.exportModule)(t, { CartStore: ["CartCollectionImpl", "CartCollection"] }, (e2) => e2.CartCollectionImpl || e2.CartCollection), (0, u.exportModule)(t, { CatalogStore: ["CatalogCollectionImpl", "CatalogCollection"] }, (e2) => e2.CatalogCollectionImpl || e2.CatalogCollection), (0, u.exportModule)(t, { EmojiVariantStore: ["EmojiVariantCollectionImpl", "EmojiVariantCollection"] }, (e2) => e2.EmojiVariantCollectionImpl || e2.EmojiVariantCollection), (0, u.exportModule)(t, { LabelStore: ["LabelCollectionImpl", "LabelCollection"] }, (e2) => e2.LabelCollectionImpl || e2.LabelCollection), (0, u.exportModule)(t, { MsgInfoStore: ["MsgInfoCollectionImpl", "MsgInfoCollection"] }, (e2) => e2.MsgInfoCollectionImpl || e2.MsgInfoCollection), (0, u.exportModule)(t, { MuteStore: ["MuteCollectionImpl", "MuteCollection"] }, (e2) => e2.MuteCollectionImpl || e2.MuteCollection), (0, u.exportModule)(t, { OrderStore: ["OrderCollectionImpl", "OrderCollection"] }, (e2) => e2.OrderCollectionImpl || e2.OrderCollection), (0, u.exportModule)(t, { PinInChatStore: ["PinInChatCollectionImpl", "PinInChatCollection"] }, (e2) => e2.PinInChatCollectionImpl || e2.PinInChatCollection), (0, u.exportModule)(t, { ProductMessageListStore: ["ProductMessageListCollectionImpl", "ProductMessageListCollection"] }, (e2) => e2.ProductMessageListCollectionImpl || e2.ProductMessageListCollection), (0, u.exportModule)(t, { RecentEmojiStore: ["RecentEmojiCollectionImpl", "RecentEmojiCollection"] }, (e2) => e2.RecentEmojiCollectionImpl || e2.RecentEmojiCollection), (0, u.exportModule)(t, { StickerSearchStore: ["StickerSearchCollectionImpl", "StickerSearchCollection"] }, (e2) => e2.StickerSearchCollectionImpl || e2.StickerSearchCollection), (0, u.exportModule)(t, { BusinessProfileStore: ["BusinessProfileCollectionImpl", "BusinessProfileCollection"] }, (e2) => e2.BusinessProfileCollectionImpl || e2.BusinessProfileCollection), (0, u.exportModule)(t, { BotProfileStore: ["BotProfileCollection"] }, (e2) => e2.BotProfileCollection), (0, u.exportModule)(t, { ProfilePicThumbStore: ["ProfilePicThumbCollection", "ProfilePicThumbCollectionImpl"] }, (e2) => e2.ProfilePicThumbCollection || e2.ProfilePicThumbCollectionImpl), (0, u.exportModule)(t, { QuickReplyStore: ["QuickReplyCollectionImpl", "QuickReplyCollection"] }, (e2) => e2.QuickReplyCollectionImpl || e2.QuickReplyCollection), (0, u.exportModule)(t, { NoteStore: ["NoteCollection"] }, (e2) => e2.NoteCollection), (0, u.exportModule)(t, { ReactionsStore: ["ReactionsCollectionImpl", "ReactionsCollection"] }, (e2) => e2.ReactionsCollectionImpl || e2.ReactionsCollection), (0, u.exportModule)(t, { ChatStore: ["ChatCollection"] }, (e2) => e2.ChatCollection);
        }, 70754(e, t) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
        }, 34439(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { WapNode: "WapNode" }, (e2) => e2.WapNode);
        }, 57346(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { ensureE2ESessions: "ensureE2ESessions" }, (e2) => e2.ensureE2ESessions);
        }, 12045(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { generateId: "generateId" }, (e2) => e2.generateId);
        }, 57411(e, t, r) {
          "use strict";
          var n = this && this.__createBinding || (Object.create ? function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2);
            var o2 = Object.getOwnPropertyDescriptor(t2, r2);
            o2 && !("get" in o2 ? !t2.__esModule : o2.writable || o2.configurable) || (o2 = { enumerable: true, get: function() {
              return t2[r2];
            } }), Object.defineProperty(e2, n2, o2);
          } : function(e2, t2, r2, n2) {
            void 0 === n2 && (n2 = r2), e2[n2] = t2[r2];
          }), o = this && this.__exportStar || function(e2, t2) {
            for (var r2 in e2) "default" === r2 || Object.prototype.hasOwnProperty.call(t2, r2) || n(t2, e2, r2);
          };
          Object.defineProperty(t, "__esModule", { value: true }), o(r(57346), t), o(r(12045), t), o(r(82257), t), o(r(82590), t), o(r(49440), t), o(r(81894), t), o(r(6123), t), o(r(34439), t);
        }, 82257(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { sendSmaxStanza: "sendSmaxStanza" }, (e2) => e2.sendSmaxStanza);
        }, 82590(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { smax: "smax" }, (e2) => e2.smax);
        }, 49440(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { startWebComms: "startWebComms" }, (e2) => e2.startWebComms);
        }, 81894(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { stopComms: "stopComms", startHandlingRequests: "startHandlingRequests" }, (e2) => e2.stopComms);
        }, 6123(e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: true });
          (0, r(54993).exportModule)(t, { wap: "wap" }, (e2) => e2.wap);
        }, 20748(e, t) {
          "use strict";
          function r(e2, t2, r2, n2) {
            var o = { timer: void 0, lastArgs: [] }, i = function() {
              for (var n3 = this, i2 = [], a = 0; a < arguments.length; a++) i2[a] = arguments[a];
              o.lastArgs = i2, o.timer ? clearTimeout(o.timer) : t2 && r2.apply(this, o.lastArgs), o.timer = setTimeout(function() {
                t2 || r2.apply(n3, o.lastArgs), o.timer = void 0;
              }, e2);
            };
            return n2 && (i = i.bind(n2)), i.options = o, i;
          }
          function n(e2, t2) {
            for (var n2 = [], o = 2; o < arguments.length; o++) n2[o - 2] = arguments[o];
            if (0 === n2.length) throw new Error("function applied debounce decorator should be a method");
            if (1 === n2.length) throw new Error("method applied debounce decorator should have valid name");
            var i = n2[0], a = n2[1], s = 3 === n2.length && n2[2] ? n2[2] : Object.getOwnPropertyDescriptor(i, a);
            if (s) return function(e3, t3, n3) {
              var o2 = n3.value;
              return n3.value = r(e3, t3, o2), n3;
            }(e2, t2, s);
            !function(e3, t3, n3, o2) {
              var i2;
              Object.defineProperty(n3, o2, { configurable: true, enumerable: false, get: function() {
                return i2;
              }, set: function(n4) {
                i2 = r(e3, t3, n4, this);
              } });
            }(e2, t2, i, a);
          }
          t.debounce = function() {
            for (var e2 = [], t2 = 0; t2 < arguments.length; t2++) e2[t2] = arguments[t2];
            var r2 = 500, o = false;
            if (e2.length && ("number" == typeof e2[0] || "object" == typeof e2[0] && void 0 !== e2[0].leading)) {
              "number" == typeof e2[0] && (r2 = e2[0]);
              var i = void 0;
              return "object" == typeof e2[0] && void 0 !== e2[0].leading && (i = e2[0]), 1 < e2.length && "object" == typeof e2[1] && void 0 !== e2[1].leading && (i = e2[1]), i && (o = i.leading), function() {
                for (var e3 = [], t3 = 0; t3 < arguments.length; t3++) e3[t3] = arguments[t3];
                return n.apply(void 0, [r2, o].concat(e3));
              };
            }
            return n.apply(void 0, [r2, o].concat(e2));
          };
        }, 44276(e, t) {
          var r, n, o;
          n = [], void 0 === (o = "function" == typeof (r = function() {
            "use strict";
            function e2(t2) {
              return e2.regex.test((t2 || "").trim());
            }
            return e2.regex = /^data:([a-z]+\/[a-z0-9-+.]+(;[a-z0-9-.!#$%*+.{}|~`]+=[a-z0-9-.!#$%*+.{}()_|~`]+)*)?(;base64)?,([a-z0-9!$&',()*+;=\-._~:@\/?%\s<>]*?)$/i, e2;
          }) ? r.apply(t, n) : r) || (e.exports = o);
        }, 54428() {
        } };
        const __webpack_module_cache__ = {};
        function __webpack_require__(e) {
          const t = __webpack_module_cache__[e];
          if (void 0 !== t) return t.exports;
          const r = __webpack_module_cache__[e] = { exports: {} };
          return __webpack_modules__[e].call(r.exports, r, r.exports, __webpack_require__), r.exports;
        }
        __webpack_require__.d = (e, t) => {
          if (Array.isArray(t)) for (var r = 0; r < t.length; ) {
            var n = t[r++], o = t[r++];
            __webpack_require__.o(e, n) ? 0 === o && r++ : 0 === o ? Object.defineProperty(e, n, { enumerable: true, value: t[r++] }) : Object.defineProperty(e, n, { enumerable: true, get: o });
          }
          else for (var n in t) __webpack_require__.o(t, n) && !__webpack_require__.o(e, n) && Object.defineProperty(e, n, { enumerable: true, get: t[n] });
        }, __webpack_require__.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t);
        let __webpack_exports__ = __webpack_require__(28156);
        self.WPP = __webpack_exports__;
      })();
    }
  });

  // src/main-world.ts
  var import_wa_js = __toESM(require_wppconnect_wa(), 1);
  var JID_PHONE_RE = /(\d{8,15})@(c\.us|s\.whatsapp\.net|lid)/;
  var MAIN_WORLD_SOURCE = "conector-whatsapp-main-world";
  var ISOLATED_SOURCE = "conector-whatsapp-isolated";
  function postToIsolatedWorld(payload) {
    try {
      window.postMessage({ source: MAIN_WORLD_SOURCE, ...payload }, window.location.origin);
    } catch {
    }
  }
  function extractPhone(jid) {
    return jid.match(JID_PHONE_RE)?.[1] ?? null;
  }
  var MAX_PROCESSED_IDS = 2e3;
  var processedMsgIds = /* @__PURE__ */ new Set();
  function alreadyProcessed(id) {
    if (processedMsgIds.has(id)) return true;
    processedMsgIds.add(id);
    if (processedMsgIds.size > MAX_PROCESSED_IDS) {
      const oldest = processedMsgIds.values().next().value;
      if (oldest !== void 0) processedMsgIds.delete(oldest);
    }
    return false;
  }
  console.log("[Conector WhatsApp] main-world.ts carregado \u2014 aguardando wa-js ficar pronto...");
  var WPP = self.WPP;
  if (!WPP) {
    console.error("[Conector WhatsApp] window.WPP n\xE3o existe depois de importar @wppconnect/wa-js \u2014 o bundle pode ter mudado de formato numa atualiza\xE7\xE3o da lib.");
  }
  setTimeout(() => {
    if (!WPP?.loader.isFullReady) {
      console.warn("[Conector WhatsApp] wa-js ainda n\xE3o ficou pronto depois de 20s \u2014 pode ser vers\xE3o do WhatsApp Web incompat\xEDvel com @wppconnect/wa-js.");
    }
  }, 2e4);
  try {
    if (!WPP) throw new Error("WPP indispon\xEDvel");
    const wpp = WPP;
    wpp.loader.onFullReady(() => {
      console.log("[Conector WhatsApp] wa-js pronto \u2014 escutando mensagens novas.");
      try {
        wpp.on("chat.new_message", (rawMsg) => {
          const msg = rawMsg;
          (async () => {
            try {
              if (msg?.id?.fromMe) return;
              const msgId = msg?.id?._serialized;
              if (msgId && alreadyProcessed(msgId)) return;
              const fromJid = msg.from?._serialized ?? "";
              if (!fromJid || fromJid.endsWith("@g.us")) return;
              const body = typeof msg.body === "string" ? msg.body.trim() : "";
              if (!body) return;
              const phone = extractPhone(fromJid);
              if (!phone) return;
              const isLid = fromJid.endsWith("@lid");
              let realPhone = null;
              if (isLid) {
                try {
                  const entry = await wpp.contact.getPnLidEntry(fromJid);
                  const resolvedJid = entry?.phoneNumber?._serialized;
                  if (resolvedJid) realPhone = extractPhone(resolvedJid);
                } catch {
                }
              }
              const contactName = typeof msg.notifyName === "string" && msg.notifyName.trim() ? msg.notifyName.trim() : null;
              const ts = typeof msg.t === "number" && msg.t > 0 ? msg.t * 1e3 : Date.now();
              console.log(`[Conector WhatsApp] mensagem capturada de ${phone}${isLid ? ` (lid${realPhone ? `, resolvido: ${realPhone}` : ""})` : ""}`);
              postToIsolatedWorld({
                type: "whatsapp-message",
                phone,
                chatId: fromJid,
                isLid,
                realPhone,
                contactName,
                body,
                ts,
                adId: msg.ctwaContext?.sourceId ?? null,
                adSourceUrl: msg.ctwaContext?.sourceUrl ?? null,
                adTitle: msg.ctwaContext?.title ?? null
              });
            } catch {
            }
          })();
        });
      } catch (e) {
        console.error("[Conector WhatsApp] erro ao registrar listener de mensagem:", e);
      }
      window.addEventListener("message", (event) => {
        if (event.source !== window || event.origin !== window.location.origin) return;
        const data = event.data;
        if (data?.source !== ISOLATED_SOURCE || data.type !== "send-reply") return;
        const { chatId, text, requestId } = data;
        if (!chatId || !text || !requestId) return;
        wpp.chat.sendTextMessage(chatId, text).then(() => {
          postToIsolatedWorld({ type: "send-result", requestId, ok: true });
        }).catch((err) => {
          const message = err instanceof Error ? err.message : String(err);
          postToIsolatedWorld({ type: "send-result", requestId, ok: false, error: message });
        });
      });
    });
  } catch (e) {
    console.error("[Conector WhatsApp] wa-js falhou ao inicializar:", e);
  }
})();
/*! Bundled license information:

@wppconnect/wa-js/dist/wppconnect-wa.js:
  (*! For license information please see wppconnect-wa.js.LICENSE.txt *)
  (*! wppconnect-team/wa-js v4.5.0 *)
*/
//# sourceMappingURL=main-world.js.map
